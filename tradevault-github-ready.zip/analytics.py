"""
TradeVault Analytics & Quantitative Trading Math
Calculates net/gross P/L, win rate, profit factor, drawdown, expectancy,
streaks, session & instrument breakdowns, equity curves, calendar datasets,
and prop-firm challenge metrics.
"""

from datetime import datetime, date
from collections import defaultdict

def filter_trades(trades, account_id=None, strategy_id=None, instrument=None, session=None, start_date=None, end_date=None, side=None):
    """Filter list of trade dictionaries based on criteria"""
    filtered = []
    for t in trades:
        if account_id and t.get("account_id") != account_id:
            continue
        if strategy_id and t.get("strategy_id") != strategy_id:
            continue
        if instrument and t.get("instrument") != instrument:
            continue
        if session and t.get("session") != session:
            continue
        if side and t.get("side") != side:
            continue
        
        close_time_str = t.get("close_time", "") or t.get("open_time", "")
        if close_time_str:
            trade_dt_str = close_time_str[:10]
            if start_date and trade_dt_str < start_date:
                continue
            if end_date and trade_dt_str > end_date:
                continue
        filtered.append(t)
    return filtered

def calculate_dashboard_metrics(trades, account=None):
    """
    Computes complete dashboard statistics:
    - Total net P/L, Gross profit, Gross loss
    - Win rate, Total trades, Win/Loss count
    - Profit factor, Average win, Average loss
    - Average Risk/Reward ratio, Expectancy per trade
    - Maximum drawdown ($ and %)
    - Current balance & equity
    - Current streak & longest streak
    - Best and worst trading days
    """
    total_trades = len(trades)
    if total_trades == 0:
        starting_bal = account.get("starting_balance", 100000.0) if account else 100000.0
        return {
            "total_trades": 0,
            "win_trades": 0,
            "loss_trades": 0,
            "be_trades": 0,
            "win_rate": 0.0,
            "loss_rate": 0.0,
            "net_pnl": 0.0,
            "gross_profit": 0.0,
            "gross_loss": 0.0,
            "total_commission": 0.0,
            "total_swap": 0.0,
            "profit_factor": 0.0,
            "avg_win": 0.0,
            "avg_loss": 0.0,
            "avg_trade": 0.0,
            "avg_rr": 0.0,
            "expectancy": 0.0,
            "max_drawdown_amount": 0.0,
            "max_drawdown_pct": 0.0,
            "current_balance": starting_bal,
            "current_equity": starting_bal,
            "starting_balance": starting_bal,
            "current_streak": {"type": "none", "count": 0},
            "best_win_streak": 0,
            "worst_loss_streak": 0,
            "best_day": {"date": "N/A", "pnl": 0.0},
            "worst_day": {"date": "N/A", "pnl": 0.0},
            "daily_pnl_chart": [],
            "equity_curve": [],
            "win_rate_over_time": [],
            "session_performance": {},
            "instrument_performance": {},
            "long_vs_short": {"long": {"count": 0, "net_pnl": 0, "win_rate": 0}, "short": {"count": 0, "net_pnl": 0, "win_rate": 0}}
        }

    # Sort trades by close_time ascending
    sorted_trades = sorted(trades, key=lambda x: x.get("close_time", "") or x.get("open_time", ""))

    win_trades = [t for t in sorted_trades if t.get("net_pnl", 0) > 0]
    loss_trades = [t for t in sorted_trades if t.get("net_pnl", 0) < 0]
    be_trades = [t for t in sorted_trades if t.get("net_pnl", 0) == 0]

    win_count = len(win_trades)
    loss_count = len(loss_trades)
    be_count = len(be_trades)

    win_rate = round((win_count / total_trades) * 100, 2)
    loss_rate = round((loss_count / total_trades) * 100, 2)

    gross_profit = round(sum(t.get("net_pnl", 0) for t in win_trades), 2)
    gross_loss = round(abs(sum(t.get("net_pnl", 0) for t in loss_trades)), 2)
    total_commission = round(sum(t.get("commission", 0) for t in sorted_trades), 2)
    total_swap = round(sum(t.get("swap", 0) for t in sorted_trades), 2)
    net_pnl = round(sum(t.get("net_pnl", 0) for t in sorted_trades), 2)

    # Profit factor: Gross Profit / Gross Loss
    if gross_loss > 0:
        profit_factor = round(gross_profit / gross_loss, 2)
    else:
        profit_factor = round(gross_profit, 2) if gross_profit > 0 else 0.0

    avg_win = round(gross_profit / win_count, 2) if win_count > 0 else 0.0
    avg_loss = round(gross_loss / loss_count, 2) if loss_count > 0 else 0.0
    avg_trade = round(net_pnl / total_trades, 2)

    # Average Risk to Reward (R-multiple)
    rr_values = [t.get("actual_rr", 0.0) for t in sorted_trades if t.get("actual_rr") is not None and t.get("actual_rr") != 0.0]
    if rr_values:
        avg_rr = round(sum(rr_values) / len(rr_values), 2)
    elif avg_loss > 0:
        avg_rr = round(avg_win / avg_loss, 2)
    else:
        avg_rr = 0.0

    # Expectancy formula: (Win Rate * Avg Win) - (Loss Rate * Avg Loss)
    expectancy = round(((win_rate / 100.0) * avg_win) - ((loss_rate / 100.0) * avg_loss), 2)

    # Balance & Equity Tracking + Drawdown Calculation
    starting_bal = account.get("starting_balance", 100000.0) if account else 100000.0
    current_bal = starting_bal
    peak_bal = starting_bal
    max_dd_amount = 0.0
    max_dd_pct = 0.0

    equity_curve = [{"trade_num": 0, "date": "Start", "equity": starting_bal, "net_pnl": 0.0, "drawdown_pct": 0.0}]
    cum_pnl = 0.0

    for i, t in enumerate(sorted_trades, 1):
        pnl = t.get("net_pnl", 0.0)
        cum_pnl += pnl
        current_bal = starting_bal + cum_pnl

        if current_bal > peak_bal:
            peak_bal = current_bal

        current_dd_amount = peak_bal - current_bal
        current_dd_pct = (current_dd_amount / peak_bal * 100.0) if peak_bal > 0 else 0.0

        if current_dd_amount > max_dd_amount:
            max_dd_amount = current_dd_amount
        if current_dd_pct > max_dd_pct:
            max_dd_pct = current_dd_pct

        trade_date_str = (t.get("close_time", "") or t.get("open_time", ""))[:10]
        equity_curve.append({
            "trade_num": i,
            "date": trade_date_str,
            "ticket": t.get("ticket_id", f"#{i}"),
            "instrument": t.get("instrument", ""),
            "side": t.get("side", ""),
            "trade_pnl": pnl,
            "cum_pnl": round(cum_pnl, 2),
            "equity": round(current_bal, 2),
            "peak": round(peak_bal, 2),
            "drawdown_pct": round(current_dd_pct, 2)
        })

    # Streaks calculation
    current_streak_type = "none"
    current_streak_count = 0
    best_win_streak = 0
    worst_loss_streak = 0
    temp_win = 0
    temp_loss = 0

    for t in sorted_trades:
        pnl = t.get("net_pnl", 0.0)
        if pnl > 0:
            temp_win += 1
            temp_loss = 0
            if temp_win > best_win_streak:
                best_win_streak = temp_win
        elif pnl < 0:
            temp_loss += 1
            temp_win = 0
            if temp_loss > worst_loss_streak:
                worst_loss_streak = temp_loss
        else:
            temp_win = 0
            temp_loss = 0

    # Determine current streak from end of list
    if sorted_trades:
        last_trade_pnl = sorted_trades[-1].get("net_pnl", 0.0)
        if last_trade_pnl > 0:
            current_streak_type = "win"
            for t in reversed(sorted_trades):
                if t.get("net_pnl", 0.0) > 0:
                    current_streak_count += 1
                else:
                    break
        elif last_trade_pnl < 0:
            current_streak_type = "loss"
            for t in reversed(sorted_trades):
                if t.get("net_pnl", 0.0) < 0:
                    current_streak_count += 1
                else:
                    break

    # Daily aggregation (Best / Worst day + Daily P/L chart)
    daily_groups = defaultdict(lambda: {"pnl": 0.0, "trades": 0, "wins": 0, "losses": 0})
    for t in sorted_trades:
        d_str = (t.get("close_time", "") or t.get("open_time", ""))[:10]
        pnl = t.get("net_pnl", 0.0)
        daily_groups[d_str]["pnl"] += pnl
        daily_groups[d_str]["trades"] += 1
        if pnl > 0:
            daily_groups[d_str]["wins"] += 1
        elif pnl < 0:
            daily_groups[d_str]["losses"] += 1

    daily_chart = []
    best_day = {"date": "N/A", "pnl": -999999999.0}
    worst_day = {"date": "N/A", "pnl": 999999999.0}

    for d_str in sorted(daily_groups.keys()):
        data = daily_groups[d_str]
        pnl_val = round(data["pnl"], 2)
        daily_chart.append({
            "date": d_str,
            "pnl": pnl_val,
            "trades": data["trades"],
            "wins": data["wins"],
            "losses": data["losses"],
            "win_rate": round((data["wins"] / data["trades"]) * 100, 1) if data["trades"] > 0 else 0.0
        })
        if pnl_val > best_day["pnl"]:
            best_day = {"date": d_str, "pnl": pnl_val}
        if pnl_val < worst_day["pnl"]:
            worst_day = {"date": d_str, "pnl": pnl_val}

    if best_day["pnl"] == -999999999.0:
        best_day = {"date": "N/A", "pnl": 0.0}
    if worst_day["pnl"] == 999999999.0:
        worst_day = {"date": "N/A", "pnl": 0.0}

    # Win rate over time (rolling cumulative win rate)
    win_rate_over_time = []
    rolling_wins = 0
    for i, t in enumerate(sorted_trades, 1):
        if t.get("net_pnl", 0.0) > 0:
            rolling_wins += 1
        win_rate_over_time.append({
            "trade_num": i,
            "date": (t.get("close_time", "") or t.get("open_time", ""))[:10],
            "win_rate": round((rolling_wins / i) * 100, 1)
        })

    # Session performance breakdown
    session_perf = defaultdict(lambda: {"count": 0, "net_pnl": 0.0, "wins": 0, "losses": 0})
    for t in sorted_trades:
        sess = t.get("session") or "Other"
        pnl = t.get("net_pnl", 0.0)
        session_perf[sess]["count"] += 1
        session_perf[sess]["net_pnl"] += pnl
        if pnl > 0:
            session_perf[sess]["wins"] += 1
        elif pnl < 0:
            session_perf[sess]["losses"] += 1

    formatted_session_perf = {}
    for sess, d in session_perf.items():
        cnt = d["count"]
        formatted_session_perf[sess] = {
            "count": cnt,
            "net_pnl": round(d["net_pnl"], 2),
            "wins": d["wins"],
            "losses": d["losses"],
            "win_rate": round((d["wins"] / cnt) * 100, 1) if cnt > 0 else 0.0
        }

    # Instrument performance breakdown
    inst_perf = defaultdict(lambda: {"count": 0, "net_pnl": 0.0, "wins": 0, "losses": 0})
    for t in sorted_trades:
        inst = t.get("instrument") or "Unknown"
        pnl = t.get("net_pnl", 0.0)
        inst_perf[inst]["count"] += 1
        inst_perf[inst]["net_pnl"] += pnl
        if pnl > 0:
            inst_perf[inst]["wins"] += 1
        elif pnl < 0:
            inst_perf[inst]["losses"] += 1

    formatted_inst_perf = {}
    for inst, d in inst_perf.items():
        cnt = d["count"]
        formatted_inst_perf[inst] = {
            "count": cnt,
            "net_pnl": round(d["net_pnl"], 2),
            "wins": d["wins"],
            "losses": d["losses"],
            "win_rate": round((d["wins"] / cnt) * 100, 1) if cnt > 0 else 0.0
        }

    # Long versus short
    long_trades = [t for t in sorted_trades if (t.get("side") or "").upper() in ("BUY", "LONG")]
    short_trades = [t for t in sorted_trades if (t.get("side") or "").upper() in ("SELL", "SHORT")]
    
    long_wins = len([t for t in long_trades if t.get("net_pnl", 0) > 0])
    short_wins = len([t for t in short_trades if t.get("net_pnl", 0) > 0])

    long_vs_short = {
        "long": {
            "count": len(long_trades),
            "net_pnl": round(sum(t.get("net_pnl", 0) for t in long_trades), 2),
            "wins": long_wins,
            "win_rate": round((long_wins / len(long_trades)) * 100, 1) if long_trades else 0.0
        },
        "short": {
            "count": len(short_trades),
            "net_pnl": round(sum(t.get("net_pnl", 0) for t in short_trades), 2),
            "wins": short_wins,
            "win_rate": round((short_wins / len(short_trades)) * 100, 1) if short_trades else 0.0
        }
    }

    # Monthly performance
    monthly_perf = defaultdict(lambda: {"net_pnl": 0.0, "trades": 0, "wins": 0, "losses": 0})
    for t in sorted_trades:
        m_str = (t.get("close_time", "") or t.get("open_time", ""))[:7] # YYYY-MM
        pnl = t.get("net_pnl", 0.0)
        monthly_perf[m_str]["net_pnl"] += pnl
        monthly_perf[m_str]["trades"] += 1
        if pnl > 0:
            monthly_perf[m_str]["wins"] += 1
        elif pnl < 0:
            monthly_perf[m_str]["losses"] += 1

    monthly_chart = []
    for m_str in sorted(monthly_perf.keys()):
        d = monthly_perf[m_str]
        monthly_chart.append({
            "month": m_str,
            "net_pnl": round(d["net_pnl"], 2),
            "trades": d["trades"],
            "wins": d["wins"],
            "losses": d["losses"],
            "win_rate": round((d["wins"] / d["trades"]) * 100, 1) if d["trades"] > 0 else 0.0
        })

    return {
        "total_trades": total_trades,
        "win_trades": win_count,
        "loss_trades": loss_count,
        "be_trades": be_count,
        "win_rate": win_rate,
        "loss_rate": loss_rate,
        "net_pnl": net_pnl,
        "gross_profit": gross_profit,
        "gross_loss": gross_loss,
        "total_commission": total_commission,
        "total_swap": total_swap,
        "profit_factor": profit_factor,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "avg_trade": avg_trade,
        "avg_rr": avg_rr,
        "expectancy": expectancy,
        "max_drawdown_amount": round(max_dd_amount, 2),
        "max_drawdown_pct": round(max_dd_pct, 2),
        "current_balance": round(current_bal, 2),
        "current_equity": round(current_bal, 2),
        "starting_balance": round(starting_bal, 2),
        "current_streak": {"type": current_streak_type, "count": current_streak_count},
        "best_win_streak": best_win_streak,
        "worst_loss_streak": worst_loss_streak,
        "best_day": best_day,
        "worst_day": worst_day,
        "daily_pnl_chart": daily_chart,
        "equity_curve": equity_curve,
        "win_rate_over_time": win_rate_over_time,
        "session_performance": formatted_session_perf,
        "instrument_performance": formatted_inst_perf,
        "long_vs_short": long_vs_short,
        "monthly_performance": monthly_chart
    }

def calculate_strategy_analytics(strategy, trades):
    """Computes comprehensive metrics for a specific strategy with sample size reliability rating"""
    strat_trades = [t for t in trades if t.get("strategy_id") == strategy["id"]]
    count = len(strat_trades)

    if count == 0:
        return {
            "strategy": strategy,
            "trade_count": 0,
            "win_rate": 0.0,
            "net_pnl": 0.0,
            "profit_factor": 0.0,
            "avg_rr": 0.0,
            "sample_size_rating": "No Data (0 trades)",
            "sample_size_level": "none",
            "best_session": "N/A",
            "common_mistakes": [],
            "long_vs_short": {"long_win_rate": 0, "short_win_rate": 0, "long_trades": 0, "short_trades": 0},
            "recent_trades": []
        }

    wins = [t for t in strat_trades if t.get("net_pnl", 0) > 0]
    losses = [t for t in strat_trades if t.get("net_pnl", 0) < 0]
    gross_win = sum(t.get("net_pnl", 0) for t in wins)
    gross_loss = abs(sum(t.get("net_pnl", 0) for t in losses))
    net_pnl = round(sum(t.get("net_pnl", 0) for t in strat_trades), 2)
    win_rate = round((len(wins) / count) * 100, 1)

    if gross_loss > 0:
        pf = round(gross_win / gross_loss, 2)
    else:
        pf = round(gross_win, 2) if gross_win > 0 else 0.0

    rr_vals = [t.get("actual_rr", 0.0) for t in strat_trades if t.get("actual_rr") is not None and t.get("actual_rr") != 0.0]
    avg_rr = round(sum(rr_vals) / len(rr_vals), 2) if rr_vals else 0.0

    # Sample size classification rule
    if count < 15:
        sample_rating = f"Small Sample ({count} trades) - Insufficient data to verify profitability"
        sample_level = "low"
    elif count < 35:
        sample_rating = f"Moderate Sample ({count} trades) - Emerging statistical edge"
        sample_level = "medium"
    else:
        sample_rating = f"Robust Sample ({count} trades) - Statistically significant track record"
        sample_level = "high"

    # Best session
    sess_counts = defaultdict(float)
    for t in strat_trades:
        sess_counts[t.get("session") or "Other"] += t.get("net_pnl", 0.0)
    best_session = max(sess_counts.items(), key=lambda x: x[1])[0] if sess_counts else "N/A"

    # Common mistakes
    mistake_counts = defaultdict(int)
    for t in strat_trades:
        m_str = t.get("mistakes", "")
        if m_str and m_str != "None":
            for m in m_str.split(","):
                m_clean = m.strip()
                if m_clean and m_clean != "None":
                    mistake_counts[m_clean] += 1
    
    top_mistakes = sorted([{"mistake": k, "count": v} for k, v in mistake_counts.items()], key=lambda x: x["count"], reverse=True)[:3]

    # Long vs Short
    longs = [t for t in strat_trades if (t.get("side") or "").upper() in ("BUY", "LONG")]
    shorts = [t for t in strat_trades if (t.get("side") or "").upper() in ("SELL", "SHORT")]
    l_wins = len([t for t in longs if t.get("net_pnl", 0) > 0])
    s_wins = len([t for t in shorts if t.get("net_pnl", 0) > 0])

    return {
        "strategy": strategy,
        "trade_count": count,
        "win_rate": win_rate,
        "net_pnl": net_pnl,
        "profit_factor": pf,
        "avg_rr": avg_rr,
        "sample_size_rating": sample_rating,
        "sample_size_level": sample_level,
        "best_session": best_session,
        "common_mistakes": top_mistakes,
        "long_vs_short": {
            "long_trades": len(longs),
            "short_trades": len(shorts),
            "long_win_rate": round((l_wins / len(longs)) * 100, 1) if longs else 0.0,
            "short_win_rate": round((s_wins / len(shorts)) * 100, 1) if shorts else 0.0
        },
        "recent_trades": sorted(strat_trades, key=lambda x: x.get("close_time", ""), reverse=True)[:5]
    }

def calculate_prop_firm_status(account, trades):
    """
    Computes strict prop firm risk parameters:
    - Target progress %
    - Daily drawdown vs limit ($ and %)
    - Overall drawdown vs limit ($ and %)
    - Remaining daily and total cushion
    - Breach alert flags
    """
    acc_id = account["id"]
    acc_trades = [t for t in trades if t.get("account_id") == acc_id]
    
    start_bal = account.get("starting_balance", 100000.0)
    profit_target_pct = account.get("profit_target_pct", 10.0)
    max_daily_loss_pct = account.get("max_daily_loss_pct", 5.0)
    max_total_loss_pct = account.get("max_total_loss_pct", 10.0)
    dd_type = account.get("drawdown_type", "balance_based")

    target_amount = round(start_bal * (profit_target_pct / 100.0), 2)
    daily_loss_limit = round(start_bal * (max_daily_loss_pct / 100.0), 2)
    total_loss_limit = round(start_bal * (max_total_loss_pct / 100.0), 2)

    total_net_pnl = sum(t.get("net_pnl", 0.0) for t in acc_trades)
    current_balance = round(start_bal + total_net_pnl, 2)

    # Profit target progress
    if target_amount > 0:
        target_progress_pct = round(min(max((total_net_pnl / target_amount) * 100.0, 0.0), 100.0), 1)
        remaining_to_target = round(max(target_amount - total_net_pnl, 0.0), 2)
    else:
        target_progress_pct = 100.0
        remaining_to_target = 0.0

    # Today's P/L
    today_str = date.today().isoformat()
    today_trades = [t for t in acc_trades if (t.get("close_time", "") or t.get("open_time", ""))[:10] == today_str]
    today_pnl = round(sum(t.get("net_pnl", 0.0) for t in today_trades), 2)

    # Daily drawdown calculation
    # If today_pnl is negative, current daily loss = abs(today_pnl)
    current_daily_loss = abs(today_pnl) if today_pnl < 0 else 0.0
    daily_loss_used_pct = round((current_daily_loss / daily_loss_limit) * 100.0, 1) if daily_loss_limit > 0 else 0.0
    remaining_daily_cushion = round(max(daily_loss_limit - current_daily_loss, 0.0), 2)

    # Total drawdown calculation
    # Balance-based vs Trailing:
    if dd_type == "trailing":
        peak = start_bal
        running = start_bal
        for t in sorted(acc_trades, key=lambda x: x.get("close_time", "")):
            running += t.get("net_pnl", 0.0)
            if running > peak:
                peak = running
        total_loss_floor = peak - total_loss_limit
        current_total_dd = peak - current_balance
    else:
        # Standard static balance-based
        total_loss_floor = start_bal - total_loss_limit
        current_total_dd = start_bal - current_balance if current_balance < start_bal else 0.0

    total_dd_used_pct = round((max(current_total_dd, 0.0) / total_loss_limit) * 100.0, 1) if total_loss_limit > 0 else 0.0
    remaining_total_cushion = round(max(current_balance - total_loss_floor, 0.0), 2)

    # Status & Alerts
    daily_breached = current_daily_loss >= daily_loss_limit
    total_breached = (current_balance <= total_loss_floor) if current_total_dd > 0 else False
    target_hit = total_net_pnl >= target_amount and target_amount > 0

    daily_warning = daily_loss_used_pct >= 70.0 and not daily_breached
    total_warning = total_dd_used_pct >= 70.0 and not total_breached

    return {
        "account_id": acc_id,
        "account_name": account.get("name", ""),
        "broker": account.get("broker", ""),
        "phase": account.get("phase", "Phase 1"),
        "starting_balance": start_bal,
        "current_balance": current_balance,
        "current_equity": current_balance,
        "total_net_pnl": round(total_net_pnl, 2),
        "target_amount": target_amount,
        "target_progress_pct": target_progress_pct,
        "remaining_to_target": remaining_to_target,
        "today_pnl": today_pnl,
        "today_trades_count": len(today_trades),
        "daily_loss_limit": daily_loss_limit,
        "current_daily_loss": current_daily_loss,
        "daily_loss_used_pct": daily_loss_used_pct,
        "remaining_daily_cushion": remaining_daily_cushion,
        "total_loss_limit": total_loss_limit,
        "current_total_dd": round(max(current_total_dd, 0.0), 2),
        "total_dd_used_pct": total_dd_used_pct,
        "remaining_total_cushion": remaining_total_cushion,
        "daily_breached": daily_breached,
        "total_breached": total_breached,
        "daily_warning": daily_warning,
        "total_warning": total_warning,
        "target_hit": target_hit,
        "drawdown_type": dd_type
    }

def calculate_calendar_month(trades, year, month):
    """Generates monthly calendar grid dataset with daily P/L and trades count"""
    import calendar
    cal = calendar.Calendar(firstweekday=0) # Monday first
    month_days = cal.monthdatescalendar(year, month)

    daily_map = defaultdict(lambda: {"pnl": 0.0, "trades": []})
    for t in trades:
        d_str = (t.get("close_time", "") or t.get("open_time", ""))[:10]
        daily_map[d_str]["pnl"] += t.get("net_pnl", 0.0)
        daily_map[d_str]["trades"].append({
            "id": t["id"],
            "ticket": t.get("ticket_id", ""),
            "instrument": t.get("instrument", ""),
            "side": t.get("side", ""),
            "net_pnl": t.get("net_pnl", 0.0),
            "close_time": t.get("close_time", ""),
            "setup_type": t.get("setup_type", ""),
            "actual_rr": t.get("actual_rr", 0.0)
        })

    month_pnl = 0.0
    month_trades_cnt = 0
    month_wins = 0
    best_day = {"date": "", "pnl": -99999999.0}
    worst_day = {"date": "", "pnl": 99999999.0}

    grid = []
    for week in month_days:
        week_row = []
        for d in week:
            d_str = d.isoformat()
            is_current_month = (d.month == month)
            day_data = daily_map[d_str]
            pnl_val = round(day_data["pnl"], 2)
            trades_cnt = len(day_data["trades"])

            if is_current_month and trades_cnt > 0:
                month_pnl += pnl_val
                month_trades_cnt += trades_cnt
                if pnl_val > 0:
                    month_wins += 1
                if pnl_val > best_day["pnl"]:
                    best_day = {"date": d_str, "pnl": pnl_val}
                if pnl_val < worst_day["pnl"]:
                    worst_day = {"date": d_str, "pnl": pnl_val}

            week_row.append({
                "date": d_str,
                "day_number": d.day,
                "is_current_month": is_current_month,
                "pnl": pnl_val,
                "trades_count": trades_cnt,
                "trades": day_data["trades"]
            })
        grid.append(week_row)

    if best_day["pnl"] == -99999999.0:
        best_day = {"date": "N/A", "pnl": 0.0}
    if worst_day["pnl"] == 99999999.0:
        worst_day = {"date": "N/A", "pnl": 0.0}

    return {
        "year": year,
        "month": month,
        "month_name": calendar.month_name[month],
        "grid": grid,
        "summary": {
            "total_net_pnl": round(month_pnl, 2),
            "total_trades": month_trades_cnt,
            "profitable_days": month_wins,
            "best_day": best_day,
            "worst_day": worst_day
        }
    }
