# TradeVault ⚡ — Institutional Trading Journal

TradeVault is a high-performance, institutional-grade, fully responsive trading journal web application built for funded-account, prop-firm, and serious retail traders.

It provides persistent SQLite data storage, automated OCR & Vision AI trade screenshot importing, prop-firm drawdown rules tracking, strategy analytics with sample-size validation, an AI Trading Coach that audits execution leaks, and comprehensive reporting.

---

## 📸 Key Features & Architecture

### 1. Design & User Experience
* **Fintech Terminal Aesthetic:** Premium dark charcoal palette (`#07090e`, `#0d121d`, `#131b2c`) with crisp borders (`#192438`) and tabular typography (`JetBrains Mono`).
* **Tasteful P/L Styling:** Emerald green (`#10b981`) for profits and crimson (`#ef4444`) for losses.
* **Fully Responsive:** Seamless layout adaptation across mobile, tablet, and ultra-wide trading desks.
* **Customizable Branding:** One-click rebrandable in Settings (change `TradeVault` to any proprietary name), currency selector (`USD`, `EUR`, `GBP`, `JPY`), and timezone options.

### 2. Main Dashboard
Calculates genuine quantitative trading metrics from saved trades:
* **Total Net P/L**, **Gross Profit**, and **Gross Loss**
* **Win Rate**, Total Trades, Winning/Losing/Break-even trades
* **Profit Factor** $\left(\frac{\text{Gross Profit}}{\text{Gross Loss}}\right)$
* **Average Win**, **Average Loss**, and **Expectancy** per trade
* **Maximum Drawdown** (both in absolute currency and percentage from peak high-watermark)
* **Current Account Balance & Equity**
* **Current Streak** and historical best/worst streaks
* **Best and Worst Trading Days**
* **Interactive HTML5 Canvas Charts:**
  * Cumulative Equity Curve with peak watermark and drawdown shading
  * Daily Net P/L distribution bars
  * Session performance breakdown (Asia, London, New York, Overlap)
  * Instrument breakdown (XAUUSD, EURUSD, US30, NAS100, etc.)
* **Dynamic Multi-Filters:** Filter dashboard by account, strategy, session, instrument, and custom date range.

### 3. AI Auto-Journal From P/L Screenshots (Core Feature)
* **Dedicated AI Import Page:** Upload screenshots from MetaTrader 4/5, cTrader, TradingView, or prop-firm broker dashboards.
* **Flexible Inputs:** Drag-and-drop single or multiple files (JPG, PNG, WebP) from desktop or mobile.
* **Vision AI Models:** Native integration with Google Gemini 1.5/2.0 Flash Vision and OpenAI GPT-4o Vision, alongside a built-in intelligent heuristic OCR engine that operates out of the box even without external API keys.
* **Editable Preview Table:** Inspect and edit every recognized field (Ticket ID, Instrument, Side, Lots, Entry, Exit, SL, TP, Net P/L, Timestamps) before confirming import.
* **Field Confidence Tags:** Flags missing or low-confidence fields with warning badges.
* **Smart Duplicate Detection:** Cross-checks ticket IDs, timestamps, instruments, and net P/L against both the existing database and other screenshots uploaded in the same batch.
* **Total Reconciliation Check:** Verifies if the sum of extracted trades matches the screenshot's displayed total P/L.
* **Batch Import to Journal:** One-click batch save assigned directly to your chosen account and strategy.

### 4. Manual Trade Journal
* Comprehensive trade entry form with live calculations:
  * Automatic Gross P/L, Commission & Swap deduction, and Net P/L
  * Automated Risk Amount (\$) and Risk % calculation
  * Planned R-Multiple and Actual R-Multiple computation
  * Session selector, Market Condition, Setup Type
  * Qualitative logging: Emotional State, Discipline Rating (1–5 Stars), Execution Mistakes checklist, Lessons Learned, and Notes.

### 5. Strategy Analytics & Sample-Size Validation
* Create custom strategies (e.g. *ICT Liquidity Sweep*, *London Breakout*, *FVG Retest*).
* Comparative metrics: Win Rate, Net P/L, Profit Factor, Average R-Multiple, Trade Count.
* **Statistical Integrity:** Categorizes sample sizes (*Small Sample < 15 trades*, *Moderate Sample 15–35 trades*, *Robust Sample > 35 trades*) to prevent labeling setups profitable prematurely.
* Identifies best-performing sessions and common mistakes per strategy.

### 6. Trading Calendar
* Monthly calendar grid with color-coded daily net P/L (green = profit, red = loss, neutral = flat).
* Daily trade count pills and P/L labels.
* Click any day to open the **Day Inspector** showing all trades executed on that date with quick view/edit options.
* Monthly and yearly performance summaries.

### 7. Prop-Firm Account Management
* Multi-account management for funded challenges (FTMO, FundedNext, Apex, Topstep, Personal Live).
* Configurable rules: Starting Balance, Profit Target (%), Max Daily Loss (%), Max Total Drawdown (%).
* Supports **Static Balance-Based**, **Equity-Based**, and **Trailing Drawdown** calculations.
* Real-time progress bars: Distance to profit target, Remaining daily loss cushion, Remaining total drawdown allowance, and automated risk breach warnings.

### 8. Goals & Milestones
* Set targets: trade count, weekly/monthly P/L, max risk threshold, minimum discipline score, plan-following day streaks, challenge milestones.
* Visual progress meters and completed milestone archive.

### 9. AI Trading Coach
* Audits real trades, discipline ratings, emotional states, and execution notes.
* Computes the **Financial Toll of Recurring Execution Leaks** (e.g. total dollars lost to *Chasing* or *Early Exits*).
* Analyzes **Discipline Rating vs P/L Correlation** (comparing 4–5 star execution vs 1–3 star execution).
* Generates tailored self-review coaching questions grounded in the trader's actual weaknesses.

### 10. Reports & Data Export
* Downloadable CSV export with full trade metadata.
* Printable PDF Performance Audit view (`@media print` optimized).
* Full JSON database Backup & Restore.
* One-click demo dataset reset.

---

## 🛠️ Tech Stack & Directory Structure

* **Backend:** Python 3 standard library (`http.server`, `socketserver`, `sqlite3`, `json`, `urllib`). Zero external package dependencies needed!
* **Database:** SQLite (`data/trades.db`) with foreign keys, indexes, and full ACID persistence.
* **Frontend:** Modern Single Page Application (HTML5, Vanilla CSS3 with CSS custom properties, responsive JavaScript with interactive Canvas charts).

```
tradevault/
├── app.py                     # Main server, REST API router & static server
├── database.py                # SQLite schema, tables, migrations & seed data
├── analytics.py               # Quantitative trading math & drawdown calculations
├── ai_extractor.py            # AI Vision extraction, OCR heuristics & duplicate detection
├── ai_coach.py                # Data-mining trading coach engine
├── test_suite_direct.py       # Full in-memory integration test suite
├── create_samples.py          # Generator for sample platform screenshots
├── sample_screenshots/        # Bundled sample screenshots (MT5 Gold, MT5 List, Prop Firm)
├── static/
│   ├── index.html             # Single-page terminal application shell
│   ├── css/
│   │   └── style.css          # Premium dark terminal stylesheet & print rules
│   └── js/
│       ├── app.js             # SPA router, state manager, toast & formatters
│       ├── api.js             # REST API client
│       ├── charts.js          # Interactive HTML5 Canvas charting engine
│       ├── dashboard.js       # Dashboard view & interactive charts controller
│       ├── trades.js          # Trades log, filtering, sorting, modals
│       ├── import.js          # AI Screenshot Import controller
│       ├── trade_form.js      # Manual trade form with live auto-math
│       ├── calendar.js        # Monthly trading calendar & day inspector
│       ├── strategies.js      # Strategy analytics & sample size badges
│       ├── accounts.js        # Prop-firm challenge tracker
│       ├── goals.js           # Goals & milestone progress controller
│       ├── coach.js           # AI Trading Coach review view
│       ├── reports.js         # CSV export, PDF print, JSON backup & restore
│       └── settings.js        # Custom branding, currency, API key configuration
├── .env.example               # Environment variables template
├── run.bat                    # Windows 1-click startup script
├── run.sh                     # Linux/Mac 1-click startup script
└── README.md                  # Comprehensive documentation
```

---

## 🚀 Quick Start & Local Development

### Prerequisites
* Python 3.9+ (Python 3.10, 3.11, 3.12, 3.13, 3.14, 3.15 supported).
* No external libraries (`pip install`) are required to run the core app!

### Running the App
1. Open a terminal in the `tradevault` directory:
   ```bash
   python app.py
   ```
   Or on Windows, double-click `run.bat`.
2. Open your browser and navigate to:
   ```
   http://localhost:8080
   ```
3. The database is automatically created and pre-loaded with realistic prop-firm challenge demo trades so you can explore the dashboard, equity curve, trading calendar, and AI coach immediately.

---

## 🔑 Configuring AI Vision API Keys

TradeVault works out-of-the-box with a built-in intelligent heuristic OCR parser. To enable live external Vision AI models (Google Gemini or OpenAI):

1. **Option A: Through the UI (Recommended)**
   * Go to **Settings** in the left sidebar.
   * Enter your **Google Gemini API Key** (from [Google AI Studio](https://aistudio.google.com/)) or **OpenAI API Key**.
   * Click **Save Settings**. The key is stored securely in your local database and is never exposed to the frontend browser.

2. **Option B: Through Environment Variables**
   * Copy `.env.example` to `.env`:
     ```bash
     GEMINI_API_KEY=AIzaSy...
     PORT=8080
     ```

---

## 🧪 Running the Integration Test Suite

To verify all database operations, math models, AI extraction, and prop-firm rules:
```bash
python test_suite_direct.py
```
Expected output:
```
🎉 ALL 11 IN-MEMORY INTEGRATION TESTS PASSED WITH 100% SUCCESS!
```

---

## 🌐 Production Deployment

### Docker Deployment
Create a `Dockerfile`:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY . .
ENV PORT=8080
EXPOSE 8080
CMD ["python", "app.py"]
```
Build and run:
```bash
docker build -t tradevault .
docker run -p 8080:8080 -v $(pwd)/data:/app/data tradevault
```

### Deploying to Render / Railway / VPS
1. Set the Start Command to: `python app.py`
2. Set Environment Variable: `PORT=8080`
3. Attach a persistent volume to `/app/data` to persist your `trades.db` database across container redeploys.

---

## 🔒 Security & Data Privacy
* **Self-Contained Data:** All trades, accounts, and screenshots reside locally in `data/trades.db` and `uploads/`. No third-party data tracking.
* **Safe Key Handling:** AI API keys are stored on the server side and never sent back to the client interface.
* **Instant Portability:** Export your entire trading record at any time via CSV or JSON backup from the Reports page.
