"""
Generates valid sample PNG images with zero external dependencies using Python's built-in zlib.
"""

import zlib
import struct
import os

def create_png(width, height, color_rgb, output_path):
    # PNG signature
    png_sig = b'\x89PNG\r\n\x1a\n'
    
    # IHDR chunk
    # Width (4 bytes), Height (4 bytes), Bit depth (1 byte: 8), Color type (1 byte: 2 = RGB),
    # Compression method (1 byte: 0), Filter method (1 byte: 0), Interlace method (1 byte: 0)
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    ihdr_crc = struct.pack('>I', zlib.crc32(b'IHDR' + ihdr_data) & 0xffffffff)
    ihdr_chunk = struct.pack('>I', len(ihdr_data)) + b'IHDR' + ihdr_data + ihdr_crc

    # Image scanlines (filter type 0 for each line)
    r, g, b = color_rgb
    raw_scanline = b'\x00' + bytes([r, g, b] * width)
    raw_data = raw_scanline * height
    
    compressed_data = zlib.compress(raw_data)
    idat_crc = struct.pack('>I', zlib.crc32(b'IDAT' + compressed_data) & 0xffffffff)
    idat_chunk = struct.pack('>I', len(compressed_data)) + b'IDAT' + compressed_data + idat_crc

    # IEND chunk
    iend_data = b''
    iend_crc = struct.pack('>I', zlib.crc32(b'IEND' + iend_data) & 0xffffffff)
    iend_chunk = struct.pack('>I', 0) + b'IEND' + iend_data + iend_crc

    with open(output_path, 'wb') as f:
        f.write(png_sig + ihdr_chunk + idat_chunk + iend_chunk)

if __name__ == "__main__":
    out_dir = os.path.join(os.path.dirname(__file__), "sample_screenshots")
    os.makedirs(out_dir, exist_ok=True)
    
    # 1. MT5 Gold Buy trade
    create_png(600, 400, (18, 24, 38), os.path.join(out_dir, "mt5_xauusd_trade.png"))
    # 2. MT5 Multi-trade history list
    create_png(800, 500, (14, 18, 28), os.path.join(out_dir, "mt5_closed_history_list.png"))
    # 3. Prop firm dashboard
    create_png(700, 450, (22, 30, 46), os.path.join(out_dir, "propfirm_challenge_payout.png"))
    print("Sample screenshots created successfully.")
