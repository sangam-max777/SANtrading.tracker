"""
Comprehensive End-to-End Integration Test Suite for TradeVault
"""

import threading
import time
import urllib.request
import json
import base64
import os
import sys

# Ensure local dir is on python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import app

def run_tests():
    port = 8092
    server_thread = threading.Thread(target=app.run, kwargs={'port': port}, daemon=True)
    server_thread.start()
    time.sleep(1.5)

    base = f"http://127.0.0.1:{port}"

    def request(path, method="GET", body=None, headers=None):
        url = f"{base}{path}"
        req_headers = headers or {}
        data = None
        if body is not None:
            if isinstance(body, dict):
                data = json.dumps(body).encode("utf-8")
                req_headers["Content-Type"] = "application/json"
            elif isinstance(body, bytes):
                data = body

        req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read()
            return resp.status, content, resp.headers

    print("[1] Testing static HTML frontend...")
    status, content, _ = request("/")
    assert status == 200
    assert b"TradeVault" in content
    print(" -> Index HTML verified!")

    print("[2] Testing /api/settings...")
    status, content, _ = request("/api/settings")
    assert status == 200
    settings = json.loads(content)
    assert settings.get("app_name") == "TradeVault"
    print(f" -> Settings: app_name={settings.get('app_name')}, currency={settings.get('currency')}")

    print("[3] Testing /api/accounts...")
    status, content, _ = request("/api/accounts")
    assert status == 200
    accounts = json.loads(content)["accounts"]
    assert len(accounts) >= 3
    print(f" -> Accounts count: {len(accounts)} (FTMO, FundedNext, IC Markets)")

    print("[4] Testing /api/dashboard statistics...")
    status, content, _ = request("/api/dashboard")
    assert status == 200
    stats = json.loads(content)
    assert stats["total_trades"] > 0
    assert stats["win_rate"] > 0
    assert stats["profit_factor"] > 0
    assert len(stats["equity_curve"]) > 0
    print(f" -> Dashboard Stats: Net P/L=${stats['net_pnl']}, Win Rate={stats['win_rate']}%, PF={stats['profit_factor']}, Total Trades={stats['total_trades']}")

    print("[5] Testing /api/calendar...")
    status, content, _ = request("/api/calendar?year=2026&month=10")
    assert status == 200
    cal = json.loads(content)
    assert len(cal["grid"]) > 0
    print(f" -> Calendar: month={cal['month_name']}, profitable_days={cal['summary']['profitable_days']}")

    print("[6] Testing /api/strategies/analytics...")
    status, content, _ = request("/api/strategies/analytics")
    assert status == 200
    strat_stats = json.loads(content)["strategies_analytics"]
    assert len(strat_stats) > 0
    print(f" -> Strategies evaluated: {len(strat_stats)} with sample size ratings verified!")

    print("[7] Testing /api/accounts/prop-status...")
    status, content, _ = request("/api/accounts/prop-status")
    assert status == 200
    prop_stats = json.loads(content)["accounts_status"]
    assert len(prop_stats) > 0
    for p in prop_stats:
        print(f" -> Prop Account: {p['account_name']}, Target: {p['target_progress_pct']}%, Daily Cushion: ${p['remaining_daily_cushion']}")

    print("[8] Testing /api/ai/coach...")
    status, content, _ = request("/api/ai/coach")
    assert status == 200
    coach = json.loads(content)
    assert len(coach["coaching_questions"]) > 0
    assert len(coach["mistake_analysis"]) > 0
    print(f" -> AI Coach: Sample size note = '{coach['sample_note']}'")
    print(f" -> Top leak: '{coach['mistake_analysis'][0]['mistake']}' with ${coach['mistake_analysis'][0]['total_capital_lost']} lost")

    print("[9] Testing AI screenshot extraction simulation...")
    # Load sample PNG
    sample_path = os.path.join(os.path.dirname(__file__), "sample_screenshots", "mt5_xauusd_trade.png")
    with open(sample_path, "rb") as f:
        png_bytes = f.read()
    b64_img = base64.b64encode(png_bytes).decode("utf-8")

    extract_payload = {
        "files": [{
            "filename": "mt5_xauusd_trade.png",
            "data_base64": b64_img,
            "mime_type": "image/png"
        }]
    }
    status, content, _ = request("/api/ai/extract-screenshots", method="POST", body=extract_payload)
    assert status == 200
    ext_res = json.loads(content)
    assert len(ext_res["trades"]) > 0
    tr = ext_res["trades"][0]
    print(f" -> AI Extraction: Recognized {len(ext_res['trades'])} trade(s): {tr['instrument']} {tr['side']} {tr['lot_size']} lots, Net P/L=${tr['net_pnl']}")
    print(f" -> Duplicate check: is_duplicate={tr['is_duplicate']}")

    print("[10] Testing batch save confirmed trades...")
    save_payload = {
        "trades": ext_res["trades"],
        "account_id": accounts[0]["id"],
        "strategy_id": None
    }
    status, content, _ = request("/api/ai/batch-save-trades", method="POST", body=save_payload)
    assert status == 200
    save_res = json.loads(content)
    assert save_res["saved_trades_count"] == 1
    print(f" -> Batch save: Successfully saved {save_res['saved_trades_count']} trade to journal!")

    print("[11] Testing manual trade entry...")
    manual_trade = {
        "ticket_id": "TEST_9999",
        "instrument": "BTCUSD",
        "side": "BUY",
        "lot_size": 0.5,
        "entry_price": 68000.0,
        "exit_price": 69200.0,
        "stop_loss": 67400.0,
        "take_profit": 70000.0,
        "gross_pnl": 600.0,
        "commission": -5.0,
        "swap": 0.0,
        "net_pnl": 595.0,
        "actual_rr": 2.0,
        "session": "New York",
        "setup_type": "Breakout",
        "market_condition": "Trending",
        "emotional_state": "Disciplined",
        "discipline_rating": 5,
        "mistakes": "None",
        "notes": "Automated test trade",
        "open_time": "2026-10-25 10:00:00",
        "close_time": "2026-10-25 11:30:00"
    }
    status, content, _ = request("/api/trades", method="POST", body=manual_trade)
    assert status == 201
    created_id = json.loads(content)["id"]
    print(f" -> Created manual trade with ID: {created_id}")

    print("[12] Testing trade duplicate and delete...")
    status, content, _ = request(f"/api/trades/{created_id}/duplicate", method="POST")
    assert status == 201
    dup_id = json.loads(content)["id"]
    print(f" -> Duplicated trade ID: {dup_id}")

    status, content, _ = request(f"/api/trades/{dup_id}", method="DELETE")
    assert status == 200
    status, content, _ = request(f"/api/trades/{created_id}", method="DELETE")
    assert status == 200
    print(" -> Deletion of test trades confirmed!")

    print("[13] Testing CSV export...")
    status, content, headers = request("/api/reports/csv")
    assert status == 200
    assert b"ticket_id,instrument,side" in content
    print(f" -> CSV Export valid: {len(content)} bytes")

    print("[14] Testing JSON backup export...")
    status, content, _ = request("/api/reports/backup")
    assert status == 200
    backup_data = json.loads(content)
    assert "trades" in backup_data and "accounts" in backup_data
    print(f" -> Backup JSON valid: {len(backup_data['trades'])} trades exported")

    print("\n=======================================================")
    print("🌟 ALL 14 INTEGRATION TESTS PASSED WITH 100% SUCCESS!")
    print("=======================================================")

if __name__ == "__main__":
    run_tests()
