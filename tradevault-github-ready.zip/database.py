"""
TradeVault Database Layer
SQLite persistence for Accounts, Strategies, Trades, Goals, and Settings.
Zero external dependencies required.
"""

import sqlite3
import json
import os
import uuid
from datetime import datetime, date, timedelta

DB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DB_PATH = os.path.join(DB_DIR, "trades.db")

def get_connection():
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Accounts table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounts (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        broker TEXT DEFAULT '',
        account_type TEXT DEFAULT 'funded_challenge', -- funded_challenge, personal_live, demo
        starting_balance REAL NOT NULL DEFAULT 100000.0,
        current_balance REAL NOT NULL DEFAULT 100000.0,
        current_equity REAL NOT NULL DEFAULT 100000.0,
        currency TEXT NOT NULL DEFAULT 'USD',
        profit_target_pct REAL DEFAULT 10.0,
        max_daily_loss_pct REAL DEFAULT 5.0,
        max_total_loss_pct REAL DEFAULT 10.0,
        drawdown_type TEXT DEFAULT 'balance_based', -- balance_based, equity_based, trailing
        phase TEXT DEFAULT 'Phase 1', -- Phase 1, Phase 2, Funded, Live
        status TEXT DEFAULT 'active', -- active, passed, breached, archived
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """)

    # Strategies table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS strategies (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT DEFAULT '',
        setup_types TEXT DEFAULT '', -- comma separated
        color TEXT DEFAULT '#3b82f6',
        created_at TEXT NOT NULL
    )
    """)

    # Trades table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS trades (
        id TEXT PRIMARY KEY,
        ticket_id TEXT DEFAULT '',
        account_id TEXT REFERENCES accounts(id) ON DELETE SET NULL,
        strategy_id TEXT REFERENCES strategies(id) ON DELETE SET NULL,
        instrument TEXT NOT NULL, -- EURUSD, XAUUSD, US30, etc.
        side TEXT NOT NULL, -- BUY (Long) or SELL (Short)
        lot_size REAL NOT NULL DEFAULT 1.0,
        entry_price REAL NOT NULL,
        exit_price REAL NOT NULL,
        stop_loss REAL DEFAULT 0.0,
        take_profit REAL DEFAULT 0.0,
        gross_pnl REAL NOT NULL DEFAULT 0.0,
        commission REAL DEFAULT 0.0,
        swap REAL DEFAULT 0.0,
        net_pnl REAL NOT NULL DEFAULT 0.0,
        risk_amount REAL DEFAULT 0.0,
        risk_pct REAL DEFAULT 1.0,
        planned_rr REAL DEFAULT 0.0,
        actual_rr REAL DEFAULT 0.0,
        session TEXT DEFAULT 'London', -- Asia, London, New York, London/NY Overlap
        setup_type TEXT DEFAULT '',
        market_condition TEXT DEFAULT 'Trending', -- Trending, Ranging, Breakout, High Volatility
        entry_reason TEXT DEFAULT '',
        exit_reason TEXT DEFAULT '',
        emotional_state TEXT DEFAULT 'Disciplined', -- Disciplined, Anxious, FOMO, Greedy, Hesitant, Confident
        discipline_rating INTEGER DEFAULT 5, -- 1 to 5 stars
        mistakes TEXT DEFAULT '', -- comma separated, e.g. 'Early Exit, Revenge Trade'
        lessons TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        screenshots TEXT DEFAULT '[]', -- JSON array of file paths
        open_time TEXT NOT NULL,
        close_time TEXT NOT NULL,
        status TEXT DEFAULT 'CLOSED', -- OPEN, CLOSED
        is_imported INTEGER DEFAULT 0, -- 1 if from AI screenshot
        import_source TEXT DEFAULT '',
        import_confidence TEXT DEFAULT '', -- high, medium, low
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """)

    # Goals table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS goals (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        target_type TEXT NOT NULL, -- trades_count, net_pnl, win_rate, max_risk, discipline_score, streak_days, payout
        target_value REAL NOT NULL,
        current_value REAL DEFAULT 0.0,
        period TEXT DEFAULT 'monthly', -- daily, weekly, monthly, challenge, milestone
        deadline TEXT DEFAULT '',
        status TEXT DEFAULT 'in_progress', -- in_progress, achieved, expired
        notes TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )
    """)

    # Settings table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
    """)

    # Indexes for performance
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_account ON trades(account_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_close_time ON trades(close_time)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_instrument ON trades(instrument)")

    conn.commit()

    # Initialize default settings if not existing
    default_settings = {
        "app_name": "TradeVault",
        "currency": "USD",
        "currency_symbol": "$",
        "timezone": "UTC",
        "theme": "charcoal",
        "default_risk_pct": "1.0",
        "gemini_api_key": "",
        "openai_api_key": "",
        "ai_provider": "gemini", # gemini or openai
        "demo_mode": "false"
    }
    for k, v in default_settings.items():
        cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
    conn.commit()
    conn.close()

def get_setting(key, default=None):
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default

def set_setting(key, value):
    conn = get_connection()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()

def get_all_settings():
    conn = get_connection()
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    conn.close()
    return {row["key"]: row["value"] for row in rows}

def update_account_balance(account_id):
    """Recalculate account balance and equity based on starting balance + sum of net P/L of trades"""
    if not account_id:
        return
    conn = get_connection()
    account = conn.execute("SELECT starting_balance FROM accounts WHERE id = ?", (account_id,)).fetchone()
    if not account:
        conn.close()
        return
    start = account["starting_balance"]
    pnl_sum = conn.execute("SELECT COALESCE(SUM(net_pnl), 0) as total FROM trades WHERE account_id = ?", (account_id,)).fetchone()["total"]
    new_bal = round(start + pnl_sum, 2)
    conn.execute("UPDATE accounts SET current_balance = ?, current_equity = ?, updated_at = ? WHERE id = ?", 
                 (new_bal, new_bal, datetime.utcnow().isoformat(), account_id))
    conn.commit()
    conn.close()

def seed_demo_data():
    """Seed realistic prop-firm accounts, strategies, trades, and goals"""
    conn = get_connection()
    cursor = conn.cursor()

    # Check if trades already exist
    existing_trades = cursor.execute("SELECT COUNT(*) as count FROM trades").fetchone()["count"]
    if existing_trades > 0:
        conn.close()
        return False

    now = datetime.utcnow()

    # 1. Accounts
    acc1_id = "acc_ftmo_100k"
    acc2_id = "acc_fundednext_50k"
    acc3_id = "acc_personal_live"

    accounts_data = [
        (acc1_id, "FTMO 100K Challenge", "FTMO", "funded_challenge", 100000.0, 100000.0, 100000.0, "USD", 10.0, 5.0, 10.0, "balance_based", "Phase 1", "active", now.isoformat(), now.isoformat()),
        (acc2_id, "FundedNext Stellar 50K", "FundedNext", "funded_challenge", 50000.0, 50000.0, 50000.0, "USD", 8.0, 5.0, 10.0, "equity_based", "Phase 2", "active", now.isoformat(), now.isoformat()),
        (acc3_id, "IC Markets Raw ECN", "IC Markets", "personal_live", 15000.0, 15000.0, 15000.0, "USD", 0.0, 3.0, 15.0, "balance_based", "Live", "active", now.isoformat(), now.isoformat())
    ]
    cursor.executemany("""
    INSERT OR REPLACE INTO accounts 
    (id, name, broker, account_type, starting_balance, current_balance, current_equity, currency, profit_target_pct, max_daily_loss_pct, max_total_loss_pct, drawdown_type, phase, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, accounts_data)

    # 2. Strategies
    strat1_id = "strat_liquidity_sweep"
    strat2_id = "strat_london_breakout"
    strat3_id = "strat_fvg_retest"
    strat4_id = "strat_trend_pullback"

    strategies_data = [
        (strat1_id, "ICT Liquidity Sweep + MSS", "Asia high/low liquidity grabs with Market Structure Shift on 1m/5m", "Sweep, MSS, FVG Entry", "#10b981", now.isoformat()),
        (strat2_id, "London Open Breakout", "Asian range expansion breakout during London Killzone (07:00-09:00 UTC)", "Session High/Low Breakout", "#3b82f6", now.isoformat()),
        (strat3_id, "Fair Value Gap (FVG) Retest", "Institutional order flow imbalance fill with 15m confluence", "FVG Mitigation, Orderblock", "#8b5cf6", now.isoformat()),
        (strat4_id, "H4 Trend Pullback", "Higher timeframe trend continuation with EMA dynamic support", "EMA 21/50 Pullback", "#f59e0b", now.isoformat())
    ]
    cursor.executemany("""
    INSERT OR REPLACE INTO strategies (id, name, description, setup_types, color, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    """, strategies_data)

    # 3. Realistic Demo Trades spanning the last 20 days
    demo_trades = [
        # (ticket, acc, strat, inst, side, lot, entry, exit, sl, tp, gross, comm, swap, net, risk_amt, risk_pct, plan_rr, act_rr, session, setup, condition, entry_r, exit_r, emotion, disc, mistakes, lessons, notes, days_ago, hour, dur_min)
        ("T-908121", acc1_id, strat1_id, "XAUUSD", "BUY", 2.0, 2680.50, 2701.20, 2673.00, 2705.00, 4140.00, 14.00, -3.50, 4122.50, 1500.0, 1.5, 3.2, 2.76, "New York", "Asia Low Sweep + MSS", "Trending", "Clean Asian liquidity sweep and 5m market structure shift", "Target reached ahead of FOMC news release", "Disciplined", 5, "None", "Patience paid off; held through minor consolidation", "Textbook execution", 19, 14, 85),
        ("T-908182", acc1_id, strat2_id, "EURUSD", "SELL", 5.0, 1.08950, 1.08620, 1.09100, 1.08500, 1650.00, 25.00, 0.00, 1625.00, 750.0, 0.75, 3.0, 2.2, "London", "London Breakout", "Trending", "London open broke Asian low with heavy volume", "Closed before NY pre-market chop", "Confident", 5, "None", "London session momentum was strong", "Good runner", 18, 8, 120),
        ("T-908254", acc1_id, strat3_id, "US30", "BUY", 1.5, 42800.0, 42720.0, 42740.0, 43050.0, -1200.00, 12.00, 0.00, -1212.00, 900.0, 0.9, 4.1, -1.35, "New York", "15m FVG Entry", "High Volatility", "Attempted to catch pullback into 15m FVG", "Hit stop loss as indices flushed lower", "Anxious", 4, "None", "Always wait for rejection candle before clicking buy", "Acceptable loss within plan", 17, 15, 40),
        ("T-908311", acc1_id, strat1_id, "GBPUSD", "BUY", 4.0, 1.30150, 1.30650, 1.29950, 1.30700, 2000.00, 20.00, -2.10, 1977.90, 800.0, 0.8, 2.75, 2.5, "London/NY Overlap", "Liquidity Sweep", "Trending", "Rejection of key 4H demand zone", "Take profit nearly hit, closed manually at resistance", "Disciplined", 5, "None", "Clean follow-through after CPI cooldown", "Solid execution", 16, 13, 95),
        ("T-908402", acc1_id, strat4_id, "NAS100", "SELL", 2.0, 20450.0, 20510.0, 20490.0, 20300.0, -1200.00, 15.00, 0.00, -1215.00, 800.0, 0.8, 3.75, -1.5, "New York", "EMA 21 Pullback", "Ranging", "Trend continuation attempt", "Stopped out on tech sector bounce", "Disciplined", 4, "None", "Market was ranging, not trending; check HTF first", "Good risk management", 15, 16, 50),
        ("T-908499", acc1_id, strat1_id, "XAUUSD", "SELL", 2.5, 2724.80, 2704.00, 2731.50, 2695.00, 5200.00, 17.50, -5.20, 5177.30, 1675.0, 1.6, 4.4, 3.11, "New York", "Asia High Sweep + FVG", "High Volatility", "Liquidity sweep of psychological 2725 level with bearish engulfing", "Secured partials and trailed stop to target", "Disciplined", 5, "None", "High probability setup during NY open peak volume", "Best trade of the week", 14, 14, 110),
        ("T-908581", acc2_id, strat2_id, "GBPUSD", "SELL", 3.0, 1.30820, 1.30400, 1.31050, 1.30200, 1260.00, 15.00, 0.00, 1245.00, 690.0, 1.38, 2.7, 1.83, "London", "London Killzone Breakout", "Trending", "Asian consolidation breakdown", "Secured profits ahead of UK press briefing", "Confident", 5, "None", "Strict adherence to entry checklist", "FTMO Phase 2 progressing well", 13, 9, 75),
        ("T-908643", acc2_id, strat1_id, "EURUSD", "BUY", 4.0, 1.08450, 1.08250, 1.08250, 1.08900, -800.00, 20.00, 0.00, -820.00, 800.0, 1.6, 2.25, -1.0, "London", "London Low Sweep", "Ranging", "Believed bottom was in after overnight drop", "Full stop loss taken without hesitation", "Disciplined", 5, "None", "Clean stop, no slippage, no tilt", "Controlled loss", 12, 10, 35),
        ("T-908712", acc2_id, strat3_id, "XAUUSD", "BUY", 1.5, 2710.00, 2728.50, 2703.50, 2735.00, 2775.00, 10.50, -2.40, 2762.10, 975.0, 1.95, 3.8, 2.85, "New York", "15m FVG Retest", "Trending", "Mitigation of morning NY FVG", "Exited into 4H liquidity pool", "Confident", 5, "None", "Multi-timeframe alignment gives immense confidence", "Solid win", 11, 15, 60),
        ("T-908790", acc1_id, strat1_id, "US30", "SELL", 2.0, 43150.0, 42920.0, 43230.0, 42800.0, 4600.00, 18.00, 0.00, 4582.00, 1600.0, 1.6, 4.37, 2.88, "New York", "All-Time High Sweep", "Trending", "Failed breakout above ATH with aggressive sell divergence", "Scaled out into pre-close session", "Disciplined", 5, "None", "Patience waiting for the confirmation candle was key", "Outstanding R-multiple", 10, 16, 90),
        ("T-908855", acc1_id, strat4_id, "EURUSD", "BUY", 6.0, 1.08300, 1.08180, 1.08150, 1.08750, -720.00, 30.00, -1.50, -751.50, 900.0, 0.9, 3.0, -0.83, "London", "H4 Pullback", "Ranging", "Testing previous day high flip to support", "Divergence invalidated, cut loss before full SL", "Disciplined", 4, "Early Exit", "Cutting early saved 15 pips, but was it emotional?", "Review trade recording", 9, 11, 45),
        ("T-908920", acc1_id, strat1_id, "XAUUSD", "SELL", 2.0, 2735.00, 2715.00, 2742.00, 2700.00, 4000.00, 14.00, -4.00, 3982.00, 1400.0, 1.4, 5.0, 2.86, "London/NY Overlap", "Sweep of NY High", "Trending", "Clean bear pin bar at psychological 2735 resistance", "Closed into London fix", "Confident", 5, "None", "Consistent execution of the A+ setup", "Smooth ride", 8, 14, 105),
        ("T-909015", acc2_id, strat2_id, "GBPUSD", "BUY", 3.5, 1.30500, 1.30900, 1.30250, 1.31200, 1400.00, 17.50, 0.00, 1382.50, 875.0, 1.75, 2.8, 1.6, "London", "London Continuation", "Trending", "Break and retest of Asian session high", "Target 1 hit, closed remainder ahead of Fed speech", "Disciplined", 5, "None", "Always protect capital before high-impact events", "Well played", 7, 9, 65),
        ("T-909104", acc1_id, strat3_id, "NAS100", "SELL", 2.5, 20680.0, 20755.0, 20740.0, 20500.0, -1875.00, 20.00, 0.00, -1895.00, 1500.0, 1.5, 3.0, -1.26, "New York", "Overnight FVG", "High Volatility", "Anticipating market reversal at open", "Slipped stop loss due to opening bell spread widen", "Anxious", 3, "Chasing, High Volatility Open", "Do NOT enter within first 5 minutes of NY market open", "Hard lesson learned on spreads", 6, 14, 25),
        ("T-909180", acc1_id, strat1_id, "XAUUSD", "BUY", 2.2, 2715.50, 2738.00, 2708.00, 2745.00, 4950.00, 15.40, -4.20, 4930.40, 1650.0, 1.65, 3.93, 3.0, "London/NY Overlap", "Demand Sweep + Displacement", "Trending", "Aggressive displacement candle on 5m chart after US PPI data", "Exited at key liquidity level", "Disciplined", 5, "None", "Letting winners run according to the rules", "Flawless trade", 5, 13, 80),
        ("T-909240", acc3_id, strat4_id, "BTCUSD", "BUY", 0.5, 67200.0, 68900.0, 66400.0, 69500.0, 850.00, 5.00, 0.00, 845.00, 400.0, 2.66, 2.87, 2.12, "Asia", "Daily EMA bounce", "Trending", "Clean daily breakout retest with volume spike", "Target reached over weekend", "Confident", 5, "None", "Crypto swings work great on 4H/Daily timeframes", "Profitable swing", 4, 3, 1400),
        ("T-909301", acc1_id, strat1_id, "EURUSD", "SELL", 5.0, 1.08700, 1.08320, 1.08880, 1.08100, 1900.00, 25.00, 0.00, 1875.00, 900.0, 0.9, 3.33, 2.11, "London", "Asia High Sweep", "Trending", "Rejection of key daily supply zone during Frankfurt open", "Exited at London midday stall", "Disciplined", 5, "None", "Clean execution, followed system without hesitation", "System works", 3, 8, 90),
        ("T-909375", acc1_id, strat2_id, "US30", "BUY", 1.5, 43200.0, 43100.0, 43110.0, 43450.0, -1500.00, 15.00, 0.00, -1515.00, 1350.0, 1.35, 2.77, -1.12, "New York", "Opening Breakout", "Ranging", "Tried to trade index breakout without waiting for pullback", "Stop out on fakeout wick", "Hesitant", 3, "Chasing", "Patience! Fakeouts are common on US30 open", "Wait for the 15m close", 2, 14, 30),
        ("T-909450", acc1_id, strat1_id, "XAUUSD", "BUY", 2.0, 2730.00, 2751.50, 2723.00, 2760.00, 4300.00, 14.00, -3.80, 4282.20, 1400.0, 1.4, 4.28, 3.07, "New York", "London Low Sweep", "Trending", "Swept London lows during NY premarket, strong reversal print", "Secured full profit before weekend close", "Disciplined", 5, "None", "Classic Friday afternoon squeeze; held conviction", "FTMO Target Reached!", 1, 15, 115)
    ]

    for t in demo_trades:
        ticket, acc, strat, inst, side, lot, entry, exit, sl, tp, gross, comm, swap, net, risk_amt, risk_pct, plan_rr, act_rr, session, setup, condition, entry_r, exit_r, emotion, disc, mistakes, lessons, notes, days_ago, hour, dur_min = t
        
        trade_date = now - timedelta(days=days_ago)
        open_dt = trade_date.replace(hour=hour, minute=15, second=0)
        close_dt = open_dt + timedelta(minutes=dur_min)

        trade_id = str(uuid.uuid4())
        cursor.execute("""
        INSERT INTO trades (
            id, ticket_id, account_id, strategy_id, instrument, side, lot_size, entry_price, exit_price,
            stop_loss, take_profit, gross_pnl, commission, swap, net_pnl, risk_amount, risk_pct,
            planned_rr, actual_rr, session, setup_type, market_condition, entry_reason, exit_reason,
            emotional_state, discipline_rating, mistakes, lessons, notes, screenshots,
            open_time, close_time, status, is_imported, import_source, import_confidence, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            trade_id, ticket, acc, strat, inst, side, lot, entry, exit,
            sl, tp, gross, comm, swap, net, risk_amt, risk_pct,
            plan_rr, act_rr, session, setup, condition, entry_r, exit_r,
            emotion, disc, mistakes, lessons, notes, '[]',
            open_dt.isoformat(), close_dt.isoformat(), "CLOSED", 0, "manual", "high",
            open_dt.isoformat(), close_dt.isoformat()
        ))

    # 4. Goals
    goals_data = [
        (str(uuid.uuid4()), "Journal 50 Completed Trades", "trades_count", 50.0, 19.0, "monthly", (now + timedelta(days=15)).strftime("%Y-%m-%d"), "in_progress", "Consistent journaling builds statistical confidence", now.isoformat()),
        (str(uuid.uuid4()), "Maintain Discipline Rating >= 4.5", "discipline_score", 4.5, 4.65, "monthly", (now + timedelta(days=30)).strftime("%Y-%m-%d"), "achieved", "Follow trading rules strictly on every trade", now.isoformat()),
        (str(uuid.uuid4()), "Pass FTMO Phase 1 ($10,000 Target)", "net_pnl", 10000.0, 12853.50, "challenge", (now + timedelta(days=10)).strftime("%Y-%m-%d"), "achieved", "Target reached with controlled risk under 1.7% per trade", now.isoformat()),
        (str(uuid.uuid4()), "Never Exceed 2% Risk Per Trade", "max_risk", 2.0, 1.95, "monthly", (now + timedelta(days=30)).strftime("%Y-%m-%d"), "in_progress", "Prop firm risk compliance", now.isoformat()),
        (str(uuid.uuid4()), "10 Consecutive Plan Following Days", "streak_days", 10.0, 7.0, "monthly", (now + timedelta(days=20)).strftime("%Y-%m-%d"), "in_progress", "No unplanned impulsive entries", now.isoformat())
    ]
    cursor.executemany("""
    INSERT INTO goals (id, title, target_type, target_value, current_value, period, deadline, status, notes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, goals_data)

    conn.commit()
    conn.close()

    # Recalculate account balances
    update_account_balance(acc1_id)
    update_account_balance(acc2_id)
    update_account_balance(acc3_id)
    return True

if __name__ == "__main__":
    init_db()
    seed_demo_data()
    print("Database initialized and seeded successfully.")
