"""
TradeVault AI Trading Coach Engine
Analyzes closed trades, journal notes, discipline ratings, emotional states,
recurring mistakes, and risk deviations to provide objective, data-driven feedback.
"""

import json
from collections import defaultdict
from datetime import datetime

def generate_coach_analysis(trades, strategies_map, accounts_map, api_key=None, ai_provider="gemini"):
    """
    Performs comprehensive quantitative pattern mining on actual trade history:
    - Recurring mistake financial toll
    - Discipline rating vs P/L correlation
    - Emotional state outcome distribution
    - Session and Instrument edge discovery
    - Risk compliance & planned vs actual R-multiple execution
    - Data-grounded self-review questions
    """
    sample_size = len(trades)
    if sample_size == 0:
        return {
            "sample_size": 0,
            "sample_note": "No trades recorded yet. Journal at least 10 trades to unlock AI Trading Coach analysis.",
            "overall_summary": "Awaiting trade data to begin pattern recognition.",
            "mistake_analysis": [],
            "discipline_correlation": {},
            "session_analysis": {},
            "emotional_analysis": {},
            "risk_compliance": {},
            "coaching_questions": [
                "What is your core setup and what specific market condition does it exploit?",
                "What is your maximum permitted loss for a single trading day?"
            ]
        }

    # 1. Sample Size Note
    if sample_size < 15:
        sample_note = f"Sample size: {sample_size} trades. (Early Sample: Patterns indicate current habits but have high statistical variance. Continue journaling to confirm true edge.)"
    elif sample_size < 40:
        sample_note = f"Sample size: {sample_size} trades. (Developing Sample: Sufficient to identify recurring behavioral leaks and session tendencies.)"
    else:
        sample_note = f"Sample size: {sample_size} trades. (Robust Sample: Statistically meaningful dataset for strategy and execution optimization.)"

    # 2. Mistakes Financial Toll
    mistake_stats = defaultdict(lambda: {"count": 0, "total_loss": 0.0, "trades": []})
    clean_trades_pnl = 0.0
    clean_trades_count = 0

    for t in trades:
        m_str = t.get("mistakes", "")
        pnl = t.get("net_pnl", 0.0)
        has_mistake = False
        if m_str and m_str.strip().lower() not in ("none", ""):
            for m in m_str.split(","):
                m_clean = m.strip()
                if m_clean and m_clean.lower() != "none":
                    has_mistake = True
                    mistake_stats[m_clean]["count"] += 1
                    if pnl < 0:
                        mistake_stats[m_clean]["total_loss"] += abs(pnl)
                    mistake_stats[m_clean]["trades"].append(t.get("ticket_id") or t["id"][:6])
        if not has_mistake:
            clean_trades_count += 1
            clean_trades_pnl += pnl

    mistake_list = []
    for m_name, d in mistake_stats.items():
        mistake_list.append({
            "mistake": m_name,
            "frequency": d["count"],
            "total_capital_lost": round(d["total_loss"], 2),
            "pct_of_sample": round((d["count"] / sample_size) * 100, 1),
            "trade_tickets": d["trades"][:4]
        })
    mistake_list = sorted(mistake_list, key=lambda x: x["total_capital_lost"], reverse=True)

    # 3. Discipline Rating vs Net P/L
    high_disc = [t for t in trades if t.get("discipline_rating", 5) >= 4] # 4-5 stars
    low_disc = [t for t in trades if t.get("discipline_rating", 5) < 4]   # 1-3 stars

    high_disc_wins = len([t for t in high_disc if t.get("net_pnl", 0) > 0])
    low_disc_wins = len([t for t in low_disc if t.get("net_pnl", 0) > 0])

    discipline_correlation = {
        "high_discipline": {
            "label": "High Discipline (4-5 Stars)",
            "count": len(high_disc),
            "win_rate": round((high_disc_wins / len(high_disc)) * 100, 1) if high_disc else 0.0,
            "net_pnl": round(sum(t.get("net_pnl", 0) for t in high_disc), 2),
            "avg_pnl": round(sum(t.get("net_pnl", 0) for t in high_disc) / len(high_disc), 2) if high_disc else 0.0
        },
        "low_discipline": {
            "label": "Impaired Discipline (1-3 Stars)",
            "count": len(low_disc),
            "win_rate": round((low_disc_wins / len(low_disc)) * 100, 1) if low_disc else 0.0,
            "net_pnl": round(sum(t.get("net_pnl", 0) for t in low_disc), 2),
            "avg_pnl": round(sum(t.get("net_pnl", 0) for t in low_disc) / len(low_disc), 2) if low_disc else 0.0
        }
    }

    # 4. Emotional State Outcomes
    emotional_groups = defaultdict(lambda: {"count": 0, "net_pnl": 0.0, "wins": 0})
    for t in trades:
        emo = t.get("emotional_state") or "Disciplined"
        pnl = t.get("net_pnl", 0.0)
        emotional_groups[emo]["count"] += 1
        emotional_groups[emo]["net_pnl"] += pnl
        if pnl > 0:
            emotional_groups[emo]["wins"] += 1

    formatted_emotional = {}
    for emo, d in emotional_groups.items():
        formatted_emotional[emo] = {
            "count": d["count"],
            "net_pnl": round(d["net_pnl"], 2),
            "win_rate": round((d["wins"] / d["count"]) * 100, 1) if d["count"] > 0 else 0.0
        }

    # 5. Session Edge Analysis
    session_groups = defaultdict(lambda: {"count": 0, "net_pnl": 0.0, "wins": 0})
    for t in trades:
        sess = t.get("session") or "Other"
        pnl = t.get("net_pnl", 0.0)
        session_groups[sess]["count"] += 1
        session_groups[sess]["net_pnl"] += pnl
        if pnl > 0:
            session_groups[sess]["wins"] += 1

    formatted_sessions = {}
    for sess, d in session_groups.items():
        formatted_sessions[sess] = {
            "count": d["count"],
            "net_pnl": round(d["net_pnl"], 2),
            "win_rate": round((d["wins"] / d["count"]) * 100, 1) if d["count"] > 0 else 0.0
        }

    # 6. Risk Compliance (Planned vs Actual)
    risk_violations = []
    for t in trades:
        risk_pct = float(t.get("risk_pct") or 0.0)
        if risk_pct > 2.0:
            risk_violations.append({
                "ticket": t.get("ticket_id") or t["id"][:6],
                "risk_pct": risk_pct,
                "net_pnl": t.get("net_pnl", 0.0),
                "instrument": t.get("instrument", "")
            })

    total_net = sum(t.get("net_pnl", 0) for t in trades)
    win_cnt = len([t for t in trades if t.get("net_pnl", 0) > 0])
    overall_win_rate = round((win_cnt / sample_size) * 100, 1)

    # 7. Tailored Self-Review Coaching Questions
    coaching_questions = []
    if mistake_list:
        top_m = mistake_list[0]["mistake"]
        top_loss = mistake_list[0]["total_capital_lost"]
        coaching_questions.append(
            f"Your most expensive execution leak is '{top_m}', costing ${top_loss} across {mistake_list[0]['frequency']} trades. What physical or mental trigger occurs immediately before you make this error?"
        )

    if low_disc and discipline_correlation["low_discipline"]["net_pnl"] < discipline_correlation["high_discipline"]["net_pnl"]:
        coaching_questions.append(
            f"Your trades executed with 4-5 star discipline yielded ${discipline_correlation['high_discipline']['net_pnl']} vs ${discipline_correlation['low_discipline']['net_pnl']} on lower discipline trades. What specific rule in your pre-trade checklist would eliminate the low-discipline trades?"
        )

    best_sess = max(formatted_sessions.items(), key=lambda x: x[1]["net_pnl"])[0] if formatted_sessions else "London"
    worst_sess = min(formatted_sessions.items(), key=lambda x: x[1]["net_pnl"])[0] if formatted_sessions else "Asia"
    if best_sess != worst_sess and formatted_sessions.get(worst_sess, {}).get("net_pnl", 0) < 0:
        coaching_questions.append(
            f"You hold a clear edge during '{best_sess}' (P/L: ${formatted_sessions[best_sess]['net_pnl']}), but are giving capital back during '{worst_sess}' (P/L: ${formatted_sessions[worst_sess]['net_pnl']}). Should you temporarily ban trading outside your primary session?"
        )

    coaching_questions.append(
        "Are your losses closed mechanically at your predetermined stop loss, or did any losses expand due to moving stops or hope-based holding?"
    )

    # 8. Executive Synthesis
    synthesis = (
        f"Based on {sample_size} journaled trades, your overall net performance is ${round(total_net, 2)} with a {overall_win_rate}% win rate. "
        f"Execution adherence directly dictates your P/L: high-discipline trades (4-5 stars) generated ${discipline_correlation['high_discipline']['net_pnl']}, "
        f"whereas discipline slip-ups resulted in ${discipline_correlation['low_discipline']['net_pnl']}. "
        f"Eliminating your top execution leak ('{mistake_list[0]['mistake'] if mistake_list else 'Chasing'}') would have preserved substantial trading capital."
    )

    return {
        "sample_size": sample_size,
        "sample_note": sample_note,
        "overall_summary": synthesis,
        "total_net_pnl": round(total_net, 2),
        "overall_win_rate": overall_win_rate,
        "mistake_analysis": mistake_list,
        "discipline_correlation": discipline_correlation,
        "session_analysis": formatted_sessions,
        "emotional_analysis": formatted_emotional,
        "risk_violations_count": len(risk_violations),
        "risk_violations": risk_violations,
        "coaching_questions": coaching_questions
    }
