/**
 * TradeVault Trades Log View Controller
 * Interactive table, sorting, filtering, detail viewer, duplicate, and deletion.
 */

window.TradesView = {
  trades: [],
  filteredTrades: [],
  currentPage: 1,
  pageSize: 15,
  currentSort: { field: 'close_time', asc: false },

  async load() {
    this.setupListeners();
    await this.fetchTrades();
  },

  setupListeners() {
    const searchInput = document.getElementById('trades-search');
    if (searchInput && !searchInput.dataset.bound) {
      searchInput.dataset.bound = 'true';
      searchInput.addEventListener('input', () => this.applyFilters());
    }

    const filterSide = document.getElementById('trades-filter-side');
    if (filterSide && !filterSide.dataset.bound) {
      filterSide.dataset.bound = 'true';
      filterSide.addEventListener('change', () => this.applyFilters());
    }

    const filterOutcome = document.getElementById('trades-filter-outcome');
    if (filterOutcome && !filterOutcome.dataset.bound) {
      filterOutcome.dataset.bound = 'true';
      filterOutcome.addEventListener('change', () => this.applyFilters());
    }

    const filterSession = document.getElementById('trades-filter-session');
    if (filterSession && !filterSession.dataset.bound) {
      filterSession.dataset.bound = 'true';
      filterSession.addEventListener('change', () => this.applyFilters());
    }
  },

  async fetchTrades() {
    try {
      const params = {};
      if (App.activeAccountId) params.account_id = App.activeAccountId;
      const res = await API.getTrades(params);
      this.trades = res.trades || [];
      this.applyFilters();
    } catch (err) {
      App.showToast("Failed to load trades: " + err.message, "error");
    }
  },

  applyFilters() {
    const search = (document.getElementById('trades-search')?.value || '').toLowerCase();
    const side = document.getElementById('trades-filter-side')?.value || '';
    const outcome = document.getElementById('trades-filter-outcome')?.value || '';
    const session = document.getElementById('trades-filter-session')?.value || '';

    this.filteredTrades = this.trades.filter(t => {
      if (side && t.side !== side) return false;
      if (session && t.session !== session) return false;
      if (outcome === 'win' && t.net_pnl <= 0) return false;
      if (outcome === 'loss' && t.net_pnl >= 0) return false;
      if (outcome === 'be' && t.net_pnl !== 0) return false;

      if (search) {
        const matchesTicket = (t.ticket_id || '').toLowerCase().includes(search);
        const matchesInst = (t.instrument || '').toLowerCase().includes(search);
        const matchesNotes = (t.notes || '').toLowerCase().includes(search);
        const matchesSetup = (t.setup_type || '').toLowerCase().includes(search);
        if (!matchesTicket && !matchesInst && !matchesNotes && !matchesSetup) return false;
      }
      return true;
    });

    this.sortTrades();
    this.renderTable();
  },

  sortTrades() {
    const { field, asc } = this.currentSort;
    this.filteredTrades.sort((a, b) => {
      let vA = a[field];
      let vB = b[field];
      if (typeof vA === 'string') vA = vA.toLowerCase();
      if (typeof vB === 'string') vB = vB.toLowerCase();
      if (vA < vB) return asc ? -1 : 1;
      if (vA > vB) return asc ? 1 : -1;
      return 0;
    });
  },

  setSort(field) {
    if (this.currentSort.field === field) {
      this.currentSort.asc = !this.currentSort.asc;
    } else {
      this.currentSort.field = field;
      this.currentSort.asc = false;
    }
    this.sortTrades();
    this.renderTable();
  },

  renderTable() {
    const tbody = document.getElementById('trades-table-body');
    const countEl = document.getElementById('trades-count-display');
    if (!tbody) return;

    if (countEl) {
      countEl.textContent = `Showing ${this.filteredTrades.length} of ${this.trades.length} trades`;
    }

    tbody.innerHTML = '';
    if (this.filteredTrades.length === 0) {
      tbody.innerHTML = `<tr><td colspan="11" style="text-align: center; color: var(--text-muted); padding: 30px;">No trades found matching current criteria.</td></tr>`;
      return;
    }

    const startIdx = (this.currentPage - 1) * this.pageSize;
    const pageTrades = this.filteredTrades.slice(startIdx, startIdx + this.pageSize);

    pageTrades.forEach(t => {
      const tr = document.createElement('tr');
      const isWin = t.net_pnl > 0;
      const isLoss = t.net_pnl < 0;

      const pnlHtml = App.formatPnL(t.net_pnl);
      const sideClass = t.side === 'BUY' ? 'badge-profit' : 'badge-loss';
      const rrHtml = t.actual_rr ? `<span class="badge-neutral font-mono">${t.actual_rr > 0 ? '+' : ''}${t.actual_rr}R</span>` : '-';
      const dtStr = (t.close_time || t.open_time || '').replace('T', ' ').substring(0, 16);

      tr.innerHTML = `
        <td class="font-mono text-muted" style="font-size: 11px;">${t.ticket_id || '#' + t.id.substring(0, 6)}</td>
        <td class="font-mono" style="font-size: 11px;">${dtStr}</td>
        <td><strong class="font-mono" style="color: #fff;">${t.instrument}</strong></td>
        <td><span class="${sideClass}">${t.side}</span></td>
        <td class="font-mono">${t.lot_size}</td>
        <td class="font-mono">${t.entry_price} → ${t.exit_price}</td>
        <td>${pnlHtml}</td>
        <td>${rrHtml}</td>
        <td><span class="badge-neutral">${t.session || 'London'}</span></td>
        <td style="max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px;" class="text-muted">
          ${t.mistakes && t.mistakes !== 'None' ? `<span class="badge-warning">${t.mistakes}</span>` : (t.setup_type || '-')}
        </td>
        <td>
          <div style="display: flex; gap: 6px;">
            <button class="btn btn-secondary btn-sm btn-icon" onclick="TradesView.viewDetails('${t.id}')" title="View Trade Details">👁️</button>
            <button class="btn btn-secondary btn-sm btn-icon" onclick="TradesView.duplicate('${t.id}')" title="Duplicate Trade">📋</button>
            <button class="btn btn-secondary btn-sm btn-icon" onclick="TradesView.delete('${t.id}')" title="Delete Trade" style="color: var(--loss);">🗑️</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

    this.renderPagination();
  },

  renderPagination() {
    const totalPages = Math.ceil(this.filteredTrades.length / this.pageSize) || 1;
    const paginationEl = document.getElementById('trades-pagination');
    if (!paginationEl) return;

    paginationEl.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 0;">
        <span style="font-size: 12px; color: var(--text-muted);">Page ${this.currentPage} of ${totalPages}</span>
        <div style="display: flex; gap: 8px;">
          <button class="btn btn-secondary btn-sm" ${this.currentPage <= 1 ? 'disabled' : ''} onclick="TradesView.changePage(${this.currentPage - 1})">Prev</button>
          <button class="btn btn-secondary btn-sm" ${this.currentPage >= totalPages ? 'disabled' : ''} onclick="TradesView.changePage(${this.currentPage + 1})">Next</button>
        </div>
      </div>
    `;
  },

  changePage(newPage) {
    this.currentPage = newPage;
    this.renderTable();
  },

  async viewDetails(tradeId) {
    try {
      const res = await API.getTrade(tradeId);
      const t = res.trade;
      const modal = document.getElementById('trade-detail-modal');
      const body = document.getElementById('trade-detail-body');
      if (!modal || !body) return;

      const pnlHtml = App.formatPnL(t.net_pnl);
      const discStars = '★'.repeat(t.discipline_rating || 5) + '☆'.repeat(5 - (t.discipline_rating || 5));

      body.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 20px;">
          <div>
            <div class="text-muted" style="font-size: 11px;">INSTRUMENT & DIRECTION</div>
            <div style="font-size: 18px; font-weight: 800; color: #fff;">${t.instrument} <span class="${t.side === 'BUY' ? 'badge-profit' : 'badge-loss'}">${t.side}</span></div>
            <div class="text-muted font-mono" style="font-size: 12px; margin-top: 4px;">Ticket: ${t.ticket_id || 'N/A'} | Lots: ${t.lot_size}</div>
          </div>
          <div style="text-align: right;">
            <div class="text-muted" style="font-size: 11px;">NET REALIZED P/L</div>
            <div style="font-size: 22px; font-weight: 800;">${pnlHtml}</div>
            <div class="font-mono text-muted" style="font-size: 12px; margin-top: 4px;">Gross: $${t.gross_pnl} | Comm: $${t.commission} | Swap: $${t.swap}</div>
          </div>
        </div>

        <div style="background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 12px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px;" class="font-mono">
          <div><span class="text-muted" style="font-size: 10px; display: block;">ENTRY</span><strong>${t.entry_price}</strong></div>
          <div><span class="text-muted" style="font-size: 10px; display: block;">EXIT</span><strong>${t.exit_price}</strong></div>
          <div><span class="text-muted" style="font-size: 10px; display: block;">STOP LOSS</span><strong>${t.stop_loss || 'None'}</strong></div>
          <div><span class="text-muted" style="font-size: 10px; display: block;">TAKE PROFIT</span><strong>${t.take_profit || 'None'}</strong></div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px;">
          <div>
            <span class="text-muted" style="font-size: 10px; display: block;">ACTUAL R-MULTIPLE</span>
            <strong class="font-mono" style="font-size: 16px;">${t.actual_rr ? t.actual_rr + 'R' : 'N/A'}</strong>
          </div>
          <div>
            <span class="text-muted" style="font-size: 10px; display: block;">DISCIPLINE RATING</span>
            <strong style="color: #f59e0b; font-size: 14px;">${discStars} (${t.discipline_rating || 5}/5)</strong>
          </div>
          <div>
            <span class="text-muted" style="font-size: 10px; display: block;">EMOTIONAL STATE</span>
            <span class="badge-neutral">${t.emotional_state || 'Disciplined'}</span>
          </div>
        </div>

        <div style="margin-bottom: 16px;">
          <strong style="font-size: 12px; color: #fff; display: block; margin-bottom: 4px;">Setup & Entry Reason:</strong>
          <div style="background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px; font-size: 12px;">
            ${t.entry_reason || 'No entry notes specified.'}
          </div>
        </div>

        <div style="margin-bottom: 16px;">
          <strong style="font-size: 12px; color: #fff; display: block; margin-bottom: 4px;">Exit Reason:</strong>
          <div style="background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px; font-size: 12px;">
            ${t.exit_reason || 'Closed according to plan.'}
          </div>
        </div>

        ${t.mistakes && t.mistakes !== 'None' ? `
          <div style="margin-bottom: 16px;">
            <strong style="font-size: 12px; color: var(--loss); display: block; margin-bottom: 4px;">Mistakes Made:</strong>
            <span class="badge-loss">${t.mistakes}</span>
          </div>
        ` : ''}

        ${t.lessons ? `
          <div style="margin-bottom: 16px;">
            <strong style="font-size: 12px; color: #10b981; display: block; margin-bottom: 4px;">Lessons Learned:</strong>
            <div style="background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px; font-size: 12px;">
              ${t.lessons}
            </div>
          </div>
        ` : ''}
      `;

      modal.classList.add('active');
    } catch (err) {
      App.showToast("Error loading trade: " + err.message, "error");
    }
  },

  async duplicate(tradeId) {
    if (!confirm("Duplicate this trade record?")) return;
    try {
      await API.duplicateTrade(tradeId);
      App.showToast("Trade duplicated successfully", "success");
      await this.fetchTrades();
    } catch (err) {
      App.showToast("Error duplicating trade: " + err.message, "error");
    }
  },

  async delete(tradeId) {
    if (!confirm("Are you sure you want to permanently delete this trade from your journal?")) return;
    try {
      await API.deleteTrade(tradeId);
      App.showToast("Trade deleted successfully", "success");
      await this.fetchTrades();
    } catch (err) {
      App.showToast("Error deleting trade: " + err.message, "error");
    }
  }
};
