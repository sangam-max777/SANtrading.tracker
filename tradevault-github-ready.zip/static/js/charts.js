/**
 * TradeVault Interactive Canvas Chart Engine
 * Ultra-performance charts with crosshairs, glow gradients, and live hover tooltips.
 */

window.Charts = {
  activeTooltips: {},

  setupCanvas(canvas) {
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    return { ctx, width: rect.width, height: rect.height };
  },

  drawEquityCurve(canvasId, data) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !data || data.length === 0) return;

    // Cache data for mousemove crosshair
    canvas._equityData = data;

    const { ctx, width, height } = this.setupCanvas(canvas);
    const padding = { top: 25, right: 35, bottom: 40, left: 75 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const equities = data.map(d => d.equity);
    const minVal = Math.min(...equities) * 0.998;
    const maxVal = Math.max(...equities) * 1.002;
    const valRange = maxVal - minVal || 1;

    const getX = (i) => padding.left + (i / (data.length - 1 || 1)) * chartW;
    const getY = (val) => padding.top + chartH - ((val - minVal) / valRange) * chartH;

    // 1. Subtle horizontal grid lines & Y labels
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    ctx.fillStyle = '#64748b';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'right';

    const ySteps = 5;
    for (let i = 0; i <= ySteps; i++) {
      const v = minVal + (valRange / ySteps) * i;
      const y = getY(v);
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
      ctx.fillText('$' + Math.round(v).toLocaleString(), padding.left - 10, y + 3.5);
    }

    // 2. High Watermark (Peak line with subtle amber glow)
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    let peak = equities[0];
    ctx.moveTo(getX(0), getY(peak));
    for (let i = 1; i < data.length; i++) {
      if (data[i].equity > peak) peak = data[i].equity;
      ctx.lineTo(getX(i), getY(peak));
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // Peak Label
    ctx.fillStyle = 'rgba(245, 158, 11, 0.7)';
    ctx.font = '9px JetBrains Mono, monospace';
    ctx.textAlign = 'left';
    ctx.fillText('HIGH WATERMARK', padding.left + 8, getY(peak) - 6);

    // 3. Shaded gradient under curve with neon glow
    const gradient = ctx.createLinearGradient(0, padding.top, 0, height - padding.bottom);
    gradient.addColorStop(0, 'rgba(16, 185, 129, 0.28)');
    gradient.addColorStop(0.7, 'rgba(16, 185, 129, 0.06)');
    gradient.addColorStop(1, 'rgba(16, 185, 129, 0.0)');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(getX(0), getY(equities[0]));
    for (let i = 1; i < data.length; i++) {
      ctx.lineTo(getX(i), getY(equities[i]));
    }
    ctx.lineTo(getX(data.length - 1), height - padding.bottom);
    ctx.lineTo(getX(0), height - padding.bottom);
    ctx.closePath();
    ctx.fill();

    // 4. Glowing Equity Line
    ctx.shadowColor = 'rgba(16, 185, 129, 0.5)';
    ctx.shadowBlur = 12;
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(getX(0), getY(equities[0]));
    for (let i = 1; i < data.length; i++) {
      ctx.lineTo(getX(i), getY(equities[i]));
    }
    ctx.stroke();
    ctx.shadowBlur = 0; // reset glow

    // 5. Data Points
    for (let i = 0; i < data.length; i++) {
      const x = getX(i);
      const y = getY(equities[i]);
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // X Axis Labels
    ctx.fillStyle = '#64748b';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(data[0].date || 'Start', getX(0), height - 12);
    if (data.length > 1) {
      ctx.fillText(data[data.length - 1].date || 'Current', getX(data.length - 1), height - 12);
    }

    // Setup interactive mouse hover crosshairs & tooltips once
    if (!canvas._boundHover) {
      canvas._boundHover = true;
      canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const curData = canvas._equityData;
        if (!curData || curData.length === 0) return;

        // Find closest point
        let closestIdx = 0;
        let minDiff = Infinity;
        for (let i = 0; i < curData.length; i++) {
          const x = padding.left + (i / (curData.length - 1 || 1)) * chartW;
          const diff = Math.abs(x - mouseX);
          if (diff < minDiff) {
            minDiff = diff;
            closestIdx = i;
          }
        }

        const point = curData[closestIdx];
        this.showTooltip(canvas, e.clientX, e.clientY, `
          <div style="font-size: 11px; font-weight: 700; color: #fff; margin-bottom: 3px;">
            ${point.date || 'Initial Balance'}
          </div>
          <div style="font-size: 13px; font-family: JetBrains Mono; font-weight: 800; color: var(--profit);">
            $${point.equity.toLocaleString()}
          </div>
          ${point.ticket ? `<div style="font-size: 10px; color: var(--text-muted); margin-top: 3px;">
            Ticket: ${point.ticket} (${point.instrument || ''} ${point.side || ''})<br>
            Trade P/L: <span style="color: ${point.trade_pnl >= 0 ? 'var(--profit)' : 'var(--loss)'}; font-weight: 700;">
              ${point.trade_pnl >= 0 ? '+' : ''}$${point.trade_pnl}
            </span>
          </div>` : ''}
        `);
      });

      canvas.addEventListener('mouseleave', () => {
        this.hideTooltip(canvas);
      });
    }
  },

  drawDailyBarChart(canvasId, dailyData) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !dailyData || dailyData.length === 0) return;

    canvas._dailyData = dailyData;
    const { ctx, width, height } = this.setupCanvas(canvas);
    const padding = { top: 25, right: 25, bottom: 40, left: 65 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const pnls = dailyData.map(d => d.pnl);
    const maxPnl = Math.max(...pnls, 400);
    const minPnl = Math.min(...pnls, -400);
    const absMax = Math.max(Math.abs(maxPnl), Math.abs(minPnl)) * 1.15;

    const zeroY = padding.top + chartH / 2;

    // Grid zero line
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(padding.left, zeroY);
    ctx.lineTo(width - padding.right, zeroY);
    ctx.stroke();

    // Y Axis labels
    ctx.fillStyle = '#64748b';
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText('$0', padding.left - 8, zeroY + 3.5);
    ctx.fillText('+$' + Math.round(absMax).toLocaleString(), padding.left - 8, padding.top + 10);
    ctx.fillText('-$' + Math.round(absMax).toLocaleString(), padding.left - 8, height - padding.bottom);

    const barWidth = Math.max(8, Math.min(32, (chartW / dailyData.length) * 0.72));
    const step = chartW / dailyData.length;

    dailyData.forEach((d, i) => {
      const x = padding.left + i * step + (step - barWidth) / 2;
      const barH = Math.max(3, Math.abs(d.pnl / absMax) * (chartH / 2));

      if (d.pnl >= 0) {
        ctx.fillStyle = '#10b981';
        ctx.shadowColor = 'rgba(16, 185, 129, 0.35)';
        ctx.shadowBlur = 8;
        ctx.fillRect(x, zeroY - barH, barWidth, barH);
      } else {
        ctx.fillStyle = '#ef4444';
        ctx.shadowColor = 'rgba(239, 68, 68, 0.35)';
        ctx.shadowBlur = 8;
        ctx.fillRect(x, zeroY, barWidth, barH);
      }
      ctx.shadowBlur = 0;
    });

    // Hover tooltip for Daily P/L
    if (!canvas._boundHover) {
      canvas._boundHover = true;
      canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const curData = canvas._dailyData;
        if (!curData) return;

        const idx = Math.floor((mouseX - padding.left) / step);
        if (idx >= 0 && idx < curData.length) {
          const d = curData[idx];
          this.showTooltip(canvas, e.clientX, e.clientY, `
            <div style="font-size: 11px; font-weight: 700; color: #fff;">${d.date}</div>
            <div style="font-size: 14px; font-family: JetBrains Mono; font-weight: 800; color: ${d.pnl >= 0 ? 'var(--profit)' : 'var(--loss)'}; margin: 2px 0;">
              ${d.pnl >= 0 ? '+' : ''}$${d.pnl.toLocaleString()}
            </div>
            <div style="font-size: 11px; color: var(--text-muted);">
              ${d.trades} trades (${d.wins}W / ${d.losses}L)
            </div>
          `);
        }
      });
      canvas.addEventListener('mouseleave', () => this.hideTooltip(canvas));
    }
  },

  drawSessionBreakdown(canvasId, sessionData) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !sessionData) return;

    const { ctx, width, height } = this.setupCanvas(canvas);
    const sessions = Object.keys(sessionData);
    if (sessions.length === 0) return;

    const padding = { top: 22, right: 35, bottom: 20, left: 115 };
    const chartW = width - padding.left - padding.right;
    const rowH = (height - padding.top - padding.bottom) / sessions.length;

    const maxAbsPnl = Math.max(...sessions.map(s => Math.abs(sessionData[s].net_pnl)), 1000);

    sessions.forEach((s, i) => {
      const y = padding.top + i * rowH + rowH * 0.22;
      const barH = rowH * 0.52;
      const d = sessionData[s];
      const pnl = d.net_pnl;

      ctx.fillStyle = '#cbd5e1';
      ctx.font = '600 11.5px Plus Jakarta Sans, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(s, padding.left - 12, y + barH * 0.7);

      const barW = Math.max(6, (Math.abs(pnl) / maxAbsPnl) * (chartW * 0.72));

      ctx.fillStyle = pnl >= 0 ? 'rgba(16, 185, 129, 0.85)' : 'rgba(239, 68, 68, 0.85)';
      ctx.fillRect(padding.left, y, barW, barH);

      ctx.fillStyle = pnl >= 0 ? '#10b981' : '#ef4444';
      ctx.font = '700 11px JetBrains Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${pnl >= 0 ? '+' : ''}$${pnl.toLocaleString()} (${d.win_rate}%)`, padding.left + barW + 10, y + barH * 0.7);
    });
  },

  drawInstrumentBreakdown(canvasId, instData) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !instData) return;

    const { ctx, width, height } = this.setupCanvas(canvas);
    const instruments = Object.keys(instData).slice(0, 6);
    if (instruments.length === 0) return;

    const padding = { top: 22, right: 35, bottom: 20, left: 85 };
    const chartW = width - padding.left - padding.right;
    const rowH = (height - padding.top - padding.bottom) / instruments.length;

    const maxAbsPnl = Math.max(...instruments.map(inst => Math.abs(instData[inst].net_pnl)), 1000);

    instruments.forEach((inst, i) => {
      const y = padding.top + i * rowH + rowH * 0.22;
      const barH = rowH * 0.52;
      const d = instData[inst];
      const pnl = d.net_pnl;

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 12px JetBrains Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(inst, padding.left - 12, y + barH * 0.7);

      const barW = Math.max(6, (Math.abs(pnl) / maxAbsPnl) * (chartW * 0.72));

      ctx.fillStyle = pnl >= 0 ? 'rgba(16, 185, 129, 0.85)' : 'rgba(239, 68, 68, 0.85)';
      ctx.fillRect(padding.left, y, barW, barH);

      ctx.fillStyle = pnl >= 0 ? '#10b981' : '#ef4444';
      ctx.font = '700 11px JetBrains Mono, monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${pnl >= 0 ? '+' : ''}$${pnl.toLocaleString()} (${d.count}t)`, padding.left + barW + 10, y + barH * 0.7);
    });
  },

  showTooltip(canvas, x, y, htmlContent) {
    let tip = document.getElementById('chart-floating-tooltip');
    if (!tip) {
      tip = document.createElement('div');
      tip.id = 'chart-floating-tooltip';
      tip.style.position = 'fixed';
      tip.style.pointerEvents = 'none';
      tip.style.background = 'rgba(13, 19, 31, 0.95)';
      tip.style.backdropFilter = 'blur(10px)';
      tip.style.border = '1px solid rgba(255, 255, 255, 0.16)';
      tip.style.borderRadius = '8px';
      tip.style.padding = '10px 14px';
      tip.style.zIndex = '300';
      tip.style.boxShadow = '0 10px 30px rgba(0,0,0,0.6)';
      tip.style.transition = 'transform 0.08s ease, opacity 0.15s ease';
      document.body.appendChild(tip);
    }
    tip.innerHTML = htmlContent;
    tip.style.display = 'block';
    tip.style.opacity = '1';
    tip.style.left = `${x + 15}px`;
    tip.style.top = `${y - 20}px`;
  },

  hideTooltip() {
    const tip = document.getElementById('chart-floating-tooltip');
    if (tip) {
      tip.style.opacity = '0';
      setTimeout(() => { if (tip.style.opacity === '0') tip.style.display = 'none'; }, 150);
    }
  }
};
