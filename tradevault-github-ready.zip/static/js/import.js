/**
 * TradeVault AI Screenshot Import View Controller
 * Core feature: OCR & Vision AI parsing, multi-screenshot upload,
 * duplicate detection, editable preview table, confidence scoring,
 * and batch confirmation.
 */

window.ImportView = {
  uploadedFiles: [],
  extractedTrades: [],
  batchSummary: null,

  load() {
    this.setupDropZone();
    this.setupSampleButtons();
    this.setupActionButtons();
    this.renderState();
  },

  setupDropZone() {
    const dropZone = document.getElementById('ai-drop-zone');
    const fileInput = document.getElementById('ai-file-input');
    if (!dropZone || dropZone.dataset.bound) return;

    dropZone.dataset.bound = 'true';

    dropZone.addEventListener('click', () => fileInput.click());

    // Clipboard Paste (Ctrl+V) listener
    window.addEventListener('paste', (e) => {
      // Only process paste if on the ai-import view
      if (App.currentView !== 'ai-import') return;
      const items = e.clipboardData?.items;
      if (!items) return;

      const imageFiles = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) imageFiles.push(file);
        }
      }

      if (imageFiles.length > 0) {
        e.preventDefault();
        App.showToast(`Pasted ${imageFiles.length} screenshot(s) from clipboard!`, "info");
        this.handleFiles(imageFiles);
      }
    });

    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
      dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
      const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
      if (files.length > 0) {
        this.handleFiles(files);
      }
    });

    fileInput.addEventListener('change', (e) => {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        this.handleFiles(files);
      }
    });
  },

  setupSampleButtons() {
    // Quick load sample screenshot buttons for immediate zero-friction evaluation
    document.querySelectorAll('.btn-load-sample').forEach(btn => {
      if (!btn.dataset.bound) {
        btn.dataset.bound = 'true';
        btn.addEventListener('click', async (e) => {
          const sampleName = btn.getAttribute('data-sample');
          await this.loadSampleScreenshot(sampleName);
        });
      }
    });
  },

  async loadSampleScreenshot(sampleName) {
    try {
      this.showProcessingState("Loading sample platform screenshot & running Vision AI extraction...");
      const res = await fetch(`/sample_screenshots/${sampleName}`);
      const blob = await res.blob();
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result;
        const payload = [{
          filename: sampleName,
          data_base64: base64Data,
          mime_type: blob.type || 'image/png'
        }];
        await this.runAiExtraction(payload);
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      App.showToast("Failed to load sample: " + err.message, "error");
      this.hideProcessingState();
    }
  },

  async handleFiles(files) {
    this.showProcessingState(`Processing ${files.length} screenshot(s) with Vision AI...`);
    const filesList = [];

    for (const file of files) {
      const base64 = await this.fileToBase64(file);
      filesList.push({
        filename: file.name,
        data_base64: base64,
        mime_type: file.type || 'image/png'
      });
    }

    await this.runAiExtraction(filesList);
  },

  fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });
  },

  async runAiExtraction(filesList) {
    try {
      const response = await API.extractScreenshots(filesList);
      this.hideProcessingState();

      if (response.is_multi) {
        this.extractedTrades = response.batch_summary.merged_trades || [];
        this.batchSummary = response.batch_summary;
      } else {
        this.extractedTrades = response.trades || [];
        this.batchSummary = response.summary;
      }

      this.renderPreviewTable();
      App.showToast(`Successfully parsed ${this.extractedTrades.length} trade(s)! Please review before saving.`, "success");
    } catch (err) {
      this.hideProcessingState();
      App.showToast("Extraction failed: " + err.message, "error");
    }
  },

  showProcessingState(message) {
    const el = document.getElementById('ai-processing-state');
    const dropEl = document.getElementById('ai-drop-zone');
    const msgEl = document.getElementById('ai-processing-msg');
    if (el) el.style.display = 'block';
    if (dropEl) dropEl.style.display = 'none';
    if (msgEl) msgEl.textContent = message;
  },

  hideProcessingState() {
    const el = document.getElementById('ai-processing-state');
    const dropEl = document.getElementById('ai-drop-zone');
    if (el) el.style.display = 'none';
    if (dropEl) dropEl.style.display = 'block';
  },

  renderState() {
    if (this.extractedTrades.length === 0) {
      const prevEl = document.getElementById('ai-preview-section');
      if (prevEl) prevEl.style.display = 'none';
    }
  },

  renderPreviewTable() {
    const prevSection = document.getElementById('ai-preview-section');
    if (prevSection) prevSection.style.display = 'block';

    // Summary banner
    const summaryBanner = document.getElementById('ai-import-summary-banner');
    if (summaryBanner && this.batchSummary) {
      const isMulti = !!this.batchSummary.cross_screenshot_duplicates !== undefined;
      const totalPnL = this.batchSummary.total_recognized_pnl || this.batchSummary.batch_total_pnl || 0.0;
      const dups = this.batchSummary.possible_duplicates || this.batchSummary.cross_screenshot_duplicates || 0;
      const revFields = this.batchSummary.fields_requiring_review || 0;

      summaryBanner.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
          <div>
            <div style="font-weight: 700; font-size: 14px; color: #fff;">
              Extraction Summary: ${this.extractedTrades.length} trades recognized
            </div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
              Total Recognized P/L: <strong>$${totalPnL.toLocaleString()}</strong> 
              ${dups > 0 ? ` | <span class="text-loss">⚠️ ${dups} potential duplicate(s) detected</span>` : ''}
              ${revFields > 0 ? ` | <span class="text-warning">⚡ ${revFields} field(s) marked for manual review</span>` : ''}
            </div>
          </div>
          <div style="display: flex; gap: 10px;">
            <button class="btn btn-secondary btn-sm" id="btn-add-manual-row">+ Add Row</button>
            <button class="btn btn-profit" id="btn-confirm-import">Confirm & Import to Journal</button>
          </div>
        </div>
      `;

      document.getElementById('btn-add-manual-row').addEventListener('click', () => this.addManualRow());
      document.getElementById('btn-confirm-import').addEventListener('click', () => this.confirmBatchSave());
    }

    const tbody = document.getElementById('ai-preview-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    this.extractedTrades.forEach((tr, index) => {
      const trEl = document.createElement('tr');
      if (tr.is_duplicate || tr.is_batch_duplicate) {
        trEl.style.backgroundColor = 'rgba(239, 68, 68, 0.08)';
      }

      const conf = tr.field_confidences || {};

      trEl.innerHTML = `
        <td>
          <input type="text" class="editable-cell font-mono" value="${tr.ticket_id || ''}" data-idx="${index}" data-field="ticket_id" style="width: 80px;" />
          ${tr.is_duplicate ? '<span class="badge-loss" style="font-size: 9px; display: block; margin-top: 2px;">DUPLICATE</span>' : ''}
        </td>
        <td>
          <input type="text" class="editable-cell font-mono" value="${tr.instrument || 'EURUSD'}" data-idx="${index}" data-field="instrument" style="width: 75px; font-weight: 700;" />
        </td>
        <td>
          <select class="editable-cell font-mono" data-idx="${index}" data-field="side" style="width: 65px; font-weight: 700; color: ${tr.side === 'BUY' ? 'var(--profit)' : 'var(--loss)'};">
            <option value="BUY" ${tr.side === 'BUY' ? 'selected' : ''}>BUY</option>
            <option value="SELL" ${tr.side === 'SELL' ? 'selected' : ''}>SELL</option>
          </select>
        </td>
        <td>
          <input type="number" step="0.01" class="editable-cell font-mono" value="${tr.lot_size || 1.0}" data-idx="${index}" data-field="lot_size" style="width: 60px;" />
        </td>
        <td>
          <input type="number" step="0.00001" class="editable-cell font-mono" value="${tr.entry_price || 0.0}" data-idx="${index}" data-field="entry_price" style="width: 85px;" />
        </td>
        <td>
          <input type="number" step="0.00001" class="editable-cell font-mono" value="${tr.exit_price || 0.0}" data-idx="${index}" data-field="exit_price" style="width: 85px;" />
        </td>
        <td>
          <input type="number" step="0.00001" class="editable-cell font-mono ${conf.stop_loss === 'missing' ? 'border-warning' : ''}" value="${tr.stop_loss || ''}" placeholder="None" data-idx="${index}" data-field="stop_loss" style="width: 75px;" />
        </td>
        <td>
          <input type="number" step="0.00001" class="editable-cell font-mono" value="${tr.take_profit || ''}" placeholder="None" data-idx="${index}" data-field="take_profit" style="width: 75px;" />
        </td>
        <td>
          <input type="number" step="0.01" class="editable-cell font-mono" value="${tr.net_pnl || 0.0}" data-idx="${index}" data-field="net_pnl" style="width: 85px; font-weight: 800; color: ${tr.net_pnl >= 0 ? 'var(--profit)' : 'var(--loss)'};" />
        </td>
        <td>
          <input type="text" class="editable-cell font-mono" value="${tr.close_time || ''}" data-idx="${index}" data-field="close_time" style="width: 130px; font-size: 11px;" />
        </td>
        <td>
          <button class="btn btn-secondary btn-sm btn-remove-row" data-idx="${index}" title="Remove this trade" style="color: var(--loss); padding: 2px 6px;">✕</button>
        </td>
      `;

      tbody.appendChild(trEl);
    });

    // Listeners for inline editing
    tbody.querySelectorAll('.editable-cell').forEach(input => {
      input.addEventListener('change', (e) => {
        const idx = parseInt(e.target.dataset.idx);
        const field = e.target.dataset.field;
        let val = e.target.value;
        if (['lot_size', 'entry_price', 'exit_price', 'stop_loss', 'take_profit', 'net_pnl'].includes(field)) {
          val = parseFloat(val) || 0.0;
        }
        this.extractedTrades[idx][field] = val;
      });
    });

    tbody.querySelectorAll('.btn-remove-row').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(btn.dataset.idx);
        this.extractedTrades.splice(idx, 1);
        this.renderPreviewTable();
      });
    });
  },

  addManualRow() {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    this.extractedTrades.push({
      ticket_id: String(Math.floor(Math.random() * 900000 + 100000)),
      instrument: 'EURUSD',
      side: 'BUY',
      lot_size: 1.0,
      entry_price: 1.08500,
      exit_price: 1.08800,
      stop_loss: 1.08300,
      take_profit: 1.08900,
      net_pnl: 300.00,
      open_time: now,
      close_time: now,
      field_confidences: {},
      review_warnings: []
    });
    this.renderPreviewTable();
  },

  async confirmBatchSave() {
    if (this.extractedTrades.length === 0) {
      App.showToast("No trades to save.", "warning");
      return;
    }

    const accountSelect = document.getElementById('ai-target-account');
    const stratSelect = document.getElementById('ai-target-strategy');
    const accId = accountSelect ? accountSelect.value : null;
    const stratId = stratSelect ? stratSelect.value : null;

    try {
      const res = await API.batchSaveTrades({
        trades: this.extractedTrades,
        account_id: accId,
        strategy_id: stratId
      });

      App.showToast(`Imported ${res.saved_trades_count} trade(s) to journal successfully!`, "success");
      this.extractedTrades = [];
      this.batchSummary = null;
      this.renderState();
      // Jump to Trades page
      App.navigateTo('trades');
    } catch (err) {
      App.showToast("Error saving trades: " + err.message, "error");
    }
  },

  setupActionButtons() {
    const clearBtn = document.getElementById('btn-clear-import');
    if (clearBtn && !clearBtn.dataset.bound) {
      clearBtn.dataset.bound = 'true';
      clearBtn.addEventListener('click', () => {
        this.extractedTrades = [];
        this.batchSummary = null;
        this.renderState();
      });
    }
  }
};
