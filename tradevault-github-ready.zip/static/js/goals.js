/**
 * TradeVault Goals & Milestones View Controller
 */

window.GoalsView = {
  goals: [],

  async load() {
    this.setupNewGoalModal();
    await this.fetchAndRender();
  },

  setupNewGoalModal() {
    const btn = document.getElementById('btn-open-new-goal-modal');
    const modal = document.getElementById('new-goal-modal');
    if (btn && !btn.dataset.bound) {
      btn.dataset.bound = 'true';
      btn.addEventListener('click', () => {
        if (modal) modal.classList.add('active');
      });
    }

    const saveBtn = document.getElementById('btn-save-new-goal');
    if (saveBtn && !saveBtn.dataset.bound) {
      saveBtn.dataset.bound = 'true';
      saveBtn.addEventListener('click', async () => {
        const title = document.getElementById('new-goal-title')?.value;
        const type = document.getElementById('new-goal-type')?.value || 'net_pnl';
        const targetVal = parseFloat(document.getElementById('new-goal-target-val')?.value) || 1000;
        const currentVal = parseFloat(document.getElementById('new-goal-current-val')?.value) || 0;
        const period = document.getElementById('new-goal-period')?.value || 'monthly';
        const deadline = document.getElementById('new-goal-deadline')?.value || '';
        const notes = document.getElementById('new-goal-notes')?.value || '';

        if (!title) {
          App.showToast("Goal title is required.", "warning");
          return;
        }

        try {
          await API.createGoal({
            title, target_type: type, target_value: targetVal, current_value: currentVal,
            period, deadline, notes, status: currentVal >= targetVal ? 'achieved' : 'in_progress'
          });
          App.showToast("Goal created successfully", "success");
          modal.classList.remove('active');
          document.getElementById('new-goal-form')?.reset();
          await this.fetchAndRender();
        } catch (err) {
          App.showToast("Error creating goal: " + err.message, "error");
        }
      });
    }
  },

  async fetchAndRender() {
    try {
      const res = await API.getGoals();
      this.goals = res.goals || [];
      this.render();
    } catch (err) {
      App.showToast("Failed to load goals: " + err.message, "error");
    }
  },

  render() {
    const activeContainer = document.getElementById('goals-active-container');
    const achievedContainer = document.getElementById('goals-achieved-container');
    if (!activeContainer || !achievedContainer) return;

    activeContainer.innerHTML = '';
    achievedContainer.innerHTML = '';

    const activeGoals = this.goals.filter(g => g.status !== 'achieved');
    const achievedGoals = this.goals.filter(g => g.status === 'achieved');

    if (activeGoals.length === 0) {
      activeContainer.innerHTML = `<div style="color: var(--text-muted); padding: 20px;">No active goals. Set a target to keep your trading disciplined!</div>`;
    } else {
      activeGoals.forEach(g => activeContainer.appendChild(this.createGoalCard(g, false)));
    }

    if (achievedGoals.length === 0) {
      achievedContainer.innerHTML = `<div style="color: var(--text-muted); padding: 20px;">No achieved milestones yet. Accomplish goals to fill your trophy room!</div>`;
    } else {
      achievedGoals.forEach(g => achievedContainer.appendChild(this.createGoalCard(g, true)));
    }
  },

  createGoalCard(g, isAchieved) {
    const card = document.createElement('div');
    card.className = 'panel';
    card.style.marginBottom = '14px';

    const pct = Math.min(Math.round((g.current_value / g.target_value) * 100) || 0, 100);

    card.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
        <div>
          <h4 style="font-size: 15px; font-weight: 700; color: #fff;">${g.title}</h4>
          <p style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">${g.notes || 'No description'}</p>
        </div>
        <div>
          ${isAchieved ? '<span class="badge-profit">COMPLETED 🏆</span>' : `<span class="badge-neutral font-mono">${pct}%</span>`}
        </div>
      </div>

      <div style="margin-bottom: 8px;">
        <div style="height: 6px; background: var(--bg-tertiary); border-radius: 3px; overflow: hidden;">
          <div style="height: 100%; width: ${pct}%; background: ${isAchieved ? '#10b981' : '#3b82f6'}; border-radius: 3px;"></div>
        </div>
      </div>

      <div style="display: flex; justify-content: space-between; font-size: 11px;" class="font-mono text-muted">
        <span>Current: <strong>${g.current_value}</strong></span>
        <span>Target: <strong>${g.target_value}</strong></span>
      </div>
    `;

    return card;
  }
};
