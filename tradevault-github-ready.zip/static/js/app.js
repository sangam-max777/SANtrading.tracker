/**
 * TradeVault Main Application State & Router
 */

window.App = {
  currentView: 'dashboard',
  activeAccountId: null,
  settings: {},
  accounts: [],
  strategies: [],

  async init() {
    console.log("Initializing TradeVault...");
    this.setupEventListeners();
    await this.loadInitialData();
    this.navigateFromHash();
  },

  async loadInitialData() {
    try {
      this.settings = await API.getSettings();
      const accountsRes = await API.getAccounts();
      this.accounts = accountsRes.accounts || [];

      const stratRes = await API.getStrategies();
      this.strategies = stratRes.strategies || [];

      this.updateBranding();
      this.populateAccountSelectors();
    } catch (err) {
      this.showToast("Failed to connect to backend server: " + err.message, "error");
    }
  },

  updateBranding() {
    const name = this.settings.app_name || 'TradeVault';
    document.querySelectorAll('.brand-name-text').forEach(el => el.textContent = name);
    document.title = `${name} | Institutional Trading Journal`;
  },

  populateAccountSelectors() {
    const selectors = document.querySelectorAll('.account-select-dropdown');
    selectors.forEach(sel => {
      const currentVal = sel.value;
      sel.innerHTML = '<option value="">All Accounts (Global)</option>';
      this.accounts.forEach(acc => {
        const opt = document.createElement('option');
        opt.value = acc.id;
        opt.textContent = `${acc.name} (${acc.currency} $${acc.current_balance.toLocaleString()})`;
        sel.appendChild(opt);
      });
      if (currentVal) sel.value = currentVal;
    });

    // Populate strategy selectors
    const stratSelectors = document.querySelectorAll('.strategy-select-dropdown');
    stratSelectors.forEach(sel => {
      const currentVal = sel.value;
      sel.innerHTML = '<option value="">Select Strategy</option>';
      this.strategies.forEach(s => {
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.name;
        sel.appendChild(opt);
      });
      if (currentVal) sel.value = currentVal;
    });
  },

  setupEventListeners() {
    // Nav links
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetView = link.getAttribute('data-view');
        if (targetView) this.navigateTo(targetView);
      });
    });

    // Hash change
    window.addEventListener('hashchange', () => this.navigateFromHash());

    // Global Account Switcher in Topbar
    const topbarAccSelect = document.getElementById('topbar-account-select');
    if (topbarAccSelect) {
      topbarAccSelect.addEventListener('change', (e) => {
        this.activeAccountId = e.target.value || null;
        this.refreshCurrentView();
      });
    }

    // Mobile Hamburger
    const menuBtn = document.getElementById('mobile-menu-btn');
    const sidebar = document.getElementById('sidebar');
    if (menuBtn && sidebar) {
      menuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('open');
      });
    }
  },

  navigateFromHash() {
    const hash = window.location.hash.replace('#', '') || 'dashboard';
    this.navigateTo(hash, false);
  },

  navigateTo(viewName, updateHash = true) {
    if (updateHash) {
      window.location.hash = viewName;
    }

    this.currentView = viewName;

    // Update nav links active class
    document.querySelectorAll('.nav-link').forEach(l => {
      if (l.getAttribute('data-view') === viewName) {
        l.classList.add('active');
      } else {
        l.classList.remove('active');
      }
    });

    // Hide all views and show target view
    document.querySelectorAll('.view-container').forEach(v => {
      v.classList.remove('active');
    });

    const targetEl = document.getElementById(`view-${viewName}`);
    if (targetEl) {
      targetEl.classList.add('active');
      this.triggerViewLoad(viewName);
    }

    // Close mobile menu if open
    const sidebar = document.getElementById('sidebar');
    if (sidebar) sidebar.classList.remove('open');
  },

  refreshCurrentView() {
    this.triggerViewLoad(this.currentView);
  },

  triggerViewLoad(viewName) {
    switch (viewName) {
      case 'dashboard':
        if (window.DashboardView) window.DashboardView.load();
        break;
      case 'trades':
        if (window.TradesView) window.TradesView.load();
        break;
      case 'ai-import':
        if (window.ImportView) window.ImportView.load();
        break;
      case 'add-trade':
        if (window.TradeFormView) window.TradeFormView.load();
        break;
      case 'calendar':
        if (window.CalendarView) window.CalendarView.load();
        break;
      case 'strategies':
        if (window.StrategiesView) window.StrategiesView.load();
        break;
      case 'accounts':
        if (window.AccountsView) window.AccountsView.load();
        break;
      case 'goals':
        if (window.GoalsView) window.GoalsView.load();
        break;
      case 'coach':
        if (window.CoachView) window.CoachView.load();
        break;
      case 'reports':
        if (window.ReportsView) window.ReportsView.load();
        break;
      case 'settings':
        if (window.SettingsView) window.SettingsView.load();
        break;
    }
  },

  // Toast notifications
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'error') icon = '❌';
    if (type === 'warning') icon = '⚠️';

    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  },

  // Number Formatters
  formatCurrency(amount, currency = null) {
    if (amount === undefined || amount === null || isNaN(amount)) return '$0.00';
    const sym = this.settings.currency_symbol || '$';
    const prefix = amount < 0 ? `-${sym}` : `${sym}`;
    return prefix + Math.abs(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatPnL(amount) {
    if (amount === undefined || amount === null || isNaN(amount)) return '$0.00';
    const sym = this.settings.currency_symbol || '$';
    if (amount > 0) {
      return `<span class="text-profit font-mono">+${sym}${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>`;
    } else if (amount < 0) {
      return `<span class="text-loss font-mono">-${sym}${Math.abs(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>`;
    } else {
      return `<span class="text-muted font-mono">${sym}0.00</span>`;
    }
  },

  formatPct(val) {
    if (val === undefined || val === null || isNaN(val)) return '0.0%';
    return `${val.toFixed(1)}%`;
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
