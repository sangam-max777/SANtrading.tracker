/**
 * TradeVault Dashboard View Controller
 * Data-dense institutional analytics, recent journal feed, long vs short edge.
 */

window.DashboardView = {
  stats: null,

  async load() {
    this.setupFilters();
    this.startLiveClock();
    await this.fetchAndRender();
  },

  startLiveClock() {
    if (this._clockInterval) return;
    const updateTime = () => {
      const now = new Date();
      const utcHours = now.getUTCHours();
      const utcMins = now.getUTCMinutes();
      const utcSecs = now.getUTCSeconds();
      const timeStr = `${String(utcHours).padStart(2, '0')}:${String(utcMins).padStart(2, '0')}:${String(utcSecs).padStart(2, '0')} UTC`;
      
      const clockEl = document.getElementById('live-utc-clock');
      if (clockEl) clockEl.textContent = timeStr;

      // Update active market sessions
      const londonEl = document.getElementById('session-london');
      const nyEl = document.getElementById('session-ny');
      const asiaEl = document.getElementById('session-asia');

      // London: 08:00 - 16:30 UTC
      if (londonEl) {
        if (utcHours >= 8 && utcHours < 17) londonEl.classList.add('active');
        else londonEl.classList.remove('active');
      }

      // NY: 13:00 - 22:00 UTC
      if (nyEl) {
        if (utcHours >= 13 && utcHours < 22) nyEl.classList.add('active');
        else nyEl.classList.remove('active');
      }

      // Asia/Tokyo: 00:00 - 09:00 UTC
      if (asiaEl) {
        if (utcHours >= 0 && utcHours < 9) asiaEl.classList.add('active');
        else asiaEl.classList.remove('active');
      }
    };

    updateTime();
    this._clockInterval = setInterval(updateTime, 1000);
  },

  setupFilters() {
    const filterIds = ['dash-filter-strategy', 'dash-filter-session', 'dash-filter-instrument', 'dash-filter-start', 'dash-filter-end'];
    filterIds.forEach(id => {
      const el = document.getElementById(id);
      if (el && !el.dataset.bound) {
        el.dataset.bound = 'true';
        el.addEventListener('change', () => this.fetchAndRender());
      }
    });

    const resetBtn = document.getElementById('dash-filter-reset');
    if (resetBtn && !resetBtn.dataset.bound) {
      resetBtn.dataset.bound = 'true';
      resetBtn.addEventListener('click', () => {
        filterIds.forEach(id => {
          const el = document.getElementById(id);
          if (el) el.value = '';
        });
        this.fetchAndRender();
      });
    }
  },

  async fetchAndRender() {
    try {
      const params = {};
      if (App.activeAccountId) params.account_id = App.activeAccountId;

      const stratEl = document.getElementById('dash-filter-strategy');
      if (stratEl && stratEl.value) params.strategy_id = stratEl.value;

      const sessEl = document.getElementById('dash-filter-session');
      if (sessEl && sessEl.value) params.session = sessEl.value;

      const instEl = document.getElementById('dash-filter-instrument');
      if (instEl && instEl.value) params.instrument = instEl.value;

      const startEl = document.getElementById('dash-filter-start');
      if (startEl && startEl.value) params.start_date = startEl.value;

      const endEl = document.getElementById('dash-filter-end');
      if (endEl && endEl.value) params.end_date = endEl.value;

      this.stats = await API.getDashboard(params);
      this.renderStatCards(this.stats);
      this.renderCharts(this.stats);
      this.renderLongShort(this.stats);
      await this.renderRecentTrades();
    } catch (err) {
      App.showToast("Failed to load dashboard: " + err.message, "error");
    }
  },

  renderStatCards(s) {
    const netEl = document.getElementById('stat-net-pnl');
    if (netEl) netEl.innerHTML = App.formatPnL(s.net_pnl);

    const winRateEl = document.getElementById('stat-win-rate');
    if (winRateEl) {
      winRateEl.textContent = `${s.win_rate}%`;
      const sub = document.getElementById('stat-win-loss-count');
      if (sub) sub.textContent = `${s.win_trades}W / ${s.loss_trades}L (${s.total_trades} trades)`;
    }

    const pfEl = document.getElementById('stat-profit-factor');
    if (pfEl) {
      pfEl.textContent = s.profit_factor > 0 ? s.profit_factor.toFixed(2) : '0.00';
      const pfSub = document.getElementById('stat-gross-ratio');
      if (pfSub) pfSub.textContent = `Gross: +$${s.gross_profit.toLocaleString()} / -$${s.gross_loss.toLocaleString()}`;
    }

    const expEl = document.getElementById('stat-expectancy');
    if (expEl) {
      expEl.innerHTML = App.formatPnL(s.expectancy);
      const expSub = document.getElementById('stat-avg-win-loss');
      if (expSub) expSub.textContent = `Avg W: $${s.avg_win.toFixed(0)} | Avg L: $${s.avg_loss.toFixed(0)}`;
    }

    const ddEl = document.getElementById('stat-max-drawdown');
    if (ddEl) {
      ddEl.innerHTML = `<span class="text-loss font-mono">-${s.max_drawdown_pct.toFixed(2)}%</span>`;
      const ddSub = document.getElementById('stat-max-dd-amount');
      if (ddSub) ddSub.textContent = `-$${s.max_drawdown_amount.toLocaleString()} peak-to-trough`;
    }

    const balEl = document.getElementById('stat-current-balance');
    if (balEl) {
      balEl.textContent = App.formatCurrency(s.current_balance);
      const balSub = document.getElementById('stat-starting-bal');
      if (balSub) balSub.textContent = `Start: ${App.formatCurrency(s.starting_balance)}`;
    }

    const streakEl = document.getElementById('stat-current-streak');
    if (streakEl) {
      const type = s.current_streak.type;
      const count = s.current_streak.count;
      if (type === 'win') {
        streakEl.innerHTML = `<span class="text-profit font-mono">${count} Wins 🔥</span>`;
      } else if (type === 'loss') {
        streakEl.innerHTML = `<span class="text-loss font-mono">${count} Losses ❄️</span>`;
      } else {
        streakEl.textContent = 'None';
      }
      const streakSub = document.getElementById('stat-best-worst-streak');
      if (streakSub) streakSub.textContent = `Best: ${s.best_win_streak}W | Worst: ${s.worst_loss_streak}L`;
    }

    const bestDayEl = document.getElementById('stat-best-day');
    if (bestDayEl) {
      bestDayEl.innerHTML = `Best: <span class="text-profit font-mono">+$${s.best_day.pnl.toLocaleString()}</span> (${s.best_day.date})`;
    }
    const worstDayEl = document.getElementById('stat-worst-day');
    if (worstDayEl) {
      worstDayEl.innerHTML = `Worst: <span class="text-loss font-mono">-$${Math.abs(s.worst_day.pnl).toLocaleString()}</span> (${s.worst_day.date})`;
    }

    // Topbar quick stats
    const topBal = document.getElementById('topbar-stat-balance');
    if (topBal) topBal.textContent = App.formatCurrency(s.current_balance);

    const topNet = document.getElementById('topbar-stat-pnl');
    if (topNet) topNet.innerHTML = App.formatPnL(s.net_pnl);

    const topWr = document.getElementById('topbar-stat-wr');
    if (topWr) topWr.textContent = `${s.win_rate}% WR`;

    // Equity Gain Badge
    const gainEl = document.getElementById('dash-equity-gain');
    if (gainEl && s.starting_balance > 0) {
      const gainPct = ((s.net_pnl / s.starting_balance) * 100).toFixed(2);
      gainEl.textContent = `${gainPct >= 0 ? '+' : ''}${gainPct}% Total Return`;
      gainEl.className = gainPct >= 0 ? 'badge-profit font-mono' : 'badge-loss font-mono';
    }
  },

  renderCharts(s) {
    if (window.Charts) {
      Charts.drawEquityCurve('chart-equity-curve', s.equity_curve);
      Charts.drawDailyBarChart('chart-daily-pnl', s.daily_pnl_chart);
      Charts.drawSessionBreakdown('chart-session-breakdown', s.session_performance);
      Charts.drawInstrumentBreakdown('chart-instrument-breakdown', s.instrument_performance);
    }
  },

  renderLongShort(s) {
    const lvs = s.long_vs_short;
    if (!lvs) return;

    const longSummary = document.getElementById('dash-long-summary');
    const shortSummary = document.getElementById('dash-short-summary');
    const longBar = document.getElementById('dash-long-bar');
    const shortBar = document.getElementById('dash-short-bar');

    if (longSummary) longSummary.textContent = `${lvs.long.count} trades | ${lvs.long.win_rate}% WR (+$${lvs.long.net_pnl.toLocaleString()})`;
    if (shortSummary) shortSummary.textContent = `${lvs.short.count} trades | ${lvs.short.win_rate}% WR (+$${lvs.short.net_pnl.toLocaleString()})`;

    if (longBar) longBar.style.width = `${Math.min(lvs.long.win_rate, 100)}%`;
    if (shortBar) shortBar.style.width = `${Math.min(lvs.short.win_rate, 100)}%`;
  },

  async renderRecentTrades() {
    try {
      const res = await API.getTrades({ limit: 5 });
      const recent = (res.trades || []).slice(0, 5);
      const tbody = document.getElementById('dash-recent-trades-body');
      if (!tbody) return;

      tbody.innerHTML = '';
      if (recent.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 18px;">No trades logged yet.</td></tr>`;
        return;
      }

      recent.forEach(t => {
        const tr = document.createElement('tr');
        const dtStr = (t.close_time || t.open_time || '').replace('T', ' ').substring(5, 16);
        tr.innerHTML = `
          <td class="font-mono text-muted" style="font-size: 11px;">${t.ticket_id || '#' + t.id.substring(0, 5)}</td>
          <td><strong class="font-mono" style="color: #fff;">${t.instrument}</strong></td>
          <td><span class="${t.side === 'BUY' ? 'badge-profit' : 'badge-loss'}">${t.side}</span></td>
          <td>${App.formatPnL(t.net_pnl)}</td>
          <td class="font-mono">${t.actual_rr ? t.actual_rr + 'R' : '-'}</td>
          <td><span class="badge-neutral">${t.session || 'London'}</span></td>
          <td class="font-mono text-muted" style="font-size: 11px;">${dtStr}</td>
        `;
        tbody.appendChild(tr);
      });
    } catch (_) {}
  }
};
