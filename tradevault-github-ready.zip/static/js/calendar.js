/**
 * TradeVault Trading Calendar View Controller
 * Monthly calendar grid with color-coded daily net P/L, trade count pills,
 * day trade inspector modal, and monthly summaries.
 */

window.CalendarView = {
  currentYear: new Date().getFullYear(),
  currentMonth: new Date().getMonth() + 1,
  calendarData: null,

  async load() {
    this.setupNavigation();
    await this.fetchAndRender();
  },

  setupNavigation() {
    const prevBtn = document.getElementById('cal-prev-month');
    const nextBtn = document.getElementById('cal-next-month');
    if (prevBtn && !prevBtn.dataset.bound) {
      prevBtn.dataset.bound = 'true';
      prevBtn.addEventListener('click', () => {
        this.currentMonth--;
        if (this.currentMonth < 1) {
          this.currentMonth = 12;
          this.currentYear--;
        }
        this.fetchAndRender();
      });
    }

    if (nextBtn && !nextBtn.dataset.bound) {
      nextBtn.dataset.bound = 'true';
      nextBtn.addEventListener('click', () => {
        this.currentMonth++;
        if (this.currentMonth > 12) {
          this.currentMonth = 1;
          this.currentYear++;
        }
        this.fetchAndRender();
      });
    }
  },

  async fetchAndRender() {
    try {
      this.calendarData = await API.getCalendar(this.currentYear, this.currentMonth, App.activeAccountId);
      this.render();
    } catch (err) {
      App.showToast("Failed to load trading calendar: " + err.message, "error");
    }
  },

  render() {
    const d = this.calendarData;
    if (!d) return;

    // Title
    const titleEl = document.getElementById('cal-month-title');
    if (titleEl) {
      titleEl.textContent = `${d.month_name} ${d.year}`;
    }

    // Monthly summary stats
    const summ = d.summary;
    const pnlEl = document.getElementById('cal-summary-pnl');
    if (pnlEl) pnlEl.innerHTML = App.formatPnL(summ.total_net_pnl);

    const tradesEl = document.getElementById('cal-summary-trades');
    if (tradesEl) tradesEl.textContent = `${summ.total_trades} Trades`;

    const daysEl = document.getElementById('cal-summary-win-days');
    if (daysEl) daysEl.textContent = `${summ.profitable_days} Green Days`;

    const bestEl = document.getElementById('cal-summary-best-day');
    if (bestEl) {
      bestEl.innerHTML = summ.best_day.pnl > 0 
        ? `<span class="text-profit">+$${summ.best_day.pnl.toLocaleString()}</span> (${summ.best_day.date})`
        : '-';
    }

    // Render Grid
    const gridEl = document.getElementById('calendar-grid-cells');
    if (!gridEl) return;
    gridEl.innerHTML = '';

    d.grid.forEach(week => {
      week.forEach(day => {
        const cell = document.createElement('div');
        let classes = 'calendar-cell';
        if (!day.is_current_month) classes += ' other-month';
        if (day.pnl > 0) classes += ' profit-day';
        else if (day.pnl < 0) classes += ' loss-day';

        cell.className = classes;

        const pnlText = day.trades_count > 0 
          ? (day.pnl >= 0 ? `+$${day.pnl.toLocaleString()}` : `-$${Math.abs(day.pnl).toLocaleString()}`)
          : '';

        const pnlClass = day.pnl >= 0 ? 'text-profit' : 'text-loss';

        cell.innerHTML = `
          <div class="calendar-day-header">
            <span class="calendar-day-num">${day.day_number}</span>
            ${day.trades_count > 0 ? `<span class="calendar-trade-count">${day.trades_count}t</span>` : ''}
          </div>
          <div class="calendar-day-pnl font-mono ${pnlClass}">
            ${pnlText}
          </div>
        `;

        if (day.trades_count > 0) {
          cell.addEventListener('click', () => this.inspectDay(day));
        }

        gridEl.appendChild(cell);
      });
    });
  },

  inspectDay(day) {
    const modal = document.getElementById('cal-day-modal');
    const title = document.getElementById('cal-day-modal-title');
    const body = document.getElementById('cal-day-modal-body');
    if (!modal || !body) return;

    title.textContent = `Trades on ${day.date} (${day.trades_count} trades | P/L: $${day.pnl.toLocaleString()})`;

    let html = `
      <table class="data-table">
        <thead>
          <tr>
            <th>Ticket</th>
            <th>Instrument</th>
            <th>Side</th>
            <th>Net P/L</th>
            <th>R-Multiple</th>
            <th>Setup</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
    `;

    day.trades.forEach(t => {
      html += `
        <tr>
          <td class="font-mono text-muted">${t.ticket || t.id.substring(0,6)}</td>
          <td><strong class="font-mono" style="color: #fff;">${t.instrument}</strong></td>
          <td><span class="${t.side === 'BUY' ? 'badge-profit' : 'badge-loss'}">${t.side}</span></td>
          <td>${App.formatPnL(t.net_pnl)}</td>
          <td class="font-mono">${t.actual_rr ? t.actual_rr + 'R' : '-'}</td>
          <td class="text-muted">${t.setup_type || '-'}</td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="TradesView.viewDetails('${t.id}')">View</button>
          </td>
        </tr>
      `;
    });

    html += `</tbody></table>`;
    body.innerHTML = html;
    modal.classList.add('active');
  }
};
