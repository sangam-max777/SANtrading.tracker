/**
 * TradeVault AI Trading Coach View Controller
 * Data-grounded behavioral analytics, mistake leaks, discipline correlation,
 * and structured self-review coaching questions.
 */

window.CoachView = {
  report: null,

  async load() {
    await this.fetchAndRender();
  },

  async fetchAndRender() {
    try {
      this.report = await API.getCoachReport();
      this.render();
    } catch (err) {
      App.showToast("Failed to load coach analysis: " + err.message, "error");
    }
  },

  render() {
    const r = this.report;
    if (!r) return;

    // 1. Sample Size & Honesty Disclaimer
    const sampleEl = document.getElementById('coach-sample-note');
    if (sampleEl) {
      sampleEl.textContent = r.sample_note;
    }

    // 2. Executive Synthesis
    const synthEl = document.getElementById('coach-synthesis-text');
    if (synthEl) {
      synthEl.textContent = r.overall_summary;
    }

    // 3. Financial Toll of Recurring Mistakes
    const mistakeContainer = document.getElementById('coach-mistakes-table-body');
    if (mistakeContainer) {
      mistakeContainer.innerHTML = '';
      if (r.mistake_analysis.length === 0) {
        mistakeContainer.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 15px;">No mistakes recorded! Outstanding execution discipline.</td></tr>`;
      } else {
        r.mistake_analysis.forEach(m => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td><strong style="color: #fff;">${m.mistake}</strong></td>
            <td class="font-mono text-muted">${m.frequency} trades (${m.pct_of_sample}%)</td>
            <td class="font-mono text-loss" style="font-weight: 700;">-$${m.total_capital_lost.toLocaleString()}</td>
            <td class="font-mono text-muted" style="font-size: 11px;">${m.trade_tickets.join(', ')}</td>
          `;
          mistakeContainer.appendChild(tr);
        });
      }
    }

    // 4. Discipline vs P/L Correlation
    const discContainer = document.getElementById('coach-discipline-container');
    if (discContainer && r.discipline_correlation.high_discipline) {
      const high = r.discipline_correlation.high_discipline;
      const low = r.discipline_correlation.low_discipline;

      discContainer.innerHTML = `
        <div class="grid-cards" style="margin-bottom: 0;">
          <div class="stat-card" style="border-left: 3px solid var(--profit);">
            <span class="stat-card-title">${high.label}</span>
            <span class="stat-card-value font-mono" style="color: var(--profit);">${App.formatCurrency(high.net_pnl)}</span>
            <span class="stat-card-sub font-mono">${high.count} trades | Win Rate: ${high.win_rate}% | Avg: $${high.avg_pnl}</span>
          </div>
          <div class="stat-card" style="border-left: 3px solid var(--loss);">
            <span class="stat-card-title">${low.label}</span>
            <span class="stat-card-value font-mono" style="color: var(--loss);">${App.formatCurrency(low.net_pnl)}</span>
            <span class="stat-card-sub font-mono">${low.count} trades | Win Rate: ${low.win_rate}% | Avg: $${low.avg_pnl}</span>
          </div>
        </div>
      `;
    }

    // 5. Tailored Self-Review Questions
    const questionsContainer = document.getElementById('coach-questions-list');
    if (questionsContainer) {
      questionsContainer.innerHTML = '';
      r.coaching_questions.forEach((q, idx) => {
        const item = document.createElement('div');
        item.style.background = 'var(--bg-secondary)';
        item.style.border = '1px solid var(--border-subtle)';
        item.style.borderRadius = 'var(--radius-sm)';
        item.style.padding = '14px';
        item.style.marginBottom = '10px';
        item.style.display = 'flex';
        item.style.gap = '12px';
        item.style.alignItems = 'flex-start';

        item.innerHTML = `
          <div style="width: 24px; height: 24px; border-radius: 50%; background: var(--bg-tertiary); display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; color: var(--accent-blue); flex-shrink: 0;">
            ${idx + 1}
          </div>
          <div style="font-size: 13px; color: var(--text-main); line-height: 1.5;">
            ${q}
          </div>
        `;
        questionsContainer.appendChild(item);
      });
    }
  }
};
