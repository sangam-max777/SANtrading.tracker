/**
 * TradeVault Settings View Controller
 */

window.SettingsView = {
  load() {
    this.populateSettings();
    this.setupSaveButton();
  },

  populateSettings() {
    const s = App.settings;
    if (!s) return;

    const nameInput = document.getElementById('setting-app-name');
    if (nameInput) nameInput.value = s.app_name || 'TradeVault';

    const currInput = document.getElementById('setting-currency');
    if (currInput) currInput.value = s.currency || 'USD';

    const tzInput = document.getElementById('setting-timezone');
    if (tzInput) tzInput.value = s.timezone || 'UTC';

    const themeInput = document.getElementById('setting-theme');
    if (themeInput) themeInput.value = s.theme || 'charcoal';

    const riskInput = document.getElementById('setting-default-risk');
    if (riskInput) riskInput.value = s.default_risk_pct || '1.0';

    const geminiInput = document.getElementById('setting-gemini-key');
    if (geminiInput) {
      geminiInput.placeholder = s.gemini_api_key_set ? "API Key Configured (Hidden)" : "AIzaSy...";
      if (!s.gemini_api_key_set) geminiInput.value = '';
    }

    const openaiInput = document.getElementById('setting-openai-key');
    if (openaiInput) {
      openaiInput.placeholder = s.openai_api_key_set ? "API Key Configured (Hidden)" : "sk-...";
      if (!s.openai_api_key_set) openaiInput.value = '';
    }

    const providerInput = document.getElementById('setting-ai-provider');
    if (providerInput) providerInput.value = s.ai_provider || 'gemini';
  },

  setupSaveButton() {
    const btn = document.getElementById('btn-save-settings');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = 'true';

    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const payload = {
        app_name: document.getElementById('setting-app-name')?.value || 'TradeVault',
        currency: document.getElementById('setting-currency')?.value || 'USD',
        timezone: document.getElementById('setting-timezone')?.value || 'UTC',
        theme: document.getElementById('setting-theme')?.value || 'charcoal',
        default_risk_pct: document.getElementById('setting-default-risk')?.value || '1.0',
        ai_provider: document.getElementById('setting-ai-provider')?.value || 'gemini'
      };

      const currencySymbols = { 'USD': '$', 'EUR': '€', 'GBP': '£', 'JPY': '¥', 'AUD': 'A$', 'CAD': 'C$' };
      payload.currency_symbol = currencySymbols[payload.currency] || '$';

      const geminiVal = document.getElementById('setting-gemini-key')?.value;
      if (geminiVal && !geminiVal.includes('...')) {
        payload.gemini_api_key = geminiVal.trim();
      }

      const openaiVal = document.getElementById('setting-openai-key')?.value;
      if (openaiVal && !openaiVal.includes('...')) {
        payload.openai_api_key = openaiVal.trim();
      }

      try {
        await API.updateSettings(payload);
        App.showToast("Settings saved successfully", "success");
        await App.loadInitialData();
      } catch (err) {
        App.showToast("Failed to save settings: " + err.message, "error");
      }
    });
  }
};
