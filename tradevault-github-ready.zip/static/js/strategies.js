/**
 * TradeVault Strategy Analytics View Controller
 * Strategy comparative performance, sample size validation badges,
 * and custom strategy creation.
 */

window.StrategiesView = {
  analytics: [],

  async load() {
    this.setupNewStrategyButton();
    await this.fetchAndRender();
  },

  setupNewStrategyButton() {
    const btn = document.getElementById('btn-open-new-strat-modal');
    const modal = document.getElementById('new-strategy-modal');
    if (btn && !btn.dataset.bound) {
      btn.dataset.bound = 'true';
      btn.addEventListener('click', () => {
        if (modal) modal.classList.add('active');
      });
    }

    const saveBtn = document.getElementById('btn-save-new-strategy');
    if (saveBtn && !saveBtn.dataset.bound) {
      saveBtn.dataset.bound = 'true';
      saveBtn.addEventListener('click', async () => {
        const name = document.getElementById('new-strat-name')?.value;
        const desc = document.getElementById('new-strat-desc')?.value;
        const setups = document.getElementById('new-strat-setups')?.value;
        const color = document.getElementById('new-strat-color')?.value || '#3b82f6';

        if (!name) {
          App.showToast("Strategy name is required.", "warning");
          return;
        }

        try {
          await API.createStrategy({ name, description: desc, setup_types: setups, color });
          App.showToast("Strategy created successfully", "success");
          modal.classList.remove('active');
          document.getElementById('new-strat-form')?.reset();
          await App.loadInitialData();
          await this.fetchAndRender();
        } catch (err) {
          App.showToast("Error creating strategy: " + err.message, "error");
        }
      });
    }
  },

  async fetchAndRender() {
    try {
      const res = await API.getStrategiesAnalytics();
      this.analytics = res.strategies_analytics || [];
      this.render();
    } catch (err) {
      App.showToast("Failed to load strategy analytics: " + err.message, "error");
    }
  },

  render() {
    const container = document.getElementById('strategies-cards-container');
    if (!container) return;
    container.innerHTML = '';

    if (this.analytics.length === 0) {
      container.innerHTML = `<div style="color: var(--text-muted); padding: 30px;">No strategies created yet. Click "+ New Strategy" to begin.</div>`;
      return;
    }

    this.analytics.forEach(item => {
      const s = item.strategy;
      const count = item.trade_count;
      const level = item.sample_size_level;

      let badgeClass = 'badge-neutral';
      if (level === 'low') badgeClass = 'badge-warning';
      else if (level === 'medium') badgeClass = 'badge-neutral';
      else if (level === 'high') badgeClass = 'badge-profit';

      const card = document.createElement('div');
      card.className = 'panel';
      card.style.borderLeft = `4px solid ${s.color || '#3b82f6'}`;

      card.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; flex-wrap: wrap; gap: 10px;">
          <div>
            <h3 style="font-size: 17px; font-weight: 800; color: #fff;">${s.name}</h3>
            <p style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">${s.description || 'No description provided'}</p>
          </div>
          <div>
            <span class="${badgeClass}">${item.sample_size_rating}</span>
          </div>
        </div>

        <div class="grid-cards" style="margin-bottom: 16px;">
          <div class="stat-card">
            <span class="stat-card-title">Net Realized P/L</span>
            <span class="stat-card-value">${App.formatPnL(item.net_pnl)}</span>
            <span class="stat-card-sub font-mono">${count} trades</span>
          </div>
          <div class="stat-card">
            <span class="stat-card-title">Win Rate</span>
            <span class="stat-card-value font-mono" style="color: ${item.win_rate >= 50 ? 'var(--profit)' : 'var(--loss)'};">${item.win_rate}%</span>
            <span class="stat-card-sub">Long: ${item.long_vs_short.long_win_rate}% | Short: ${item.long_vs_short.short_win_rate}%</span>
          </div>
          <div class="stat-card">
            <span class="stat-card-title">Profit Factor</span>
            <span class="stat-card-value font-mono">${item.profit_factor > 0 ? item.profit_factor.toFixed(2) : '0.00'}</span>
            <span class="stat-card-sub">Avg R: ${item.avg_rr}R</span>
          </div>
          <div class="stat-card">
            <span class="stat-card-title">Best Session</span>
            <span class="stat-card-value" style="font-size: 16px; color: #fff;">${item.best_session}</span>
            <span class="stat-card-sub">Peak execution window</span>
          </div>
        </div>

        ${item.common_mistakes.length > 0 ? `
          <div style="background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px 14px; font-size: 12px; display: flex; align-items: center; gap: 10px;">
            <strong style="color: var(--warning);">Common Leaks:</strong>
            ${item.common_mistakes.map(m => `<span class="badge-warning">${m.mistake} (${m.count}x)</span>`).join(' ')}
          </div>
        ` : ''}
      `;

      container.appendChild(card);
    });
  }
};
