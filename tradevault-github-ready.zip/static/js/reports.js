/**
 * TradeVault Reports & Data Export View Controller
 */

window.ReportsView = {
  load() {
    this.setupButtons();
  },

  setupButtons() {
    // CSV Download
    const csvBtn = document.getElementById('btn-download-csv');
    if (csvBtn && !csvBtn.dataset.bound) {
      csvBtn.dataset.bound = 'true';
      csvBtn.addEventListener('click', () => {
        API.downloadCsv();
        App.showToast("CSV export initiated", "success");
      });
    }

    // Print / PDF View
    const printBtn = document.getElementById('btn-print-report');
    if (printBtn && !printBtn.dataset.bound) {
      printBtn.dataset.bound = 'true';
      printBtn.addEventListener('click', () => {
        window.print();
      });
    }

    // JSON Backup Download
    const backupBtn = document.getElementById('btn-download-backup');
    if (backupBtn && !backupBtn.dataset.bound) {
      backupBtn.dataset.bound = 'true';
      backupBtn.addEventListener('click', async () => {
        try {
          const data = await API.getBackup();
          const str = JSON.stringify(data, null, 2);
          const blob = new Blob([str], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `tradevault_backup_${new Date().toISOString().substring(0, 10)}.json`;
          a.click();
          URL.revokeObjectURL(url);
          App.showToast("Backup exported successfully", "success");
        } catch (err) {
          App.showToast("Error generating backup: " + err.message, "error");
        }
      });
    }

    // JSON Restore Upload
    const restoreInput = document.getElementById('restore-file-input');
    const restoreBtn = document.getElementById('btn-trigger-restore');
    if (restoreBtn && !restoreBtn.dataset.bound) {
      restoreBtn.dataset.bound = 'true';
      restoreBtn.addEventListener('click', () => restoreInput.click());
    }

    if (restoreInput && !restoreInput.dataset.bound) {
      restoreInput.dataset.bound = 'true';
      restoreInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (!confirm("Restoring will replace current journal data. Proceed?")) {
          restoreInput.value = '';
          return;
        }

        try {
          const text = await file.text();
          const data = JSON.parse(text);
          const res = await API.restoreBackup(data);
          App.showToast(res.message, "success");
          await App.loadInitialData();
          App.refreshCurrentView();
        } catch (err) {
          App.showToast("Restore failed: " + err.message, "error");
        }
      });
    }

    // Reset Demo Data
    const resetBtn = document.getElementById('btn-reset-demo-data');
    if (resetBtn && !resetBtn.dataset.bound) {
      resetBtn.dataset.bound = 'true';
      resetBtn.addEventListener('click', async () => {
        if (!confirm("Reset database to realistic funded account demo dataset?")) return;
        try {
          await API.resetDemoData();
          App.showToast("Demo data reseeded successfully!", "success");
          await App.loadInitialData();
          App.refreshCurrentView();
        } catch (err) {
          App.showToast("Reset failed: " + err.message, "error");
        }
      });
    }
  }
};
