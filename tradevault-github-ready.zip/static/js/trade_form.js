/**
 * TradeVault Manual Trade Entry View Controller
 * Form with real-time automatic calculations for Pips, P/L, Risk %, and R-multiples.
 */

window.TradeFormView = {
  load() {
    this.setupAutoCalculations();
    this.setupSubmitButton();
    this.populateDefaults();
  },

  populateDefaults() {
    const dateInput = document.getElementById('form-trade-date');
    if (dateInput && !dateInput.value) {
      const now = new Date();
      dateInput.value = now.toISOString().substring(0, 16);
    }
  },

  setupAutoCalculations() {
    const calcInputs = ['form-entry-price', 'form-exit-price', 'form-stop-loss', 'form-take-profit', 'form-lot-size', 'form-instrument', 'form-side', 'form-gross-pnl', 'form-commission', 'form-swap'];
    calcInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el && !el.dataset.bound) {
        el.dataset.bound = 'true';
        el.addEventListener('input', () => this.recomputeLiveMetrics());
      }
    });
  },

  recomputeLiveMetrics() {
    const inst = (document.getElementById('form-instrument')?.value || 'EURUSD').toUpperCase();
    const side = document.getElementById('form-side')?.value || 'BUY';
    const entry = parseFloat(document.getElementById('form-entry-price')?.value) || 0;
    const exit = parseFloat(document.getElementById('form-exit-price')?.value) || 0;
    const sl = parseFloat(document.getElementById('form-stop-loss')?.value) || 0;
    const tp = parseFloat(document.getElementById('form-take-profit')?.value) || 0;
    const lots = parseFloat(document.getElementById('form-lot-size')?.value) || 1;
    let gross = parseFloat(document.getElementById('form-gross-pnl')?.value) || 0;
    const comm = parseFloat(document.getElementById('form-commission')?.value) || 0;
    const swap = parseFloat(document.getElementById('form-swap')?.value) || 0;

    // Automatic Gross P/L estimation if entry and exit provided and gross not manually overridden
    if (entry > 0 && exit > 0 && document.getElementById('form-gross-pnl')?.dataset.auto !== 'false') {
      let multiplier = 100000; // standard forex lot
      if (inst.includes('XAU') || inst.includes('GOLD')) multiplier = 100;
      else if (inst.includes('US30') || inst.includes('NAS') || inst.includes('SPX')) multiplier = 1;
      else if (inst.includes('BTC') || inst.includes('CRYPTO')) multiplier = 1;

      const priceDiff = side === 'BUY' ? (exit - entry) : (entry - exit);
      gross = Math.round(priceDiff * lots * multiplier * 100) / 100;
      const grossEl = document.getElementById('form-gross-pnl');
      if (grossEl) grossEl.value = gross;
    }

    const net = Math.round((gross + comm + swap) * 100) / 100;
    const netEl = document.getElementById('form-net-pnl');
    if (netEl) netEl.value = net;

    // R-multiple calculations
    if (sl > 0 && entry > 0) {
      const riskDistance = Math.abs(entry - sl);
      if (riskDistance > 0) {
        // Actual RR
        if (exit > 0) {
          const rewardDistance = side === 'BUY' ? (exit - entry) : (entry - exit);
          const actRR = Math.round((rewardDistance / riskDistance) * 100) / 100;
          const actRREl = document.getElementById('form-actual-rr');
          if (actRREl) actRREl.value = actRR;
        }

        // Planned RR
        if (tp > 0) {
          const plannedReward = Math.abs(tp - entry);
          const planRR = Math.round((plannedReward / riskDistance) * 100) / 100;
          const planRREl = document.getElementById('form-planned-rr');
          if (planRREl) planRREl.value = planRR;
        }

        // Estimated Risk Amount in Dollars
        let multiplier = 100000;
        if (inst.includes('XAU')) multiplier = 100;
        else if (inst.includes('US30') || inst.includes('NAS')) multiplier = 1;
        const riskDollars = Math.round(riskDistance * lots * multiplier * 100) / 100;
        const riskAmtEl = document.getElementById('form-risk-amount');
        if (riskAmtEl && !riskAmtEl.value) riskAmtEl.value = riskDollars;
      }
    }
  },

  setupSubmitButton() {
    const btn = document.getElementById('btn-save-trade-form');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = 'true';

    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      await this.saveTrade();
    });
  },

  async saveTrade() {
    const inst = document.getElementById('form-instrument')?.value;
    const entry = parseFloat(document.getElementById('form-entry-price')?.value);
    const exit = parseFloat(document.getElementById('form-exit-price')?.value);

    if (!inst || isNaN(entry) || isNaN(exit)) {
      App.showToast("Please provide at least Instrument, Entry Price, and Exit Price.", "warning");
      return;
    }

    const tradeDate = document.getElementById('form-trade-date')?.value || new Date().toISOString();
    const tradeData = {
      ticket_id: document.getElementById('form-ticket-id')?.value || '',
      account_id: document.getElementById('form-account-id')?.value || null,
      strategy_id: document.getElementById('form-strategy-id')?.value || null,
      instrument: inst.toUpperCase(),
      side: document.getElementById('form-side')?.value || 'BUY',
      lot_size: parseFloat(document.getElementById('form-lot-size')?.value) || 1.0,
      entry_price: entry,
      exit_price: exit,
      stop_loss: parseFloat(document.getElementById('form-stop-loss')?.value) || 0.0,
      take_profit: parseFloat(document.getElementById('form-take-profit')?.value) || 0.0,
      gross_pnl: parseFloat(document.getElementById('form-gross-pnl')?.value) || 0.0,
      commission: parseFloat(document.getElementById('form-commission')?.value) || 0.0,
      swap: parseFloat(document.getElementById('form-swap')?.value) || 0.0,
      net_pnl: parseFloat(document.getElementById('form-net-pnl')?.value) || 0.0,
      risk_amount: parseFloat(document.getElementById('form-risk-amount')?.value) || 0.0,
      risk_pct: parseFloat(document.getElementById('form-risk-pct')?.value) || 1.0,
      planned_rr: parseFloat(document.getElementById('form-planned-rr')?.value) || 0.0,
      actual_rr: parseFloat(document.getElementById('form-actual-rr')?.value) || 0.0,
      session: document.getElementById('form-session')?.value || 'London',
      setup_type: document.getElementById('form-setup-type')?.value || '',
      market_condition: document.getElementById('form-market-condition')?.value || 'Trending',
      entry_reason: document.getElementById('form-entry-reason')?.value || '',
      exit_reason: document.getElementById('form-exit-reason')?.value || '',
      emotional_state: document.getElementById('form-emotional-state')?.value || 'Disciplined',
      discipline_rating: parseInt(document.getElementById('form-discipline-rating')?.value || '5'),
      mistakes: document.getElementById('form-mistakes')?.value || 'None',
      lessons: document.getElementById('form-lessons')?.value || '',
      notes: document.getElementById('form-notes')?.value || '',
      open_time: tradeDate,
      close_time: tradeDate,
      status: 'CLOSED'
    };

    try {
      await API.createTrade(tradeData);
      App.showToast("Trade saved to journal successfully!", "success");
      // Reset form
      document.getElementById('form-manual-entry')?.reset();
      this.populateDefaults();
      // Navigate to Trades view
      App.navigateTo('trades');
    } catch (err) {
      App.showToast("Failed to save trade: " + err.message, "error");
    }
  }
};
