/**
 * TradeVault API Client
 */

window.API = {
  baseUrl: '',

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const defaultHeaders = {
      'Accept': 'application/json'
    };
    if (!(options.body instanceof FormData)) {
      defaultHeaders['Content-Type'] = 'application/json';
    }

    const config = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers
      }
    };

    try {
      const response = await fetch(url, config);
      if (!response.ok) {
        let errMsg = `HTTP Error ${response.status}`;
        try {
          const errData = await response.json();
          errMsg = errData.error || errMsg;
        } catch (_) {}
        throw new Error(errMsg);
      }

      // Check if response is JSON or file blob
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        return await response.json();
      } else {
        return await response.blob();
      }
    } catch (err) {
      console.error(`[API Error] ${endpoint}:`, err);
      throw err;
    }
  },

  // Settings
  getSettings() { return this.request('/api/settings'); },
  updateSettings(data) { return this.request('/api/settings', { method: 'POST', body: JSON.stringify(data) }); },

  // Accounts
  getAccounts() { return this.request('/api/accounts'); },
  createAccount(data) { return this.request('/api/accounts', { method: 'POST', body: JSON.stringify(data) }); },
  updateAccount(id, data) { return this.request(`/api/accounts/${id}`, { method: 'PUT', body: JSON.stringify(data) }); },
  deleteAccount(id) { return this.request(`/api/accounts/${id}`, { method: 'DELETE' }); },
  getPropStatus() { return this.request('/api/accounts/prop-status'); },

  // Strategies
  getStrategies() { return this.request('/api/strategies'); },
  createStrategy(data) { return this.request('/api/strategies', { method: 'POST', body: JSON.stringify(data) }); },
  deleteStrategy(id) { return this.request(`/api/strategies/${id}`, { method: 'DELETE' }); },
  getStrategiesAnalytics() { return this.request('/api/strategies/analytics'); },

  // Trades
  getTrades(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/api/trades${query ? '?' + query : ''}`);
  },
  getTrade(id) { return this.request(`/api/trades/${id}`); },
  createTrade(data) { return this.request('/api/trades', { method: 'POST', body: JSON.stringify(data) }); },
  updateTrade(id, data) { return this.request(`/api/trades/${id}`, { method: 'PUT', body: JSON.stringify(data) }); },
  duplicateTrade(id) { return this.request(`/api/trades/${id}/duplicate`, { method: 'POST' }); },
  deleteTrade(id) { return this.request(`/api/trades/${id}`, { method: 'DELETE' }); },

  // Dashboard Stats
  getDashboard(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/api/dashboard${query ? '?' + query : ''}`);
  },

  // Calendar
  getCalendar(year, month, accountId = null) {
    const params = { year, month };
    if (accountId) params.account_id = accountId;
    const query = new URLSearchParams(params).toString();
    return this.request(`/api/calendar?${query}`);
  },

  // Goals
  getGoals() { return this.request('/api/goals'); },
  createGoal(data) { return this.request('/api/goals', { method: 'POST', body: JSON.stringify(data) }); },
  updateGoal(id, data) { return this.request(`/api/goals/${id}`, { method: 'PUT', body: JSON.stringify(data) }); },
  deleteGoal(id) { return this.request(`/api/goals/${id}`, { method: 'DELETE' }); },

  // AI Screenshot Extraction
  extractScreenshots(filesList) {
    // filesList is array of {filename, data_base64, mime_type}
    return this.request('/api/ai/extract-screenshots', {
      method: 'POST',
      body: JSON.stringify({ files: filesList })
    });
  },
  batchSaveTrades(data) {
    return this.request('/api/ai/batch-save-trades', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  // AI Trading Coach
  getCoachReport() { return this.request('/api/ai/coach'); },

  // Data & Reports
  downloadCsv() {
    window.location.href = '/api/reports/csv';
  },
  getBackup() { return this.request('/api/reports/backup'); },
  restoreBackup(data) {
    return this.request('/api/reports/restore', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },
  resetDemoData() {
    return this.request('/api/demo/reset', { method: 'POST' });
  }
};
