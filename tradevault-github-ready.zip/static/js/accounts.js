/**
 * TradeVault Prop-Firm Accounts & Challenges Controller
 * Strict prop-firm risk monitoring, daily drawdown cushions,
 * trailing vs balance-based drawdowns, and profit target tracking.
 */

window.AccountsView = {
  accountsStatus: [],

  async load() {
    this.setupNewAccountModal();
    await this.fetchAndRender();
  },

  setupNewAccountModal() {
    const btn = document.getElementById('btn-open-new-acc-modal');
    const modal = document.getElementById('new-account-modal');
    if (btn && !btn.dataset.bound) {
      btn.dataset.bound = 'true';
      btn.addEventListener('click', () => {
        if (modal) modal.classList.add('active');
      });
    }

    const saveBtn = document.getElementById('btn-save-new-account');
    if (saveBtn && !saveBtn.dataset.bound) {
      saveBtn.dataset.bound = 'true';
      saveBtn.addEventListener('click', async () => {
        const name = document.getElementById('new-acc-name')?.value;
        const broker = document.getElementById('new-acc-broker')?.value;
        const startBal = parseFloat(document.getElementById('new-acc-start-bal')?.value) || 100000;
        const targetPct = parseFloat(document.getElementById('new-acc-target-pct')?.value) || 10;
        const dailyLossPct = parseFloat(document.getElementById('new-acc-daily-loss-pct')?.value) || 5;
        const totalLossPct = parseFloat(document.getElementById('new-acc-total-loss-pct')?.value) || 10;
        const ddType = document.getElementById('new-acc-dd-type')?.value || 'balance_based';
        const phase = document.getElementById('new-acc-phase')?.value || 'Phase 1';

        if (!name) {
          App.showToast("Account name is required.", "warning");
          return;
        }

        try {
          await API.createAccount({
            name, broker, starting_balance: startBal, profit_target_pct: targetPct,
            max_daily_loss_pct: dailyLossPct, max_total_loss_pct: totalLossPct,
            drawdown_type: ddType, phase
          });
          App.showToast("Account added successfully", "success");
          modal.classList.remove('active');
          document.getElementById('new-account-form')?.reset();
          await App.loadInitialData();
          await this.fetchAndRender();
        } catch (err) {
          App.showToast("Error creating account: " + err.message, "error");
        }
      });
    }
  },

  async fetchAndRender() {
    try {
      const res = await API.getPropStatus();
      this.accountsStatus = res.accounts_status || [];
      this.render();
    } catch (err) {
      App.showToast("Failed to load accounts: " + err.message, "error");
    }
  },

  render() {
    const container = document.getElementById('accounts-cards-container');
    if (!container) return;
    container.innerHTML = '';

    if (this.accountsStatus.length === 0) {
      container.innerHTML = `<div style="color: var(--text-muted); padding: 30px;">No accounts found. Click "+ Add Account" to create your funded challenge.</div>`;
      return;
    }

    this.accountsStatus.forEach(acc => {
      const card = document.createElement('div');
      card.className = 'panel';

      const isBreached = acc.daily_breached || acc.total_breached;
      const isTargetPassed = acc.target_hit;

      let statusBadge = `<span class="badge-neutral">${acc.phase}</span>`;
      if (isBreached) {
        statusBadge = `<span class="badge-loss">RULE BREACHED</span>`;
      } else if (isTargetPassed) {
        statusBadge = `<span class="badge-profit">TARGET ACHIEVED 🎉</span>`;
      } else if (acc.daily_warning || acc.total_warning) {
        statusBadge = `<span class="badge-warning">DRAWDOWN WARNING ⚠️</span>`;
      }

      card.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
          <div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <h3 style="font-size: 18px; font-weight: 800; color: #fff;">${acc.account_name}</h3>
              <span class="badge-neutral">${acc.broker || 'Prop Firm'}</span>
            </div>
            <p style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
              Starting: <strong>$${acc.starting_balance.toLocaleString()}</strong> | 
              Calculation Rule: <strong>${acc.drawdown_type.replace('_', ' ').toUpperCase()}</strong>
            </p>
          </div>
          <div>
            ${statusBadge}
          </div>
        </div>

        <div class="grid-cards" style="margin-bottom: 20px;">
          <div class="stat-card">
            <span class="stat-card-title">Current Balance</span>
            <span class="stat-card-value font-mono">$${acc.current_balance.toLocaleString()}</span>
            <span class="stat-card-sub font-mono">Net P/L: ${App.formatPnL(acc.total_net_pnl)}</span>
          </div>
          <div class="stat-card">
            <span class="stat-card-title">Profit Target Progress</span>
            <span class="stat-card-value font-mono" style="color: var(--profit);">${acc.target_progress_pct}%</span>
            <span class="stat-card-sub">Remaining: $${acc.remaining_to_target.toLocaleString()}</span>
          </div>
          <div class="stat-card">
            <span class="stat-card-title">Daily Loss Cushion</span>
            <span class="stat-card-value font-mono" style="color: ${acc.daily_warning ? 'var(--loss)' : 'var(--text-main)'};">$${acc.remaining_daily_cushion.toLocaleString()}</span>
            <span class="stat-card-sub font-mono">Today P/L: ${App.formatPnL(acc.today_pnl)}</span>
          </div>
          <div class="stat-card">
            <span class="stat-card-title">Total Max DD Cushion</span>
            <span class="stat-card-value font-mono" style="color: ${acc.total_warning ? 'var(--loss)' : 'var(--text-main)'};">$${acc.remaining_total_cushion.toLocaleString()}</span>
            <span class="stat-card-sub">Max Limit: $${acc.total_loss_limit.toLocaleString()}</span>
          </div>
        </div>

        <!-- Target Progress Bar -->
        <div style="margin-bottom: 14px;">
          <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px;">
            <span class="text-muted">Target Progress ($${acc.total_net_pnl.toLocaleString()} / $${acc.target_amount.toLocaleString()})</span>
            <span class="font-mono text-profit">${acc.target_progress_pct}%</span>
          </div>
          <div style="height: 6px; background: var(--bg-tertiary); border-radius: 3px; overflow: hidden;">
            <div style="height: 100%; width: ${Math.min(acc.target_progress_pct, 100)}%; background: #10b981; border-radius: 3px; transition: width 0.3s ease;"></div>
          </div>
        </div>

        <!-- Daily Drawdown Bar -->
        <div style="margin-bottom: 14px;">
          <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 4px;">
            <span class="text-muted">Daily Drawdown Used ($${acc.current_daily_loss.toLocaleString()} / $${acc.daily_loss_limit.toLocaleString()})</span>
            <span class="font-mono ${acc.daily_warning ? 'text-loss' : 'text-muted'}">${acc.daily_loss_used_pct}%</span>
          </div>
          <div style="height: 6px; background: var(--bg-tertiary); border-radius: 3px; overflow: hidden;">
            <div style="height: 100%; width: ${Math.min(acc.daily_loss_used_pct, 100)}%; background: ${acc.daily_warning ? '#ef4444' : '#f59e0b'}; border-radius: 3px; transition: width 0.3s ease;"></div>
          </div>
        </div>
      `;

      container.appendChild(card);
    });
  }
};
