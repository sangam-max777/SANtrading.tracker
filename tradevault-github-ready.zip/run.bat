@echo off
title TradeVault Institutional Journal
echo =======================================================
echo Starting TradeVault Institutional Trading Journal...
echo =======================================================
python app.py
pause
