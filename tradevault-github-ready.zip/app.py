"""
TradeVault Main Application Server
Full RESTful API server with SQLite persistence, AI Vision screenshot extraction,
analytics calculations, prop-firm tracking, and static web serving.
Runs on Python 3.x standard library with zero external dependencies required.
"""

import sys
import os
import json
import uuid
import csv
import io
import mimetypes
import email
from email.policy import default
from datetime import datetime, date
from urllib.parse import urlparse, parse_qs
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

# Import local modules
import database
import analytics
import ai_extractor
import ai_coach

PORT = int(os.environ.get("PORT", 8080))
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
UPLOADS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
SAMPLES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_screenshots")

os.makedirs(STATIC_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(SAMPLES_DIR, exist_ok=True)

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class TradeVaultHandler(BaseHTTPRequestHandler):

    def send_json(self, status_code, data):
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def send_file(self, file_path, content_type=None):
        if not os.path.exists(file_path) or os.path.isdir(file_path):
            self.send_error(404, "File Not Found")
            return
        if not content_type:
            content_type, _ = mimetypes.guess_type(file_path)
            content_type = content_type or "application/octet-stream"
        
        try:
            with open(file_path, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Error reading file: {e}")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def parse_json_body(self):
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            return {}
        raw = self.rfile.read(content_length).decode("utf-8")
        return json.loads(raw)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        # 1. API routes
        if path.startswith("/api/"):
            try:
                self.handle_api_get(path, query)
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.send_json(500, {"error": str(e)})
            return

        # 2. Uploads and Static files
        if path.startswith("/uploads/"):
            filename = os.path.basename(path)
            self.send_file(os.path.join(UPLOADS_DIR, filename))
            return

        if path.startswith("/sample_screenshots/"):
            filename = os.path.basename(path)
            self.send_file(os.path.join(SAMPLES_DIR, filename))
            return

        # Serve static frontend files
        rel_path = path.lstrip("/")
        if not rel_path or rel_path == "":
            rel_path = "index.html"
        local_path = os.path.join(STATIC_DIR, rel_path)
        if os.path.exists(local_path) and not os.path.isdir(local_path):
            self.send_file(local_path)
        else:
            # Fallback to index.html for SPA routing
            self.send_file(os.path.join(STATIC_DIR, "index.html"))

    def handle_api_get(self, path, query):
        conn = database.get_connection()
        try:
            self._dispatch_api_get(conn, path, query)
        finally:
            conn.close()

    def _dispatch_api_get(self, conn, path, query):
        if path == "/api/settings":
            settings = database.get_all_settings()
            # Mask API keys for safety in client response
            masked = dict(settings)
            if masked.get("gemini_api_key"):
                masked["gemini_api_key_set"] = True
                masked["gemini_api_key"] = masked["gemini_api_key"][:4] + "..." + masked["gemini_api_key"][-4:]
            else:
                masked["gemini_api_key_set"] = False

            if masked.get("openai_api_key"):
                masked["openai_api_key_set"] = True
                masked["openai_api_key"] = masked["openai_api_key"][:4] + "..." + masked["openai_api_key"][-4:]
            else:
                masked["openai_api_key_set"] = False
            self.send_json(200, masked)

        elif path == "/api/accounts":
            accounts = [dict(r) for r in conn.execute("SELECT * FROM accounts ORDER BY name ASC").fetchall()]
            self.send_json(200, {"accounts": accounts})

        elif path == "/api/strategies":
            strategies = [dict(r) for r in conn.execute("SELECT * FROM strategies ORDER BY name ASC").fetchall()]
            self.send_json(200, {"strategies": strategies})

        elif path == "/api/trades":
            # Filter params
            acc_id = query.get("account_id", [None])[0]
            strat_id = query.get("strategy_id", [None])[0]
            inst = query.get("instrument", [None])[0]
            session = query.get("session", [None])[0]
            side = query.get("side", [None])[0]
            start_date = query.get("start_date", [None])[0]
            end_date = query.get("end_date", [None])[0]

            rows = [dict(r) for r in conn.execute("SELECT * FROM trades ORDER BY close_time DESC").fetchall()]
            filtered = analytics.filter_trades(
                rows,
                account_id=acc_id,
                strategy_id=strat_id,
                instrument=inst,
                session=session,
                side=side,
                start_date=start_date,
                end_date=end_date
            )
            self.send_json(200, {"trades": filtered, "total_count": len(filtered)})

        elif path.startswith("/api/trades/"):
            trade_id = path.split("/")[3]
            row = conn.execute("SELECT * FROM trades WHERE id = ?", (trade_id,)).fetchone()
            if row:
                self.send_json(200, {"trade": dict(row)})
            else:
                self.send_json(404, {"error": "Trade not found"})

        elif path == "/api/dashboard":
            acc_id = query.get("account_id", [None])[0]
            strat_id = query.get("strategy_id", [None])[0]
            inst = query.get("instrument", [None])[0]
            session = query.get("session", [None])[0]
            start_date = query.get("start_date", [None])[0]
            end_date = query.get("end_date", [None])[0]

            all_trades = [dict(r) for r in conn.execute("SELECT * FROM trades ORDER BY close_time ASC").fetchall()]
            filtered_trades = analytics.filter_trades(
                all_trades,
                account_id=acc_id,
                strategy_id=strat_id,
                instrument=inst,
                session=session,
                start_date=start_date,
                end_date=end_date
            )

            account = None
            if acc_id:
                acc_row = conn.execute("SELECT * FROM accounts WHERE id = ?", (acc_id,)).fetchone()
                if acc_row:
                    account = dict(acc_row)

            stats = analytics.calculate_dashboard_metrics(filtered_trades, account)
            self.send_json(200, stats)

        elif path == "/api/calendar":
            year = int(query.get("year", [date.today().year])[0])
            month = int(query.get("month", [date.today().month])[0])
            acc_id = query.get("account_id", [None])[0]

            trades = [dict(r) for r in conn.execute("SELECT * FROM trades").fetchall()]
            if acc_id:
                trades = [t for t in trades if t.get("account_id") == acc_id]

            cal_data = analytics.calculate_calendar_month(trades, year, month)
            self.send_json(200, cal_data)

        elif path == "/api/strategies/analytics":
            strategies = [dict(r) for r in conn.execute("SELECT * FROM strategies ORDER BY name ASC").fetchall()]
            trades = [dict(r) for r in conn.execute("SELECT * FROM trades").fetchall()]
            results = [analytics.calculate_strategy_analytics(s, trades) for s in strategies]
            self.send_json(200, {"strategies_analytics": results})

        elif path == "/api/accounts/prop-status":
            accounts = [dict(r) for r in conn.execute("SELECT * FROM accounts WHERE status = 'active' ORDER BY name ASC").fetchall()]
            trades = [dict(r) for r in conn.execute("SELECT * FROM trades").fetchall()]
            statuses = [analytics.calculate_prop_firm_status(a, trades) for a in accounts]
            self.send_json(200, {"accounts_status": statuses})

        elif path == "/api/goals":
            goals = [dict(r) for r in conn.execute("SELECT * FROM goals ORDER BY created_at DESC").fetchall()]
            self.send_json(200, {"goals": goals})

        elif path == "/api/ai/coach":
            trades = [dict(r) for r in conn.execute("SELECT * FROM trades ORDER BY close_time ASC").fetchall()]
            strategies = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM strategies").fetchall()}
            accounts = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM accounts").fetchall()}
            settings = database.get_all_settings()

            coach_report = ai_coach.generate_coach_analysis(
                trades,
                strategies,
                accounts,
                api_key=settings.get("gemini_api_key"),
                ai_provider=settings.get("ai_provider", "gemini")
            )
            self.send_json(200, coach_report)

        elif path == "/api/reports/csv":
            trades = [dict(r) for r in conn.execute("SELECT * FROM trades ORDER BY close_time DESC").fetchall()]
            
            output = io.StringIO()
            fieldnames = [
                "ticket_id", "instrument", "side", "lot_size", "entry_price", "exit_price",
                "stop_loss", "take_profit", "gross_pnl", "commission", "swap", "net_pnl",
                "risk_amount", "risk_pct", "actual_rr", "session", "setup_type",
                "market_condition", "emotional_state", "discipline_rating", "mistakes",
                "open_time", "close_time"
            ]
            writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for t in trades:
                writer.writerow(t)

            csv_data = output.getvalue().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Disposition", f"attachment; filename=tradevault_trades_{date.today().isoformat()}.csv")
            self.send_header("Content-Length", str(len(csv_data)))
            self.end_headers()
            self.wfile.write(csv_data)

        elif path == "/api/reports/backup":
            trades = [dict(r) for r in conn.execute("SELECT * FROM trades").fetchall()]
            accounts = [dict(r) for r in conn.execute("SELECT * FROM accounts").fetchall()]
            strategies = [dict(r) for r in conn.execute("SELECT * FROM strategies").fetchall()]
            goals = [dict(r) for r in conn.execute("SELECT * FROM goals").fetchall()]
            settings = database.get_all_settings()

            backup = {
                "version": "1.0",
                "exported_at": datetime.utcnow().isoformat(),
                "accounts": accounts,
                "strategies": strategies,
                "trades": trades,
                "goals": goals,
                "settings": settings
            }
            self.send_json(200, backup)

        else:
            self.send_json(404, {"error": "API route not found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            try:
                self.handle_api_post(path)
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.send_json(500, {"error": str(e)})
            return

        self.send_error(404)

    def handle_api_post(self, path):
        conn = database.get_connection()
        try:
            if path == "/api/settings":
                body = self.parse_json_body()
                for k, v in body.items():
                    if k in ("app_name", "currency", "currency_symbol", "timezone", "theme", "default_risk_pct", "gemini_api_key", "openai_api_key", "ai_provider"):
                        database.set_setting(k, v)
                self.send_json(200, {"success": True, "message": "Settings updated"})

            elif path == "/api/accounts":
                body = self.parse_json_body()
                acc_id = str(uuid.uuid4())
                now = datetime.now().isoformat()
                conn.execute("""
                INSERT INTO accounts (id, name, broker, account_type, starting_balance, current_balance, current_equity, currency, profit_target_pct, max_daily_loss_pct, max_total_loss_pct, drawdown_type, phase, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    acc_id,
                    body.get("name", "New Account"),
                    body.get("broker", ""),
                    body.get("account_type", "funded_challenge"),
                    float(body.get("starting_balance", 100000.0)),
                    float(body.get("starting_balance", 100000.0)),
                    float(body.get("starting_balance", 100000.0)),
                    body.get("currency", "USD"),
                    float(body.get("profit_target_pct", 10.0)),
                    float(body.get("max_daily_loss_pct", 5.0)),
                    float(body.get("max_total_loss_pct", 10.0)),
                    body.get("drawdown_type", "balance_based"),
                    body.get("phase", "Phase 1"),
                    body.get("status", "active"),
                    now, now
                ))
                conn.commit()
                self.send_json(201, {"id": acc_id, "success": True})

            elif path == "/api/strategies":
                body = self.parse_json_body()
                strat_id = str(uuid.uuid4())
                now = datetime.now().isoformat()
                conn.execute("""
                INSERT INTO strategies (id, name, description, setup_types, color, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    strat_id,
                    body.get("name", "New Strategy"),
                    body.get("description", ""),
                    body.get("setup_types", ""),
                    body.get("color", "#3b82f6"),
                    now
                ))
                conn.commit()
                self.send_json(201, {"id": strat_id, "success": True})

            elif path == "/api/trades":
                body = self.parse_json_body()
                trade_id = str(uuid.uuid4())
                now = datetime.now().isoformat()

                account_id = (body.get("account_id") or "").strip() or None
                strategy_id = (body.get("strategy_id") or "").strip() or None
                if not account_id:
                    first_acc = conn.execute("SELECT id FROM accounts LIMIT 1").fetchone()
                    if first_acc:
                        account_id = first_acc["id"]

                # Automatic calculations
                entry = float(body.get("entry_price") or 0.0)
                exit_p = float(body.get("exit_price") or 0.0)
                sl = float(body.get("stop_loss") or 0.0)
                tp = float(body.get("take_profit") or 0.0)
                gross = float(body.get("gross_pnl") or 0.0)
                comm = float(body.get("commission") or 0.0)
                swap = float(body.get("swap") or 0.0)
                net = round(gross + comm + swap, 2)

                planned_rr = float(body.get("planned_rr") or 0.0)
                actual_rr = float(body.get("actual_rr") or 0.0)

                # Auto-calculate R-multiple if stop loss present
                if sl > 0 and entry > 0:
                    risk_dist = abs(entry - sl)
                    if risk_dist > 0:
                        if tp > 0 and planned_rr == 0.0:
                            planned_rr = round(abs(tp - entry) / risk_dist, 2)
                        if exit_p > 0 and actual_rr == 0.0:
                            reward_dist = (exit_p - entry) if body.get("side", "BUY") == "BUY" else (entry - exit_p)
                            actual_rr = round(reward_dist / risk_dist, 2)

                conn.execute("""
                INSERT INTO trades (
                    id, ticket_id, account_id, strategy_id, instrument, side, lot_size,
                    entry_price, exit_price, stop_loss, take_profit, gross_pnl, commission, swap,
                    net_pnl, risk_amount, risk_pct, planned_rr, actual_rr, session,
                    setup_type, market_condition, entry_reason, exit_reason, emotional_state,
                    discipline_rating, mistakes, lessons, notes, screenshots,
                    open_time, close_time, status, is_imported, import_source, import_confidence,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    trade_id,
                    body.get("ticket_id", ""),
                    account_id,
                    strategy_id,
                    body.get("instrument", "EURUSD"),
                    body.get("side", "BUY"),
                    float(body.get("lot_size", 1.0)),
                    entry, exit_p, sl, tp, gross, comm, swap, net,
                    float(body.get("risk_amount") or 0.0),
                    float(body.get("risk_pct") or 1.0),
                    planned_rr, actual_rr,
                    body.get("session", "London"),
                    body.get("setup_type", ""),
                    body.get("market_condition", "Trending"),
                    body.get("entry_reason", ""),
                    body.get("exit_reason", ""),
                    body.get("emotional_state", "Disciplined"),
                    int(body.get("discipline_rating", 5)),
                    body.get("mistakes", "None"),
                    body.get("lessons", ""),
                    body.get("notes", ""),
                    json.dumps(body.get("screenshots", [])),
                    body.get("open_time", now),
                    body.get("close_time", now),
                    body.get("status", "CLOSED"),
                    int(body.get("is_imported", 0)),
                    body.get("import_source", "manual"),
                    body.get("import_confidence", "high"),
                    now, now
                ))
                conn.commit()

                # Update account balance
                database.update_account_balance(account_id)
                self.send_json(201, {"id": trade_id, "success": True})

            elif path.startswith("/api/trades/") and path.endswith("/duplicate"):
                trade_id = path.split("/")[3]
                row = conn.execute("SELECT * FROM trades WHERE id = ?", (trade_id,)).fetchone()
                if not row:
                    self.send_json(404, {"error": "Trade not found"})
                    return

                orig = dict(row)
                new_id = str(uuid.uuid4())
                now = datetime.now().isoformat()
                orig["id"] = new_id
                orig["ticket_id"] = f"{orig['ticket_id']}_COPY" if orig["ticket_id"] else f"COPY_{new_id[:6]}"
                orig["created_at"] = now
                orig["updated_at"] = now

                conn.execute("""
                INSERT INTO trades (
                    id, ticket_id, account_id, strategy_id, instrument, side, lot_size,
                    entry_price, exit_price, stop_loss, take_profit, gross_pnl, commission, swap,
                    net_pnl, risk_amount, risk_pct, planned_rr, actual_rr, session,
                    setup_type, market_condition, entry_reason, exit_reason, emotional_state,
                    discipline_rating, mistakes, lessons, notes, screenshots,
                    open_time, close_time, status, is_imported, import_source, import_confidence,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    orig["id"], orig["ticket_id"], orig["account_id"], orig["strategy_id"], orig["instrument"],
                    orig["side"], orig["lot_size"], orig["entry_price"], orig["exit_price"], orig["stop_loss"],
                    orig["take_profit"], orig["gross_pnl"], orig["commission"], orig["swap"], orig["net_pnl"],
                    orig["risk_amount"], orig["risk_pct"], orig["planned_rr"], orig["actual_rr"], orig["session"],
                    orig["setup_type"], orig["market_condition"], orig["entry_reason"], orig["exit_reason"],
                    orig["emotional_state"], orig["discipline_rating"], orig["mistakes"], orig["lessons"],
                    orig["notes"], orig["screenshots"], orig["open_time"], orig["close_time"], orig["status"],
                    orig["is_imported"], orig["import_source"], orig["import_confidence"], orig["created_at"], orig["updated_at"]
                ))
                conn.commit()
                database.update_account_balance(orig["account_id"])
                self.send_json(201, {"id": new_id, "success": True, "message": "Trade duplicated successfully"})

            elif path == "/api/goals":
                body = self.parse_json_body()
                goal_id = str(uuid.uuid4())
                now = datetime.now().isoformat()
                conn.execute("""
                INSERT INTO goals (id, title, target_type, target_value, current_value, period, deadline, status, notes, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    goal_id,
                    body.get("title", "New Goal"),
                    body.get("target_type", "net_pnl"),
                    float(body.get("target_value", 1000.0)),
                    float(body.get("current_value", 0.0)),
                    body.get("period", "monthly"),
                    body.get("deadline", ""),
                    body.get("status", "in_progress"),
                    body.get("notes", ""),
                    now
                ))
                conn.commit()
                self.send_json(201, {"id": goal_id, "success": True})

            elif path == "/api/ai/extract-screenshots":
                # Handles multipart/form-data or JSON with base64 screenshots
                content_type = self.headers.get("Content-Type", "")
                existing_trades = [dict(r) for r in conn.execute("SELECT * FROM trades").fetchall()]
                settings = database.get_all_settings()

                extractions = []

                if "multipart/form-data" in content_type:
                    content_length = int(self.headers.get("Content-Length", 0))
                    body = self.rfile.read(content_length)
                    msg = email.message_from_bytes(
                        b"Content-Type: " + content_type.encode("utf-8") + b"\r\n\r\n" + body,
                        policy=default
                    )
                    for part in msg.iter_parts():
                        filename = part.get_filename()
                        if filename:
                            data = part.get_payload(decode=True)
                            save_path = os.path.join(UPLOADS_DIR, f"{uuid.uuid4()}_{filename}")
                            with open(save_path, "wb") as f_out:
                                f_out.write(data)
                            ext = ai_extractor.process_screenshot_upload(
                                filename, data, part.get_content_type() or "image/png", settings, existing_trades
                            )
                            ext["saved_file_path"] = f"/uploads/{os.path.basename(save_path)}"
                            extractions.append(ext)
                else:
                    body = self.parse_json_body()
                    files = body.get("files", [])
                    for f_info in files:
                        fname = f_info.get("filename", "screenshot.png")
                        b64_data = f_info.get("data_base64", "")
                        mime = f_info.get("mime_type", "image/png")
                        if "," in b64_data:
                            b64_data = b64_data.split(",", 1)[1]
                        import base64
                        data = base64.b64decode(b64_data)
                        save_path = os.path.join(UPLOADS_DIR, f"{uuid.uuid4()}_{fname}")
                        with open(save_path, "wb") as f_out:
                            f_out.write(data)
                        ext = ai_extractor.process_screenshot_upload(
                            fname, data, mime, settings, existing_trades
                        )
                        ext["saved_file_path"] = f"/uploads/{os.path.basename(save_path)}"
                        extractions.append(ext)

                if len(extractions) > 1:
                    batch_summary = ai_extractor.merge_multi_screenshot_extractions(extractions)
                    self.send_json(200, {
                        "extractions": extractions,
                        "batch_summary": batch_summary,
                        "is_multi": True
                    })
                elif len(extractions) == 1:
                    self.send_json(200, {
                        "extractions": extractions,
                        "summary": extractions[0]["summary"],
                        "trades": extractions[0]["trades"],
                        "is_multi": False
                    })
                else:
                    self.send_json(400, {"error": "No screenshots provided for extraction"})

            elif path == "/api/ai/batch-save-trades":
                # Saves user-confirmed trades after review
                body = self.parse_json_body()
                trades_to_save = body.get("trades", [])
                account_id = (body.get("account_id") or "").strip() or None
                strategy_id = (body.get("strategy_id") or "").strip() or None

                # Default to first account if none selected
                if not account_id:
                    first_acc = conn.execute("SELECT id FROM accounts LIMIT 1").fetchone()
                    if first_acc:
                        account_id = first_acc["id"]

                now = datetime.now().isoformat()
                saved_count = 0
                for tr in trades_to_save:
                    trade_id = str(uuid.uuid4())
                    entry = float(tr.get("entry_price") or 0.0)
                    exit_p = float(tr.get("exit_price") or 0.0)
                    sl = float(tr.get("stop_loss") or 0.0)
                    tp = float(tr.get("take_profit") or 0.0)
                    gross = float(tr.get("gross_pnl") or tr.get("net_pnl") or 0.0)
                    comm = float(tr.get("commission") or 0.0)
                    swap = float(tr.get("swap") or 0.0)
                    net = float(tr.get("net_pnl") or (gross + comm + swap))
                    actual_rr = float(tr.get("actual_rr") or 0.0)

                    conn.execute("""
                    INSERT INTO trades (
                        id, ticket_id, account_id, strategy_id, instrument, side, lot_size,
                        entry_price, exit_price, stop_loss, take_profit, gross_pnl, commission, swap,
                        net_pnl, risk_amount, risk_pct, planned_rr, actual_rr, session,
                        setup_type, market_condition, entry_reason, exit_reason, emotional_state,
                        discipline_rating, mistakes, lessons, notes, screenshots,
                        open_time, close_time, status, is_imported, import_source, import_confidence,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        trade_id,
                        tr.get("ticket_id", ""),
                        account_id,
                        strategy_id,
                        tr.get("instrument", "EURUSD"),
                        tr.get("side", "BUY"),
                        float(tr.get("lot_size") or 1.0),
                        entry, exit_p, sl, tp, gross, comm, swap, net,
                        float(tr.get("risk_amount") or 0.0),
                        float(tr.get("risk_pct") or 1.0),
                        float(tr.get("planned_rr") or 0.0),
                        actual_rr,
                        tr.get("session") or "London",
                        tr.get("setup_type", "AI Screenshot Import"),
                        "Trending",
                        tr.get("entry_reason", "Imported via AI Vision Screenshot"),
                        tr.get("exit_reason", ""),
                        "Disciplined",
                        5,
                        "None",
                        "",
                        f"Imported from {tr.get('import_source', 'Screenshot')}",
                        json.dumps(tr.get("screenshots", [])),
                        tr.get("open_time") or now,
                        tr.get("close_time") or now,
                        tr.get("status", "CLOSED"),
                        1,
                        tr.get("platform", "AI Vision"),
                        "high",
                        now, now
                    ))
                    saved_count += 1

                conn.commit()
                if account_id:
                    database.update_account_balance(account_id)
                self.send_json(200, {"success": True, "saved_trades_count": saved_count})

            elif path == "/api/demo/reset":
                # Clear database and reseed demo data
                conn.execute("DELETE FROM trades")
                conn.execute("DELETE FROM accounts")
                conn.execute("DELETE FROM strategies")
                conn.execute("DELETE FROM goals")
                conn.commit()
                database.seed_demo_data()
                self.send_json(200, {"success": True, "message": "Demo data reset successfully"})

            elif path == "/api/reports/restore":
                body = self.parse_json_body()
                conn.execute("DELETE FROM trades")
                conn.execute("DELETE FROM accounts")
                conn.execute("DELETE FROM strategies")
                conn.execute("DELETE FROM goals")

                for a in body.get("accounts", []):
                    conn.execute("""
                    INSERT OR REPLACE INTO accounts (id, name, broker, account_type, starting_balance, current_balance, current_equity, currency, profit_target_pct, max_daily_loss_pct, max_total_loss_pct, drawdown_type, phase, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (a["id"], a["name"], a["broker"], a["account_type"], a["starting_balance"], a["current_balance"], a["current_equity"], a["currency"], a["profit_target_pct"], a["max_daily_loss_pct"], a["max_total_loss_pct"], a["drawdown_type"], a["phase"], a["status"], a["created_at"], a["updated_at"]))

                for s in body.get("strategies", []):
                    conn.execute("""
                    INSERT OR REPLACE INTO strategies (id, name, description, setup_types, color, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """, (s["id"], s["name"], s.get("description", ""), s.get("setup_types", ""), s.get("color", "#3b82f6"), s["created_at"]))

                for t in body.get("trades", []):
                    conn.execute("""
                    INSERT OR REPLACE INTO trades (
                        id, ticket_id, account_id, strategy_id, instrument, side, lot_size,
                        entry_price, exit_price, stop_loss, take_profit, gross_pnl, commission, swap,
                        net_pnl, risk_amount, risk_pct, planned_rr, actual_rr, session,
                        setup_type, market_condition, entry_reason, exit_reason, emotional_state,
                        discipline_rating, mistakes, lessons, notes, screenshots,
                        open_time, close_time, status, is_imported, import_source, import_confidence,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        t["id"], t.get("ticket_id", ""), t.get("account_id"), t.get("strategy_id"), t["instrument"],
                        t["side"], t["lot_size"], t["entry_price"], t["exit_price"], t["stop_loss"],
                        t["take_profit"], t["gross_pnl"], t["commission"], t["swap"], t["net_pnl"],
                        t["risk_amount"], t["risk_pct"], t["planned_rr"], t["actual_rr"], t["session"],
                        t["setup_type"], t["market_condition"], t["entry_reason"], t["exit_reason"],
                        t["emotional_state"], t["discipline_rating"], t["mistakes"], t["lessons"],
                        t["notes"], t["screenshots"], t["open_time"], t["close_time"], t["status"],
                        t["is_imported"], t["import_source"], t["import_confidence"], t["created_at"], t["updated_at"]
                    ))

                for g in body.get("goals", []):
                    conn.execute("""
                    INSERT OR REPLACE INTO goals (id, title, target_type, target_value, current_value, period, deadline, status, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (g["id"], g["title"], g["target_type"], g["target_value"], g["current_value"], g["period"], g["deadline"], g["status"], g["notes"], g["created_at"]))

                conn.commit()
                self.send_json(200, {"success": True, "message": "Database successfully restored from backup."})

            else:
                self.send_json(404, {"error": "API route not found"})
        finally:
            conn.close()

    def do_PUT(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            try:
                self.handle_api_put(path)
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.send_json(500, {"error": str(e)})
            return
        self.send_error(404)

    def handle_api_put(self, path):
        conn = database.get_connection()
        body = self.parse_json_body()
        now = datetime.utcnow().isoformat()

        if path.startswith("/api/trades/"):
            trade_id = path.split("/")[3]
            entry = float(body.get("entry_price") or 0.0)
            exit_p = float(body.get("exit_price") or 0.0)
            sl = float(body.get("stop_loss") or 0.0)
            tp = float(body.get("take_profit") or 0.0)
            gross = float(body.get("gross_pnl") or 0.0)
            comm = float(body.get("commission") or 0.0)
            swap = float(body.get("swap") or 0.0)
            net = round(gross + comm + swap, 2)
            actual_rr = float(body.get("actual_rr") or 0.0)
            planned_rr = float(body.get("planned_rr") or 0.0)

            if sl > 0 and entry > 0 and actual_rr == 0.0:
                risk = abs(entry - sl)
                reward = abs(exit_p - entry)
                actual_rr = round(reward / risk, 2) if risk > 0 else 0.0

            conn.execute("""
            UPDATE trades SET
                ticket_id = ?, account_id = ?, strategy_id = ?, instrument = ?, side = ?,
                lot_size = ?, entry_price = ?, exit_price = ?, stop_loss = ?, take_profit = ?,
                gross_pnl = ?, commission = ?, swap = ?, net_pnl = ?, risk_amount = ?,
                risk_pct = ?, planned_rr = ?, actual_rr = ?, session = ?, setup_type = ?,
                market_condition = ?, entry_reason = ?, exit_reason = ?, emotional_state = ?,
                discipline_rating = ?, mistakes = ?, lessons = ?, notes = ?,
                open_time = ?, close_time = ?, updated_at = ?
            WHERE id = ?
            """, (
                body.get("ticket_id", ""),
                body.get("account_id"),
                body.get("strategy_id"),
                body.get("instrument", "EURUSD"),
                body.get("side", "BUY"),
                float(body.get("lot_size", 1.0)),
                entry, exit_p, sl, tp, gross, comm, swap, net,
                float(body.get("risk_amount") or 0.0),
                float(body.get("risk_pct") or 1.0),
                planned_rr, actual_rr,
                body.get("session", "London"),
                body.get("setup_type", ""),
                body.get("market_condition", "Trending"),
                body.get("entry_reason", ""),
                body.get("exit_reason", ""),
                body.get("emotional_state", "Disciplined"),
                int(body.get("discipline_rating", 5)),
                body.get("mistakes", "None"),
                body.get("lessons", ""),
                body.get("notes", ""),
                body.get("open_time", now),
                body.get("close_time", now),
                now,
                trade_id
            ))
            conn.commit()
            database.update_account_balance(body.get("account_id"))
            self.send_json(200, {"success": True, "message": "Trade updated"})

        elif path.startswith("/api/accounts/"):
            acc_id = path.split("/")[3]
            conn.execute("""
            UPDATE accounts SET
                name = ?, broker = ?, account_type = ?, starting_balance = ?,
                currency = ?, profit_target_pct = ?, max_daily_loss_pct = ?,
                max_total_loss_pct = ?, drawdown_type = ?, phase = ?, status = ?, updated_at = ?
            WHERE id = ?
            """, (
                body.get("name"), body.get("broker"), body.get("account_type"),
                float(body.get("starting_balance", 100000.0)), body.get("currency", "USD"),
                float(body.get("profit_target_pct", 10.0)), float(body.get("max_daily_loss_pct", 5.0)),
                float(body.get("max_total_loss_pct", 10.0)), body.get("drawdown_type", "balance_based"),
                body.get("phase", "Phase 1"), body.get("status", "active"), now,
                acc_id
            ))
            conn.commit()
            database.update_account_balance(acc_id)
            self.send_json(200, {"success": True, "message": "Account updated"})

        elif path.startswith("/api/goals/"):
            goal_id = path.split("/")[3]
            conn.execute("""
            UPDATE goals SET
                title = ?, target_type = ?, target_value = ?, current_value = ?,
                period = ?, deadline = ?, status = ?, notes = ?
            WHERE id = ?
            """, (
                body.get("title"), body.get("target_type"), float(body.get("target_value", 0.0)),
                float(body.get("current_value", 0.0)), body.get("period", "monthly"),
                body.get("deadline", ""), body.get("status", "in_progress"), body.get("notes", ""),
                goal_id
            ))
            conn.commit()
            self.send_json(200, {"success": True, "message": "Goal updated"})

        else:
            self.send_json(404, {"error": "API route not found"})

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            try:
                self.handle_api_delete(path)
            except Exception as e:
                import traceback
                traceback.print_exc()
                self.send_json(500, {"error": str(e)})
            return
        self.send_error(404)

    def handle_api_delete(self, path):
        conn = database.get_connection()

        if path.startswith("/api/trades/"):
            trade_id = path.split("/")[3]
            row = conn.execute("SELECT account_id FROM trades WHERE id = ?", (trade_id,)).fetchone()
            acc_id = row["account_id"] if row else None
            conn.execute("DELETE FROM trades WHERE id = ?", (trade_id,))
            conn.commit()
            if acc_id:
                database.update_account_balance(acc_id)
            self.send_json(200, {"success": True, "message": "Trade deleted successfully"})

        elif path.startswith("/api/accounts/"):
            acc_id = path.split("/")[3]
            conn.execute("DELETE FROM accounts WHERE id = ?", (acc_id,))
            conn.commit()
            self.send_json(200, {"success": True, "message": "Account deleted successfully"})

        elif path.startswith("/api/strategies/"):
            strat_id = path.split("/")[3]
            conn.execute("DELETE FROM strategies WHERE id = ?", (strat_id,))
            conn.commit()
            self.send_json(200, {"success": True, "message": "Strategy deleted successfully"})

        elif path.startswith("/api/goals/"):
            goal_id = path.split("/")[3]
            conn.execute("DELETE FROM goals WHERE id = ?", (goal_id,))
            conn.commit()
            self.send_json(200, {"success": True, "message": "Goal deleted successfully"})

        else:
            self.send_json(404, {"error": "API route not found"})

    def log_message(self, format, *args):
        # Clean logging
        sys.stderr.write(f"[{datetime.now().strftime('%H:%M:%S')}] {format % args}\n")

def run(port=PORT):
    database.init_db()
    database.seed_demo_data()
    server_address = ("0.0.0.0", port)
    httpd = ThreadedHTTPServer(server_address, TradeVaultHandler)
    print(f"\n=======================================================")
    print(f"🚀 TradeVault Server running at http://localhost:{port}")
    print(f"📁 Database: {database.DB_PATH}")
    print(f"🎨 Theme: Premium Dark Charcoal Terminal")
    print(f"=======================================================\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down TradeVault Server.")
        httpd.server_close()

if __name__ == "__main__":
    run(PORT)
