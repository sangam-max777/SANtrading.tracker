#!/usr/bin/env bash
echo "======================================================="
echo "Starting TradeVault Institutional Trading Journal..."
echo "======================================================="
python3 app.py
